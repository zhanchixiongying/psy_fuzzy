function T = inspect_ferrari2025_csv(fp)
%INSPECT_FERRARI2025_CSV Inspect Ferrari data_anx_gad7_prior.csv.

if nargin < 1 || isempty(fp)
    fp = fullfile('+p4fresh', '+io', 'Charpentier', 'data_anx_gad7_prior.csv');
end
T = readtable(fp, 'VariableNamingRule','preserve');
fprintf('Rows: %d, Columns: %d\n', height(T), width(T));
disp(string(T.Properties.VariableNames(:)));
expected = ["id","state_anx","trait_anx","gad7","rho","lambda","mu", ...
    "anx_gad7_median","anx_trait_median","anx_state_median", ...
    "p_gamble","p_gamble_mixed","p_gamble_gain"];
for i = 1:numel(expected)
    nm = expected(i);
    idx = find(strcmpi(string(T.Properties.VariableNames), nm), 1);
    if isempty(idx)
        fprintf('Missing expected column: %s\n', nm);
    else
        x = T{:,idx};
        if isnumeric(x) || islogical(x)
            fprintf('%s: mean=%.4f, sd=%.4f, min=%.4f, max=%.4f\n', nm, ...
                mean(double(x),'omitnan'), std(double(x),'omitnan'), min(double(x),[],'omitnan'), max(double(x),[],'omitnan'));
        else
            fprintf('%s: present\n', nm);
        end
    end
end
end
