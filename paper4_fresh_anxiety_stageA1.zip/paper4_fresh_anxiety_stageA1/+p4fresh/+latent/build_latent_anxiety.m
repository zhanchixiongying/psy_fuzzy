function dataset = build_latent_anxiety(dataset, cfg)
subjects = dataset.subjects;
trials = dataset.trials;

for s = 1:numel(subjects)
    tf = subjects(s).trait_features(:);
    Atrait = sum(cfg.latent.trait_weights(:) .* tf);
    subjects(s).latent_trait = Atrait;
end

for r = 1:numel(trials)
    sidx = double(trials(r).subject_idx);
    Astate = sum(cfg.latent.state_weights(:) .* trials(r).state_features(:));
    A = p4fresh.utils.sigmoid(cfg.latent.rho0 + cfg.latent.rhoT*subjects(sidx).latent_trait + cfg.latent.rhoS*Astate);
    trials(r).latent_state = Astate;
    trials(r).latent_total = A;
end

for s = 1:numel(subjects)
    idx = double(subjects(s).trial_indices);
    subjects(s).latent_state_mean = mean([trials(idx).latent_state]);
    subjects(s).latent_total_mean = mean([trials(idx).latent_total]);
end

dataset.subjects = subjects;
dataset.trials = trials;
end
