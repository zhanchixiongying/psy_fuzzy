function dataset = build_latent_anxiety(dataset, cfg)
%BUILD_LATENT_ANXIETY Construct Ferrari anxiety profile Psi.
%
% Psi_i = z(mean[z(GAD7_i), z(STAI-S_i), z(STAI-T_i)])
% High anxiety defaults to Psi >= median(Psi). Source median splits are
% retained only for diagnostics.

if nargin < 2
    cfg = struct(); %#ok<NASGU>
end

n = numel(dataset.subjects);
gad7 = NaN(n,1);
state = NaN(n,1);
trait = NaN(n,1);
gad7Split = false(n,1);
traitSplit = false(n,1);
stateSplit = false(n,1);

for i = 1:n
    gad7(i) = double(dataset.subjects(i).gad7);
    state(i) = double(dataset.subjects(i).state_anx);
    trait(i) = double(dataset.subjects(i).trait_anx);
    gad7Split(i) = logical(dataset.subjects(i).anx_gad7_median);
    traitSplit(i) = logical(dataset.subjects(i).anx_trait_median);
    stateSplit(i) = logical(dataset.subjects(i).anx_state_median);
end

zG = local_zscore(gad7);
zS = local_zscore(state);
zT = local_zscore(trait);
psi = local_zscore(mean([zG,zS,zT], 2, 'omitnan'));
highPsi = psi >= median(psi, 'omitnan');

latent_table = table();
latent_table.subject_idx = int32((1:n)');
latent_table.subject_id = string({dataset.subjects.subject_id}');
latent_table.gad7 = gad7;
latent_table.state_anx = state;
latent_table.trait_anx = trait;
latent_table.gad7_z = zG;
latent_table.state_anx_z = zS;
latent_table.trait_anx_z = zT;
latent_table.psi_anxiety = psi;
latent_table.high_anxiety = highPsi;
latent_table.anx_gad7_median = gad7Split;
latent_table.anx_trait_median = traitSplit;
latent_table.anx_state_median = stateSplit;

for i = 1:n
    dataset.subjects(i).latent_anxiety = psi(i);
    dataset.subjects(i).high_anxiety = highPsi(i);
    dataset.subjects(i).trait_features = [zG(i), zS(i), zT(i), psi(i)];
end

dataset.latent = struct();
dataset.latent.table = latent_table;
dataset.latent.method = "Ferrari anxiety profile: z(mean(zGAD7,zSTAI_state,zSTAI_trait)).";
end

function z = local_zscore(x)
x = double(x(:));
mu = mean(x,'omitnan');
sd = std(x,'omitnan');
if ~isfinite(sd) || sd < 1e-12
    z = zeros(size(x));
else
    z = (x - mu) ./ sd;
end
z(~isfinite(z)) = 0;
end
