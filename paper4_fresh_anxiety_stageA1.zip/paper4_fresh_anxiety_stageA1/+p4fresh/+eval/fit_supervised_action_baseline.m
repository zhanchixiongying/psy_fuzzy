function baseline = fit_supervised_action_baseline(actionTable, labelFile, method, caseId)
%FIT_SUPERVISED_ACTION_BASELINE Supervised expert-action imitation baseline.
%
% The supervised model is a comparison baseline, not the deployable rule.
% It uses only deployable features and expert communication labels.
%
% If split=train/validation/test is present in the label file, the split is
% respected. Otherwise deterministic stratified CV is used.

if nargin < 3 || isempty(method), method = "treebagger"; end
if nargin < 4, caseId = ""; end

L0 = local_read_label_table(labelFile);
L = local_filter_case(L0, caseId);
local_assert_ready(L, labelFile, caseId);
local_assert_no_leakage(L);

if nargin < 1 || isempty(actionTable)
    [X, y, meta, featureNames] = local_features_from_label_table(L);
else
    [X, y, meta, featureNames] = local_features_from_action_table(actionTable, L, caseId);
end

valid = all(isfinite(X),2) & strlength(y) > 0 & ~ismissing(y);
X = X(valid,:);
y = y(valid);
meta = meta(valid,:);

baseline = struct();
baseline.method = string(method);
baseline.case_id = string(caseId);
baseline.label_file = string(labelFile);
baseline.feature_names = featureNames;
baseline.n = numel(y);
baseline.primary_labels_all5 = local_primary_labels();
baseline.note = "Supervised expert-action imitation baseline; deployable feature comparison only.";

if numel(y) < 5
    error('fit_supervised_action_baseline:TooFewRows', 'Too few matched labeled rows for supervised baseline.');
end

if ismember("split", string(meta.Properties.VariableNames)) && any(strlength(string(meta.split)) > 0)
    baseline.split_mode = "provided_split";
    baseline = local_run_provided_split(baseline, X, y, meta, method);
else
    baseline.split_mode = "deterministic_cross_validation";
    baseline = local_run_cv(baseline, X, y, meta, method, 5);
end
end

function baseline = local_run_provided_split(baseline, X, y, meta, method)
split = lower(strtrim(string(meta.split)));
isTrain = split == "train";
isVal = split == "validation" | split == "val" | split == "dev";
isTest = split == "test";

if ~any(isTrain), error('fit_supervised_action_baseline:NoTrainRows', 'No split=train rows found.'); end
if ~any(isVal) && ~any(isTest), error('fit_supervised_action_baseline:NoEvalRows', 'No validation/test rows found.'); end

[Xz, mu, sd] = local_standardize_train(X, isTrain);
model = local_fit_classifier(Xz(isTrain,:), y(isTrain), method);
baseline.model = model;
baseline.standardization_mu = mu;
baseline.standardization_sd = sd;

pred = strings(numel(y),1);
pred(isTrain) = local_predict_classifier(model, Xz(isTrain,:));
if any(isVal), pred(isVal) = local_predict_classifier(model, Xz(isVal,:)); end
if any(isTest), pred(isTest) = local_predict_classifier(model, Xz(isTest,:)); end

baseline.prediction_table = meta;
baseline.prediction_table.expert_primary_action = y;
baseline.prediction_table.predicted_primary_action = pred;
baseline.prediction_table.correct = pred == y;

baseline.train_metrics = local_classification_metrics(pred(isTrain), y(isTrain));
if any(isVal), baseline.validation_metrics = local_classification_metrics(pred(isVal), y(isVal)); else, baseline.validation_metrics = struct(); end
if any(isTest), baseline.test_metrics = local_classification_metrics(pred(isTest), y(isTest)); else, baseline.test_metrics = struct(); end
baseline.all_eval_metrics = local_classification_metrics(pred(isVal | isTest), y(isVal | isTest));
baseline.summary_table = local_make_summary_table(baseline);
end

function baseline = local_run_cv(baseline, X, y, meta, method, K)
N = numel(y);
K = min(max(2,K), N);
fold = local_stratified_folds(y, K, 20261001);
pred = strings(N,1);
for k = 1:K
    isTest = fold == k;
    isTrain = ~isTest;
    [Xz, ~, ~] = local_standardize_train(X, isTrain);
    model = local_fit_classifier(Xz(isTrain,:), y(isTrain), method);
    pred(isTest) = local_predict_classifier(model, Xz(isTest,:));
end
baseline.prediction_table = meta;
baseline.prediction_table.expert_primary_action = y;
baseline.prediction_table.predicted_primary_action = pred;
baseline.prediction_table.correct = pred == y;
baseline.cv_metrics = local_classification_metrics(pred, y);
baseline.summary_table = local_make_summary_table(baseline);
end

function model = local_fit_classifier(X, y, method)
method = lower(string(method));
yCat = categorical(y);
if (method == "treebagger" || method == "bagger" || method == "rf") && exist('TreeBagger','file') == 2
    model.type = "treebagger";
    model.object = TreeBagger(200, X, yCat, 'Method','classification', 'OOBPrediction','off');
elseif (method == "linear" || method == "ecoc") && exist('fitcecoc','file') == 2
    model.type = "fitcecoc_linear";
    model.object = fitcecoc(X, yCat);
elseif exist('fitcecoc','file') == 2
    model.type = "fitcecoc_default";
    model.object = fitcecoc(X, yCat);
else
    model = local_fit_centroid(X, y);
end
end

function pred = local_predict_classifier(model, X)
switch string(model.type)
    case {"fitcecoc_linear","fitcecoc_default"}
        pred = string(predict(model.object, X));
    case "treebagger"
        pred = string(predict(model.object, X));
    case "centroid"
        pred = local_predict_centroid(model, X);
    otherwise
        error('fit_supervised_action_baseline:UnknownModelType', 'Unknown model type: %s', string(model.type));
end
pred = local_canonical_primary(pred);
end

function model = local_fit_centroid(X, y)
labels = unique(string(y(:)), 'stable');
centroids = NaN(numel(labels), size(X,2));
for i = 1:numel(labels)
    centroids(i,:) = mean(X(string(y)==labels(i),:), 1, 'omitnan');
end
centroids(~isfinite(centroids)) = 0;
model = struct('type',"centroid",'labels',labels,'centroids',centroids);
end

function pred = local_predict_centroid(model, X)
D = zeros(size(X,1), numel(model.labels));
for j = 1:numel(model.labels)
    dif = X - model.centroids(j,:);
    D(:,j) = sum(dif.^2, 2);
end
[~,ix] = min(D, [], 2);
pred = string(model.labels(ix));
end

function [X, y, meta, featureNames] = local_features_from_action_table(actionTable, L, caseId)
[tfA, locA] = local_match_action_label_rows(actionTable, L, caseId);
L = L(tfA,:);
A = actionTable(locA,:);
[X, featureNames] = local_feature_matrix(A);
y = local_canonical_primary(L.expert_primary_action);
meta = local_meta_from_label(L, A, caseId);
end

function [tf, loc] = local_match_action_label_rows(A, L, caseId)
Aprof = string(A.profile_id);
Lprof = string(L.profile_id);
if ismember("case_id", string(A.Properties.VariableNames)) && ismember("case_id", string(L.Properties.VariableNames)) && strlength(string(caseId)) == 0
    Akey = string(A.case_id) + "||" + Aprof;
    Lkey = string(L.case_id) + "||" + Lprof;
else
    Akey = Aprof;
    Lkey = Lprof;
end
[tf, loc] = ismember(Lkey, Akey);
end

function [X, y, meta, featureNames] = local_features_from_label_table(L)
[X, featureNames] = local_feature_matrix(L);
y = local_canonical_primary(L.expert_primary_action);
meta = local_meta_from_label(L, table(), "");
end

function meta = local_meta_from_label(L, A, caseId)
meta = table();
if ismember("case_id", string(L.Properties.VariableNames))
    meta.case_id = string(L.case_id);
elseif ~isempty(A) && istable(A) && ismember("case_id", string(A.Properties.VariableNames))
    meta.case_id = string(A.case_id);
else
    meta.case_id = repmat(string(caseId), height(L), 1);
end
meta.profile_id = string(L.profile_id);
if ismember("split", string(L.Properties.VariableNames)), meta.split = lower(strtrim(string(L.split))); else, meta.split = strings(height(L),1); end
if ismember("sample_type", string(L.Properties.VariableNames)), meta.sample_type = string(L.sample_type); end
if ismember("challenge_stratum", string(L.Properties.VariableNames)), meta.challenge_stratum = string(L.challenge_stratum); end
end

function [X, featureNames] = local_feature_matrix(T)
featureNames = ["B","U","K","C","F","W_tail","G_base","G_support","G_info_core","G_info_resid","G_mechanism_load", ...
    "abs_D_PT","Pol_PT","abs_D_support","Pol_support","S_info","S_anxiety","S_resilience","S_guardrail","S_capacity","S_communication_burden"];
X = NaN(height(T), numel(featureNames));
names = string(T.Properties.VariableNames);
for j = 1:numel(featureNames)
    nm = featureNames(j);
    if ismember(nm, names), X(:,j) = double(T.(nm)); else, X(:,j) = 0; end
end
for j = 1:size(X,2)
    v = X(:,j);
    fill = median(v(isfinite(v)), 'omitnan');
    if isempty(fill) || ~isfinite(fill), fill = 0; end
    v(~isfinite(v)) = fill;
    X(:,j) = v;
end
end

function [Xz, mu, sd] = local_standardize_train(X, isTrain)
mu = mean(X(isTrain,:), 1, 'omitnan');
sd = std(X(isTrain,:), 0, 1, 'omitnan');
sd(~isfinite(sd) | sd < 1e-12) = 1;
mu(~isfinite(mu)) = 0;
Xz = (X - mu) ./ sd;
Xz(~isfinite(Xz)) = 0;
end

function metrics = local_classification_metrics(pred, truth)
pred = local_canonical_primary(pred(:));
truth = local_canonical_primary(truth(:));
valid = strlength(truth) > 0 & strlength(pred) > 0 & ~ismissing(truth) & ~ismissing(pred);
pred = pred(valid); truth = truth(valid);
labelsAll = local_primary_labels();
observed = labelsAll(ismember(labelsAll, unique([pred; truth])));
if isempty(observed), observed = labelsAll; end
mAll = local_primary_metrics(pred, truth, labelsAll);
mObs = local_primary_metrics(pred, truth, observed);
metrics = struct();
metrics.n = numel(truth);
metrics.accuracy = mAll.accuracy;
metrics.macro_f1_5labels = mAll.macro_f1;
metrics.macro_f1_observed = mObs.macro_f1;
metrics.weighted_f1 = mAll.weighted_f1;
metrics.primary_coverage_rate = numel(unique(truth)) / numel(labelsAll);
metrics.confusion_matrix_5labels = mAll.confusion_matrix;
metrics.per_label_all5 = mAll.per_label;
metrics.per_label_observed = mObs.per_label;
end

function out = local_primary_metrics(pred, gold, labels)
labels = string(labels(:));
cm = zeros(numel(labels), numel(labels));
for i = 1:numel(gold)
    r = find(labels == gold(i), 1); c = find(labels == pred(i), 1);
    if ~isempty(r) && ~isempty(c), cm(r,c) = cm(r,c) + 1; end
end
precision = zeros(numel(labels),1); recall = zeros(numel(labels),1); f1 = zeros(numel(labels),1);
support = sum(cm,2); predicted_count = sum(cm,1)';
for k = 1:numel(labels)
    tp = cm(k,k); fp = sum(cm(:,k)) - tp; fn = sum(cm(k,:)) - tp;
    precision(k) = tp / max(tp + fp, eps);
    recall(k) = tp / max(tp + fn, eps);
    f1(k) = 2 * precision(k) * recall(k) / max(precision(k) + recall(k), eps);
end
out = struct();
out.confusion_matrix = cm;
out.accuracy = sum(diag(cm)) / max(sum(cm(:)), eps);
out.macro_f1 = mean(f1, 'omitnan');
out.weighted_f1 = sum(f1 .* support) / max(sum(support), eps);
out.per_label = table(labels, precision, recall, f1, support, predicted_count, ...
    'VariableNames', {'label','precision','recall','f1','support','predicted_count'});
end

function T = local_make_summary_table(baseline)
T = table();
T.case_id = string(baseline.case_id);
T.method = string(baseline.method);
T.split_mode = string(baseline.split_mode);
T.n = double(baseline.n);

if isfield(baseline,'train_metrics')
    T.train_accuracy = baseline.train_metrics.accuracy;
    T.train_macro_f1_5labels = baseline.train_metrics.macro_f1_5labels;
    T.train_weighted_f1 = baseline.train_metrics.weighted_f1;
else
    T.train_accuracy = NaN; T.train_macro_f1_5labels = NaN; T.train_weighted_f1 = NaN;
end

if isfield(baseline,'validation_metrics') && isfield(baseline.validation_metrics,'accuracy')
    T.validation_accuracy = baseline.validation_metrics.accuracy;
    T.validation_macro_f1_5labels = baseline.validation_metrics.macro_f1_5labels;
    T.validation_weighted_f1 = baseline.validation_metrics.weighted_f1;
else
    T.validation_accuracy = NaN; T.validation_macro_f1_5labels = NaN; T.validation_weighted_f1 = NaN;
end

if isfield(baseline,'test_metrics') && isfield(baseline.test_metrics,'accuracy')
    T.test_accuracy = baseline.test_metrics.accuracy;
    T.test_macro_f1_observed = baseline.test_metrics.macro_f1_observed;
    T.test_macro_f1_5labels = baseline.test_metrics.macro_f1_5labels;
    T.test_weighted_f1 = baseline.test_metrics.weighted_f1;
else
    T.test_accuracy = NaN; T.test_macro_f1_observed = NaN; T.test_macro_f1_5labels = NaN; T.test_weighted_f1 = NaN;
end

if isfield(baseline,'all_eval_metrics')
    T.eval_accuracy = baseline.all_eval_metrics.accuracy;
    T.eval_macro_f1_observed = baseline.all_eval_metrics.macro_f1_observed;
    T.eval_macro_f1_5labels = baseline.all_eval_metrics.macro_f1_5labels;
    T.eval_weighted_f1 = baseline.all_eval_metrics.weighted_f1;
elseif isfield(baseline,'cv_metrics')
    T.eval_accuracy = baseline.cv_metrics.accuracy;
    T.eval_macro_f1_observed = baseline.cv_metrics.macro_f1_observed;
    T.eval_macro_f1_5labels = baseline.cv_metrics.macro_f1_5labels;
    T.eval_weighted_f1 = baseline.cv_metrics.weighted_f1;
else
    T.eval_accuracy = NaN; T.eval_macro_f1_observed = NaN; T.eval_macro_f1_5labels = NaN; T.eval_weighted_f1 = NaN;
end
end

function L = local_read_label_table(labelFile)
try, L = readtable(labelFile, 'VariableNamingRule','preserve', 'TextType','string');
catch, L = readtable(labelFile, 'VariableNamingRule','preserve'); end
end

function L = local_filter_case(L, caseId)
caseId = string(caseId);
if strlength(caseId) > 0 && ismember("case_id", string(L.Properties.VariableNames))
    L = L(string(L.case_id) == caseId, :);
end
end

function local_assert_ready(L, labelFile, caseId)
names = string(L.Properties.VariableNames);
required = ["profile_id","expert_primary_action"];
missing = required(~ismember(required, names));
if ~isempty(missing), error('fit_supervised_action_baseline:MissingColumns', 'Label file %s is missing columns: %s', string(labelFile), strjoin(missing, ', ')); end
if height(L) == 0, error('fit_supervised_action_baseline:NoRowsForCase', 'No rows found for case_id=%s.', string(caseId)); end
end

function local_assert_no_leakage(L)
names = lower(string(L.Properties.VariableNames));
for i = 1:numel(names)
    nm = names(i);
    if contains(nm,"ground_truth") || contains(nm,"future") || contains(nm,"outcome") || contains(nm,"audit")
        error('fit_supervised_action_baseline:LeakageColumnDetected', 'Forbidden leakage column: %s', nm);
    end
    if contains(nm,"truth") && ~(nm == "truthiness")
        error('fit_supervised_action_baseline:LeakageColumnDetected', 'Forbidden truth column: %s', nm);
    end
    if contains(nm,"residual") && ~(nm == "g_info_resid")
        error('fit_supervised_action_baseline:LeakageColumnDetected', 'Forbidden residual column: %s', nm);
    end
end
end

function fold = local_stratified_folds(y, K, seed)
rng(seed);
y = string(y(:));
fold = zeros(numel(y),1);
classes = unique(y, 'stable');
for c = 1:numel(classes)
    idx = find(y == classes(c));
    idx = idx(randperm(numel(idx)));
    for j = 1:numel(idx), fold(idx(j)) = mod(j-1, K) + 1; end
end
end

function labels = local_primary_labels()
labels = ["Information supplementation";"Anxiety-sensitive explanation";"Protective financial resilience communication";"Guardrail explanation";"Standard risk-capacity communication"];
end

function y = local_canonical_primary(x)
s = lower(strtrim(string(x(:))));
s = replace(s, "_", " "); s = replace(s, "-", " ");
y = strings(size(s));
for i = 1:numel(s)
    si = s(i);
    if ismissing(si) || strlength(si) == 0, y(i) = "";
    elseif contains(si, "information") || strcmp(si, "info"), y(i) = "Information supplementation";
    elseif contains(si, "anxiety"), y(i) = "Anxiety-sensitive explanation";
    elseif contains(si, "protective") || contains(si, "resilience"), y(i) = "Protective financial resilience communication";
    elseif contains(si, "guardrail"), y(i) = "Guardrail explanation";
    elseif contains(si, "standard") || contains(si, "capacity"), y(i) = "Standard risk-capacity communication";
    else, y(i) = string(x(i)); end
end
end
