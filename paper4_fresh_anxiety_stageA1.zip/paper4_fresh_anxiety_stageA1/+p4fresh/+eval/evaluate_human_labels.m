function metrics = evaluate_human_labels(actionTable, labelFile, caseId)
%EVALUATE_HUMAN_LABELS Evaluate v8 deployable actions against expert communication labels.
%
% Required label columns:
%   profile_id, expert_primary_action
%
% Recommended:
%   case_id, split, expert_secondary_flags, expert_confidence_1to5
%
% This function is strict about leakage:
%   It rejects truth, ground_truth, audit, future, outcome, and residual
%   columns except G_info_resid.

if nargin < 3, caseId = ""; end
if isempty(actionTable) || ~istable(actionTable)
    error('evaluate_human_labels:BadActionTable', 'actionTable must be a non-empty table.');
end

L0 = local_read_label_table(labelFile);
L = local_filter_case(L0, caseId);
local_assert_label_ready(L, labelFile, caseId);
local_assert_no_label_leakage(L);
local_assert_action_table(actionTable);

[Aidx, Lidx] = local_match_action_label_rows(actionTable, L, caseId);
if isempty(Aidx)
    error('evaluate_human_labels:NoMatchedRows', 'No matched profile rows between action table and label file.');
end

A = actionTable(Aidx,:);
L = L(Lidx,:);

gold = local_canonical_primary(L.expert_primary_action);
pred = local_canonical_primary(A.primary_action);
valid = strlength(gold) > 0 & ~ismissing(gold) & strlength(pred) > 0 & ~ismissing(pred);
A = A(valid,:);
L = L(valid,:);
gold = gold(valid);
pred = pred(valid);

allLabels = local_primary_labels();
observedLabels = allLabels(ismember(allLabels, unique([gold; pred])));
if isempty(observedLabels), observedLabels = allLabels; end

primaryAll = local_primary_metrics(pred, gold, allLabels);
primaryObserved = local_primary_metrics(pred, gold, observedLabels);

flagMetrics = struct();
if ismember("expert_secondary_flags", string(L.Properties.VariableNames)) && ismember("secondary_flags", string(A.Properties.VariableNames))
    flagMetrics = local_flag_metrics(string(A.secondary_flags), string(L.expert_secondary_flags));
else
    flagMetrics.micro_f1 = NaN;
    flagMetrics.hamming_accuracy = NaN;
    flagMetrics.mean_jaccard = NaN;
    flagMetrics.per_flag = table();
end

ratingT = local_rating_summary(L);

metrics = struct();
metrics.case_id = string(caseId);
metrics.label_file = string(labelFile);
metrics.n_rows_in_label_file = height(L0);
metrics.n_rows_after_case_filter = height(local_filter_case(L0, caseId));
metrics.n_matched = numel(gold);
metrics.n_unmatched = height(local_filter_case(L0, caseId)) - numel(gold);
metrics.primary_labels_all5 = allLabels;
metrics.primary_labels_observed = observedLabels;

metrics.accuracy = primaryAll.accuracy;
metrics.macro_f1_5labels = primaryAll.macro_f1;
metrics.macro_f1_observed = primaryObserved.macro_f1;
metrics.weighted_f1 = primaryAll.weighted_f1;
metrics.expert_primary_coverage_rate = numel(unique(gold)) / numel(allLabels);
metrics.model_primary_coverage_rate = numel(unique(pred)) / numel(allLabels);
metrics.primary_coverage_rate = metrics.expert_primary_coverage_rate;

metrics.confusion_matrix_5labels = primaryAll.confusion_matrix;
metrics.per_label_all5 = primaryAll.per_label;
metrics.per_label_observed = primaryObserved.per_label;
metrics.flag_metrics = flagMetrics;
metrics.rating_summary = ratingT;

prediction = table();
prediction.profile_id = string(L.profile_id);
if ismember("case_id", string(L.Properties.VariableNames))
    prediction.case_id = string(L.case_id);
elseif ismember("case_id", string(A.Properties.VariableNames))
    prediction.case_id = string(A.case_id);
else
    prediction.case_id = repmat(string(caseId), height(L), 1);
end
if ismember("split", string(L.Properties.VariableNames)), prediction.split = string(L.split); else, prediction.split = strings(height(L),1); end
if ismember("sample_type", string(L.Properties.VariableNames)), prediction.sample_type = string(L.sample_type); end
if ismember("challenge_stratum", string(L.Properties.VariableNames)), prediction.challenge_stratum = string(L.challenge_stratum); end
prediction.expert_primary_action = gold;
prediction.model_primary_action = pred;
prediction.primary_correct = pred == gold;
if ismember("expert_secondary_flags", string(L.Properties.VariableNames)), prediction.expert_secondary_flags = string(L.expert_secondary_flags); end
if ismember("secondary_flags", string(A.Properties.VariableNames)), prediction.model_secondary_flags = string(A.secondary_flags); end
metrics.prediction_table = prediction;

metrics.summary_table = table(string(caseId), metrics.n_rows_in_label_file, metrics.n_rows_after_case_filter, metrics.n_matched, metrics.n_unmatched, ...
    metrics.accuracy, metrics.macro_f1_observed, metrics.macro_f1_5labels, metrics.weighted_f1, ...
    metrics.expert_primary_coverage_rate, metrics.model_primary_coverage_rate, ...
    metrics.flag_metrics.micro_f1, metrics.flag_metrics.hamming_accuracy, metrics.flag_metrics.mean_jaccard, ...
    'VariableNames', {'case_id','n_label_rows_total','n_after_case_filter','n_evaluated','n_unmatched', ...
    'accuracy','macro_f1_observed','macro_f1_5labels','weighted_f1','expert_primary_coverage_rate','model_primary_coverage_rate', ...
    'flag_micro_f1','flag_hamming_accuracy','mean_flag_jaccard'});
end

function [Aidx, Lidx] = local_match_action_label_rows(A, L, caseId)
Aprof = string(A.profile_id);
Lprof = string(L.profile_id);

if ismember("case_id", string(A.Properties.VariableNames)) && ismember("case_id", string(L.Properties.VariableNames)) && strlength(string(caseId)) == 0
    Akey = string(A.case_id) + "||" + Aprof;
    Lkey = string(L.case_id) + "||" + Lprof;
else
    Akey = Aprof;
    Lkey = Lprof;
end

[tf, loc] = ismember(Lkey, Akey);
Lidx = find(tf);
Aidx = loc(tf);
end

function out = local_primary_metrics(pred, gold, labels)
labels = string(labels(:));
pred = string(pred(:));
gold = string(gold(:));
cm = zeros(numel(labels), numel(labels));
for i = 1:numel(gold)
    r = find(labels == gold(i), 1);
    c = find(labels == pred(i), 1);
    if ~isempty(r) && ~isempty(c), cm(r,c) = cm(r,c) + 1; end
end
precision = zeros(numel(labels),1);
recall = zeros(numel(labels),1);
f1 = zeros(numel(labels),1);
support = sum(cm,2);
predicted_count = sum(cm,1)';
for k = 1:numel(labels)
    tp = cm(k,k);
    fp = sum(cm(:,k)) - tp;
    fn = sum(cm(k,:)) - tp;
    precision(k) = tp / max(tp + fp, eps);
    recall(k) = tp / max(tp + fn, eps);
    f1(k) = 2 * precision(k) * recall(k) / max(precision(k) + recall(k), eps);
end
out = struct();
out.labels = labels;
out.confusion_matrix = cm;
out.per_label = table(labels, precision, recall, f1, support, predicted_count, ...
    'VariableNames', {'label','precision','recall','f1','support','predicted_count'});
out.accuracy = sum(diag(cm)) / max(sum(cm(:)), eps);
out.macro_f1 = mean(f1, 'omitnan');
out.weighted_f1 = sum(f1 .* support) / max(sum(support), eps);
end

function fm = local_flag_metrics(predFlags, goldFlags)
flagList = ["info","anxiety_sensitive","resilience","guardrail","capacity"];
predM = local_flags_to_matrix(predFlags, flagList);
goldM = local_flags_to_matrix(goldFlags, flagList);

tp = sum(predM & goldM, 1)';
fp = sum(predM & ~goldM, 1)';
fn = sum(~predM & goldM, 1)';
tn = sum(~predM & ~goldM, 1)';

precision = tp ./ max(tp + fp, eps);
recall = tp ./ max(tp + fn, eps);
f1 = 2 .* precision .* recall ./ max(precision + recall, eps);

microTP = sum(tp);
microFP = sum(fp);
microFN = sum(fn);
microP = microTP / max(microTP + microFP, eps);
microR = microTP / max(microTP + microFN, eps);
microF1 = 2 * microP * microR / max(microP + microR, eps);

J = zeros(size(predM,1),1);
for i = 1:size(predM,1)
    inter = sum(predM(i,:) & goldM(i,:));
    uni = sum(predM(i,:) | goldM(i,:));
    if uni == 0, J(i) = 1; else, J(i) = inter / uni; end
end

fm = struct();
fm.micro_f1 = microF1;
fm.hamming_accuracy = mean(predM(:) == goldM(:));
fm.mean_jaccard = mean(J, 'omitnan');
fm.per_flag = table(flagList(:), precision, recall, f1, tp, fp, fn, tn, ...
    'VariableNames', {'flag','precision','recall','f1','tp','fp','fn','tn'});
end

function M = local_flags_to_matrix(S, flagList)
S = string(S(:));
S = lower(strtrim(S));
S = replace(S, ",", ";");
S = replace(S, " ", "_");
S(ismissing(S)) = "";
M = false(numel(S), numel(flagList));
for j = 1:numel(flagList)
    M(:,j) = contains(";" + S + ";", ";" + flagList(j) + ";");
end
end

function T = local_rating_summary(L)
ratingNames = ["expert_confidence_1to5","ambiguity_1to5","decision_difficulty_1to5","usefulness_1to5","clarity_1to5","trust_1to5","cognitive_load_1to5"];
field = strings(0,1); n = zeros(0,1); mean_value = zeros(0,1); sd_value = zeros(0,1); min_value = zeros(0,1); max_value = zeros(0,1);
names = string(L.Properties.VariableNames);
for i = 1:numel(ratingNames)
    nm = ratingNames(i);
    if ismember(nm, names)
        x = double(L.(nm));
        mask = isfinite(x);
        field(end+1,1) = nm; %#ok<AGROW>
        n(end+1,1) = sum(mask); %#ok<AGROW>
        mean_value(end+1,1) = mean(x(mask),'omitnan'); %#ok<AGROW>
        sd_value(end+1,1) = std(x(mask),'omitnan'); %#ok<AGROW>
        min_value(end+1,1) = min(x(mask),[],'omitnan'); %#ok<AGROW>
        max_value(end+1,1) = max(x(mask),[],'omitnan'); %#ok<AGROW>
    end
end
T = table(field, n, mean_value, sd_value, min_value, max_value);
end

function L = local_read_label_table(labelFile)
try
    L = readtable(labelFile, 'VariableNamingRule','preserve', 'TextType','string');
catch
    L = readtable(labelFile, 'VariableNamingRule','preserve');
end
end

function L = local_filter_case(L, caseId)
caseId = string(caseId);
if strlength(caseId) > 0 && ismember("case_id", string(L.Properties.VariableNames))
    L = L(string(L.case_id) == caseId, :);
end
end

function local_assert_label_ready(L, labelFile, caseId)
names = string(L.Properties.VariableNames);
required = ["profile_id","expert_primary_action"];
missing = required(~ismember(required, names));
if ~isempty(missing)
    error('evaluate_human_labels:MissingLabelColumns', 'Label file %s is missing columns: %s', string(labelFile), strjoin(missing, ', '));
end
if height(L) == 0
    error('evaluate_human_labels:NoRowsForCase', 'No label rows found for case_id=%s in %s.', string(caseId), string(labelFile));
end
gold = local_canonical_primary(L.expert_primary_action);
allowed = local_primary_labels();
nonEmpty = strlength(gold) > 0 & ~ismissing(gold);
bad = unique(gold(nonEmpty & ~ismember(gold, allowed)));
if ~any(nonEmpty)
    error('evaluate_human_labels:NoExpertPrimaryAction', 'No non-empty expert_primary_action found.');
end
if ~isempty(bad)
    error('evaluate_human_labels:BadExpertPrimaryAction', 'Invalid expert_primary_action values: %s', strjoin(bad, ', '));
end
end

function local_assert_action_table(A)
names = string(A.Properties.VariableNames);
required = ["profile_id","primary_action"];
missing = required(~ismember(required, names));
if ~isempty(missing)
    error('evaluate_human_labels:BadActionTable', 'actionTable is missing columns: %s', strjoin(missing, ', '));
end
end

function local_assert_no_label_leakage(L)
names = lower(string(L.Properties.VariableNames));
for i = 1:numel(names)
    nm = names(i);
    if contains(nm,"ground_truth") || contains(nm,"future") || contains(nm,"outcome") || contains(nm,"audit")
        error('evaluate_human_labels:LeakageColumnDetected', 'Forbidden leakage column: %s', nm);
    end
    if contains(nm,"truth") && ~(nm == "truthiness")
        error('evaluate_human_labels:LeakageColumnDetected', 'Forbidden truth column: %s', nm);
    end
    if contains(nm,"residual") && ~(nm == "g_info_resid")
        error('evaluate_human_labels:LeakageColumnDetected', 'Forbidden residual column: %s', nm);
    end
end
end

function labels = local_primary_labels()
labels = ["Information supplementation"; ...
          "Anxiety-sensitive explanation"; ...
          "Protective financial resilience communication"; ...
          "Guardrail explanation"; ...
          "Standard risk-capacity communication"];
end

function y = local_canonical_primary(x)
s = lower(strtrim(string(x(:))));
s = replace(s, "_", " ");
s = replace(s, "-", " ");
y = strings(size(s));
for i = 1:numel(s)
    si = s(i);
    if ismissing(si) || strlength(si) == 0
        y(i) = "";
    elseif contains(si, "information") || strcmp(si, "info")
        y(i) = "Information supplementation";
    elseif contains(si, "anxiety")
        y(i) = "Anxiety-sensitive explanation";
    elseif contains(si, "protective") || contains(si, "resilience")
        y(i) = "Protective financial resilience communication";
    elseif contains(si, "guardrail")
        y(i) = "Guardrail explanation";
    elseif contains(si, "standard") || contains(si, "capacity")
        y(i) = "Standard risk-capacity communication";
    else
        y(i) = string(x(i));
    end
end
end
