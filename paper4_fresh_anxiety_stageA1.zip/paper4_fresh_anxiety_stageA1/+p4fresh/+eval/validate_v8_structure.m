function checks = validate_v8_structure(out)
%VALIDATE_V8_STRUCTURE Hard checks for APF-DS-XAI v8 data structures.
checks = table();
for c = 1:numel(out.fuzzy_cases)
    fc = out.fuzzy_cases(c);
    tr = out.transfers{c};
    row = table();
    row.case_id = string(fc.case_id);
    row.layer_shape_ok = isequal(size(fc.B), size(fc.U), size(fc.K), size(fc.C), size(fc.F), size(fc.W_tail));
    row.alt_vector_ok = numel(fc.B_alt)==numel(fc.alternative_names) && numel(fc.ground_truth)==numel(fc.alternative_names);
    row.profile_ok = isfield(fc,'profile_id') && numel(fc.profile_id)==numel(fc.alternative_names) && numel(unique(fc.profile_id)) <= numel(fc.alternative_names);
    row.pt_degeneracy_ok = isfield(tr,'sanity') && tr.sanity.PT_mean_minus_base_max_abs < 1e-10;
    row.deployable_leakage_free = logical(tr.sanity.deployable_action_leakage_free);
    row.has_info_resid = isfield(tr,'G_information_need_resid') && numel(tr.G_information_need_resid)==numel(tr.G_base);
    row.has_mechanism_load = isfield(tr,'G_mechanism_load') && numel(tr.G_mechanism_load)==numel(tr.G_base);
    row.has_communication_burden = isfield(tr,'G_communication_burden') && numel(tr.G_communication_burden)==numel(tr.G_base);
    row.has_flag_rates = isfield(tr,'action_flag_rate_table') && istable(tr.action_flag_rate_table) && height(tr.action_flag_rate_table)>0;
    row.has_cooccurrence = isfield(tr,'action_cooccurrence_table') && istable(tr.action_cooccurrence_table) && height(tr.action_cooccurrence_table)>0;
    row.has_calibrated_audit = istable(tr.audit_table) && ismember('residual_calibrated', string(tr.audit_table.Properties.VariableNames));
    row.has_rationale_split = istable(tr.deployable_action_table) && all(ismember(["primary_rationale","secondary_cautions","top_drivers"], string(tr.deployable_action_table.Properties.VariableNames)));
    row.has_action_mechanism_fields = istable(tr.deployable_action_table) && all(ismember(["G_mechanism_load","S_communication_burden"], string(tr.deployable_action_table.Properties.VariableNames)));
    row.has_deployable_explanation_table = isfield(tr,'deployable_explanation_table') && istable(tr.deployable_explanation_table) && height(tr.deployable_explanation_table)>0;
    row.deployable_explanation_no_truth = row.has_deployable_explanation_table && local_no_leakage_vars(tr.deployable_explanation_table);
    row.explanation_table_no_truth = isfield(tr,'explanation_table') && istable(tr.explanation_table) && local_no_leakage_vars(tr.explanation_table);
    row.has_validation_component_table = isfield(tr,'validation_component_table') && istable(tr.validation_component_table) && height(tr.validation_component_table)>0;
    row.action_ablation_recomputed = istable(tr.action_ablation_table) && all(ismember(["primary_changed_rate","flag_jaccard_distance"], string(tr.action_ablation_table.Properties.VariableNames))) && ~all(isnan(tr.action_ablation_table.primary_changed_rate));
    row.deployable_table_no_truth = local_no_leakage_vars(tr.deployable_action_table);
    checks = [checks; row]; %#ok<AGROW>
end
end

function ok = local_no_leakage_vars(T)
names = lower(string(T.Properties.VariableNames));
ok = true;
for i = 1:numel(names)
    nm = names(i);
    if contains(nm,"truth") || contains(nm,"ground_truth") || contains(nm,"expert") || contains(nm,"future") || contains(nm,"outcome") || contains(nm,"audit")
        ok = false; return;
    end
    if contains(nm,"residual") && ~(nm == "g_info_resid")
        ok = false; return;
    end
end
end
