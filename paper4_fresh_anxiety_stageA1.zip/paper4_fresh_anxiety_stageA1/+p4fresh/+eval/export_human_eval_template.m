function template = export_human_eval_template(transfer, outFile, maxProfiles, mode)
%EXPORT_HUMAN_EVAL_TEMPLATE Export APF-DS-XAI v8 expert annotation template.
%
% mode:
%   "strict_blind"      : excludes model action and S_* scores. Recommended for gold-label annotation.
%   "blind_with_scores" : includes S_* action scores but excludes model labels/rationales.
%   "review"            : includes model action/rationale for Stage-B explanation review.
%
% No truth, audit, future outcome, or audit residual columns are exported.

if nargin < 3 || isempty(maxProfiles), maxProfiles = 200; end
if nargin < 4 || isempty(mode), mode = "strict_blind"; end
if nargin < 2 || isempty(outFile), outFile = fullfile(pwd, 'apfds_xai_v8_human_eval_template.csv'); end

if ~isstruct(transfer) || ~isfield(transfer, 'deployable_action_table')
    error('export_human_eval_template:MissingActionTable', 'transfer.deployable_action_table is missing.');
end
T = transfer.deployable_action_table;
if ~istable(T) || height(T) == 0
    error('export_human_eval_template:EmptyActionTable', 'transfer.deployable_action_table is empty or not a table.');
end

required = ["profile_id","n_alternatives","B","U","K","C","F","W_tail","G_base","G_support","G_info_core","G_info_resid","G_mechanism_load", ...
    "abs_D_PT","Pol_PT","abs_D_support","Pol_support","primary_action","secondary_flags","primary_rationale","secondary_cautions","top_drivers"];
local_assert_columns(T, required);

if ismember("action_priority", string(T.Properties.VariableNames))
    T = sortrows(T, 'action_priority', 'descend');
end
T = T(1:min(maxProfiles, height(T)), :);

mode = string(mode);
template = table();
template.profile_id = T.profile_id;
template.n_alternatives = T.n_alternatives;
template.B = T.B; template.U = T.U; template.K = T.K; template.C = T.C; template.F = T.F; template.W_tail = T.W_tail;
template.G_base = T.G_base; template.G_support = T.G_support; template.G_info_core = T.G_info_core; template.G_info_resid = T.G_info_resid; template.G_mechanism_load = T.G_mechanism_load;
template.abs_D_PT = T.abs_D_PT; template.Pol_PT = T.Pol_PT; template.abs_D_support = T.abs_D_support; template.Pol_support = T.Pol_support;

if mode == "blind_with_scores" || mode == "review"
    local_assert_columns(T, ["S_info","S_anxiety","S_resilience","S_guardrail","S_capacity","S_communication_burden"]);
    template.S_info = T.S_info; template.S_anxiety = T.S_anxiety; template.S_resilience = T.S_resilience; template.S_guardrail = T.S_guardrail; template.S_capacity = T.S_capacity; template.S_communication_burden = T.S_communication_burden;
end

if mode == "review"
    template.model_primary_action = T.primary_action;
    template.model_secondary_flags = T.secondary_flags;
    template.model_primary_rationale = T.primary_rationale;
    template.model_secondary_cautions = T.secondary_cautions;
    template.model_top_drivers = T.top_drivers;
end

template.expert_id = strings(height(T),1);
template.expert_primary_action = strings(height(T),1);
template.expert_secondary_flags = strings(height(T),1);
template.primary_reason_code = strings(height(T),1);
template.secondary_reason_code = strings(height(T),1);
template.primary_reason_text = strings(height(T),1);
template.expert_confidence_1to5 = NaN(height(T),1);
template.ambiguity_1to5 = NaN(height(T),1);
template.decision_difficulty_1to5 = NaN(height(T),1);
template.need_more_information_yesno = strings(height(T),1);
template.adjudicated_primary_action = strings(height(T),1);
template.adjudication_note = strings(height(T),1);

if mode == "review"
    template.usefulness_1to5 = NaN(height(T),1);
    template.clarity_1to5 = NaN(height(T),1);
    template.trust_1to5 = NaN(height(T),1);
    template.cognitive_load_1to5 = NaN(height(T),1);
end

local_assert_no_template_leakage(template);
writetable(template, outFile);
fprintf('Human/expert evaluation template written to:\n  %s\n', outFile);
end

function local_assert_columns(T, required)
names = string(T.Properties.VariableNames);
missing = required(~ismember(required, names));
if ~isempty(missing)
    error('export_human_eval_template:MissingColumns', 'deployable_action_table is missing columns: %s', strjoin(missing, ', '));
end
end

function local_assert_no_template_leakage(T)
names = lower(string(T.Properties.VariableNames));
for i = 1:numel(names)
    nm = names(i);
    if contains(nm,"truth") || contains(nm,"ground_truth") || contains(nm,"future") || contains(nm,"outcome") || contains(nm,"audit")
        error('export_human_eval_template:LeakageColumnDetected', 'Template contains forbidden leakage column: %s', nm);
    end
    if contains(nm,"residual") && ~(nm == "g_info_resid")
        error('export_human_eval_template:LeakageColumnDetected', 'Template contains forbidden residual column: %s', nm);
    end
end
end
