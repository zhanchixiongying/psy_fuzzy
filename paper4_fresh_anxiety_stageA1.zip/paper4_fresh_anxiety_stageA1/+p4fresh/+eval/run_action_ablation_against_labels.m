function result = run_action_ablation_against_labels(transfer, labelFile, caseId)
%RUN_ACTION_ABLATION_AGAINST_LABELS Evaluate v8 action ablations with expert labels.
%
% A_full uses deployable_action_table directly. Other variants recompute
% primary_action and secondary_flags using the same final-guideline hierarchy
% with one mechanism removed. No truth, audit, residual_calibrated, future
% outcome, or expert label is used to generate actions.

if nargin < 3, caseId = ""; end
if ~isstruct(transfer) || ~isfield(transfer,'deployable_action_table')
    error('run_action_ablation_against_labels:MissingActionTable', 'transfer.deployable_action_table is required.');
end

baseT = transfer.deployable_action_table;
variants = ["A_full";"A_no_psych";"A_no_mechanism_load";"A_no_info";"A_no_resilience";"A_no_guardrail";"A_single_label"];
description = ["Final-guideline full deployable action policy"; ...
    "Remove anxiety mechanism score and anxiety_sensitive flag"; ...
    "Remove only G_mechanism_load contribution inside S_anxiety"; ...
    "Remove information-need score and info flag"; ...
    "Remove resilience score and resilience flag"; ...
    "Remove guardrail score and guardrail flag"; ...
    "Keep final primary action only; remove secondary flags"];

result = table();
for i = 1:numel(variants)
    actionT = local_make_variant_action_table(baseT, variants(i));
    metrics = p4fresh.eval.evaluate_human_labels(actionT, labelFile, caseId);
    row = table(variants(i), description(i), metrics.n_matched, metrics.n_unmatched, ...
        metrics.accuracy, metrics.macro_f1_observed, metrics.macro_f1_5labels, metrics.weighted_f1, ...
        metrics.flag_metrics.micro_f1, metrics.flag_metrics.hamming_accuracy, metrics.flag_metrics.mean_jaccard, ...
        metrics.expert_primary_coverage_rate, metrics.model_primary_coverage_rate, ...
        'VariableNames', {'action_ablation','description','n_evaluated','n_unmatched', ...
        'accuracy','macro_f1_observed','macro_f1_5labels','weighted_f1', ...
        'flag_micro_f1','flag_hamming_accuracy','mean_flag_jaccard', ...
        'expert_primary_coverage_rate','model_primary_coverage_rate'});
    result = [result; row]; %#ok<AGROW>
end

fullWeighted = result.weighted_f1(result.action_ablation == "A_full");
fullMacro = result.macro_f1_5labels(result.action_ablation == "A_full");
fullFlag = result.mean_flag_jaccard(result.action_ablation == "A_full");
if isempty(fullWeighted), fullWeighted = NaN; end
if isempty(fullMacro), fullMacro = NaN; end
if isempty(fullFlag), fullFlag = NaN; end
result.delta_weighted_f1_vs_full = result.weighted_f1 - fullWeighted(1);
result.delta_macro_f1_5labels_vs_full = result.macro_f1_5labels - fullMacro(1);
result.delta_flag_jaccard_vs_full = result.mean_flag_jaccard - fullFlag(1);
end

function T = local_make_variant_action_table(T, variant)
local_assert_action_columns(T);
variant = string(variant);
if variant == "A_full", return; end

S_info = double(T.S_info);
S_anxiety = double(T.S_anxiety);
S_resilience = double(T.S_resilience);
S_guardrail = double(T.S_guardrail);
S_capacity = double(T.S_capacity);

flag_info = logical(T.flag_info);
flag_anxiety = logical(T.flag_anxiety);
flag_resilience = logical(T.flag_resilience);
flag_guardrail = logical(T.flag_guardrail);
flag_capacity = logical(T.flag_capacity);

switch variant
    case "A_no_psych"
        S_anxiety(:) = NaN; flag_anxiety(:) = false;
    case "A_no_mechanism_load"
        % Recomputed below after normalized D/Pol fields are available.
    case "A_no_info"
        S_info(:) = NaN; flag_info(:) = false;
    case "A_no_resilience"
        S_resilience(:) = NaN; flag_resilience(:) = false;
    case "A_no_guardrail"
        S_guardrail(:) = NaN; flag_guardrail(:) = false;
    case "A_single_label"
        flag_info(:) = false; flag_anxiety(:) = false; flag_resilience(:) = false; flag_guardrail(:) = false; flag_capacity(:) = false;
    otherwise
        error('run_action_ablation_against_labels:BadVariant', 'Unknown action ablation: %s', variant);
end

zInfo = local_minmax01(T.G_info_core);
zInfoResidPos = local_minmax01(max(T.G_info_resid,0));
zK = local_minmax01(T.K);
zC = local_minmax01(T.C);
zAbsDsup = local_minmax01(T.abs_D_support);
zPolsup = local_minmax01(T.Pol_support);
zAbsDpt = local_minmax01(T.abs_D_PT);
zF = local_minmax01(T.F);
zW = local_minmax01(T.W_tail);
zBase = local_minmax01(T.G_base);

if variant == "A_no_mechanism_load"
    S_anxiety = local_anxiety_without_mechanism(zAbsDsup, zPolsup, zAbsDpt);
end

primary = local_final_guideline_primary_policy(S_info, S_anxiety, S_resilience, S_guardrail, S_capacity, ...
    zInfo, zInfoResidPos, zK, zC, zAbsDsup, zPolsup, zAbsDpt, zF, zW, zBase);
T.primary_action = primary;

flag_info = flag_info | primary == "Information supplementation";
flag_anxiety = flag_anxiety | primary == "Anxiety-sensitive explanation";
flag_resilience = flag_resilience | primary == "Protective financial resilience communication";
flag_guardrail = flag_guardrail | primary == "Guardrail explanation";
flag_capacity = flag_capacity | primary == "Standard risk-capacity communication";

if variant == "A_no_psych", flag_anxiety(:) = false; end
if variant == "A_no_info", flag_info(:) = false; end
if variant == "A_no_resilience", flag_resilience(:) = false; end
if variant == "A_no_guardrail", flag_guardrail(:) = false; end

flagNames = ["info","anxiety_sensitive","resilience","guardrail","capacity"];
flags = [flag_info, flag_anxiety, flag_resilience, flag_guardrail, flag_capacity];
secondary = strings(height(T),1);
for r = 1:height(T)
    if variant == "A_single_label"
        secondary(r) = "standard";
    else
        fs = flagNames(flags(r,:));
        if isempty(fs), secondary(r) = "standard"; else, secondary(r) = strjoin(fs, ";"); end
    end
end
T.secondary_flags = secondary;
end

function primary_action = local_final_guideline_primary_policy(S_info, S_anxiety, S_resilience, S_guardrail, S_capacity, zInfo, zInfoResidPos, zK, zC, zAbsDsup, zPolsup, zAbsDpt, zF, zW, zBase)
n = numel(S_info);
primary_action = repmat("Standard risk-capacity communication", n, 1);
riskPressure = max(zF, zW);

infoGate = S_info >= local_quantile(S_info, 0.68) & ...
    (zInfo >= local_quantile(zInfo, 0.68) | zInfoResidPos >= local_quantile(zInfoResidPos, 0.68) | ...
     zK >= local_quantile(zK, 0.62) | zC >= local_quantile(zC, 0.70));

anxietyGate = S_anxiety >= local_quantile(S_anxiety, 0.68) & ...
    (zAbsDsup >= local_quantile(zAbsDsup, 0.62) | zPolsup >= local_quantile(zPolsup, 0.62) | ...
     zAbsDpt >= local_quantile(zAbsDpt, 0.62));

guardrailGate = S_guardrail >= local_quantile(S_guardrail, 0.62) & ...
    zBase >= local_quantile(zBase, 0.55) & riskPressure >= local_quantile(riskPressure, 0.55);

resilienceGate = S_resilience >= local_quantile(S_resilience, 0.55) & ...
    (zF >= local_quantile(zF, 0.55) | zW >= local_quantile(zW, 0.55) | zBase <= local_quantile(zBase, 0.40));

primary_action(resilienceGate) = "Protective financial resilience communication";
primary_action(guardrailGate) = "Guardrail explanation";
primary_action(anxietyGate) = "Anxiety-sensitive explanation";
primary_action(infoGate) = "Information supplementation";

capacityGate = S_capacity >= local_quantile(S_capacity, 0.70) & ...
    zBase >= local_quantile(zBase, 0.65) & riskPressure <= local_quantile(riskPressure, 0.55) & ...
    ~infoGate & ~anxietyGate & ~guardrailGate & ~resilienceGate;
primary_action(capacityGate) = "Standard risk-capacity communication";
end

function S = local_anxiety_without_mechanism(zAbsDsup, zPolsup, zAbsDpt)
w = [0.35 0.25 0.15];
w = w ./ sum(w);
S = w(1).*zAbsDsup + w(2).*zPolsup + w(3).*zAbsDpt;
end

function local_assert_action_columns(T)
required = ["profile_id","B","U","K","C","F","W_tail","G_base","G_info_core","G_info_resid","G_mechanism_load", ...
    "abs_D_PT","Pol_PT","abs_D_support","Pol_support", ...
    "S_info","S_anxiety","S_resilience","S_guardrail","S_capacity","S_communication_burden", ...
    "flag_info","flag_anxiety","flag_resilience","flag_guardrail","flag_capacity", ...
    "primary_action","secondary_flags"];
names = string(T.Properties.VariableNames);
missing = required(~ismember(required, names));
if ~isempty(missing)
    error('run_action_ablation_against_labels:MissingColumns', 'deployable_action_table is missing columns: %s', strjoin(missing, ', '));
end
end

function z = local_minmax01(x)
x = double(x(:));
z = zeros(size(x));
mask = isfinite(x);
if ~any(mask), z(:) = 0.5; return; end
lo = min(x(mask)); hi = max(x(mask));
if hi <= lo + eps, z(:) = 0.5; else, z(mask) = (x(mask) - lo) ./ (hi - lo); z(~mask) = 0.5; end
z = min(max(z,0),1);
end

function q = local_quantile(x, p)
x = double(x(:));
x = sort(x(isfinite(x)));
if isempty(x), q = NaN; return; end
p = min(max(double(p),0),1);
pos = 1 + (numel(x)-1)*p;
lo = floor(pos); hi = ceil(pos);
if lo == hi, q = x(lo); else, q = x(lo) + (pos-lo)*(x(hi)-x(lo)); end
end
