function report = validate_expert_annotation_file(labelFile, caseId)
%VALIDATE_EXPERT_ANNOTATION_FILE Validate APF-DS-XAI v8 expert annotation CSV.

if nargin < 2, caseId = ""; end

L0 = local_read_label_table(labelFile);
L = local_filter_case(L0, caseId);

report = struct();
report.label_file = string(labelFile);
report.case_id = string(caseId);
report.n_total = height(L0);
report.n_after_case_filter = height(L);
report.required_columns_present = false;
report.no_forbidden_leakage_columns = false;
report.primary_labels_valid = false;
report.secondary_flags_valid = true;
report.ratings_valid = true;
report.split_valid = true;
report.is_ready_for_evaluation = false;
report.errors = strings(0,1);
report.warnings = strings(0,1);
report.n_labeled = 0;

names = string(L.Properties.VariableNames);
required = ["profile_id","expert_primary_action"];
missing = required(~ismember(required, names));
if isempty(missing), report.required_columns_present = true;
else, report.errors(end+1,1) = "Missing required columns: " + strjoin(missing, ", "); end

[leakOk, leakBad] = local_check_leakage(names);
report.no_forbidden_leakage_columns = leakOk;
if ~leakOk, report.errors(end+1,1) = "Forbidden leakage columns: " + strjoin(leakBad, ", "); end

if height(L) == 0
    report.errors(end+1,1) = "No rows after case_id filtering.";
    report.n_labeled = 0;
    report.primary_distribution = table();
else
    if report.required_columns_present
        y = local_canonical_primary(L.expert_primary_action);
        allowed = local_primary_labels();
        nonEmpty = strlength(y) > 0 & ~ismissing(y);
        badY = unique(y(nonEmpty & ~ismember(y, allowed)));
        report.n_labeled = sum(nonEmpty);
        report.primary_labels_valid = isempty(badY) && report.n_labeled > 0;
        if ~isempty(badY), report.errors(end+1,1) = "Invalid expert_primary_action values: " + strjoin(badY, ", "); end
        if report.n_labeled == 0, report.errors(end+1,1) = "No non-empty expert_primary_action values."; end
        report.primary_distribution = local_primary_distribution(y);
    else
        report.n_labeled = 0;
        report.primary_distribution = table();
    end

    if ismember("expert_secondary_flags", names)
        [flagOk, badFlagTable] = local_validate_flags(L.expert_secondary_flags);
        report.secondary_flags_valid = flagOk;
        report.bad_flag_rows = badFlagTable;
        if ~flagOk, report.errors(end+1,1) = "Invalid expert_secondary_flags detected. See bad_flag_rows."; end
        report.flag_distribution = local_flag_distribution(L.expert_secondary_flags);
    else
        report.secondary_flags_valid = true;
        report.bad_flag_rows = table();
        report.flag_distribution = table();
        report.warnings(end+1,1) = "expert_secondary_flags column is missing; flag metrics will be skipped.";
    end

    ratingNames = ["expert_confidence_1to5","ambiguity_1to5","decision_difficulty_1to5","usefulness_1to5","clarity_1to5","trust_1to5","cognitive_load_1to5"];
    badRating = strings(0,1);
    for i = 1:numel(ratingNames)
        nm = ratingNames(i);
        if ismember(nm, names)
            x = double(L.(nm));
            mask = isfinite(x);
            if any(x(mask) < 1 | x(mask) > 5), badRating(end+1,1) = nm; end %#ok<AGROW>
        end
    end
    report.ratings_valid = isempty(badRating);
    if ~report.ratings_valid, report.errors(end+1,1) = "1-5 rating columns out of range: " + strjoin(badRating, ", "); end

    if ismember("split", names)
        s = lower(strtrim(string(L.split)));
        badSplit = unique(s(strlength(s)>0 & ~ismember(s, ["train","validation","val","dev","test"])));
        report.split_valid = isempty(badSplit);
        if ~report.split_valid, report.errors(end+1,1) = "Invalid split values: " + strjoin(badSplit, ", "); end
        report.split_distribution = local_split_distribution(s);
    else
        report.split_distribution = table();
        report.warnings(end+1,1) = "split column is missing; supervised baseline will use deterministic CV.";
    end
end

report.is_ready_for_evaluation = report.required_columns_present && report.no_forbidden_leakage_columns && ...
    report.primary_labels_valid && report.secondary_flags_valid && report.ratings_valid && report.split_valid;

report.summary_table = table(string(labelFile), string(caseId), report.n_total, report.n_after_case_filter, ...
    report.n_labeled, report.required_columns_present, report.no_forbidden_leakage_columns, ...
    report.primary_labels_valid, report.secondary_flags_valid, report.ratings_valid, ...
    report.split_valid, report.is_ready_for_evaluation, ...
    'VariableNames', {'label_file','case_id','n_total','n_after_case_filter','n_labeled', ...
    'required_columns_present','no_forbidden_leakage_columns','primary_labels_valid', ...
    'secondary_flags_valid','ratings_valid','split_valid','is_ready_for_evaluation'});
end

function L = local_read_label_table(labelFile)
try, L = readtable(labelFile, 'VariableNamingRule','preserve', 'TextType','string');
catch, L = readtable(labelFile, 'VariableNamingRule','preserve'); end
end

function L = local_filter_case(L, caseId)
caseId = string(caseId);
if strlength(caseId) > 0 && ismember("case_id", string(L.Properties.VariableNames))
    L = L(string(L.case_id) == caseId, :);
end
end

function [ok,bad] = local_check_leakage(names)
names = lower(string(names(:)));
bad = strings(0,1);
for i = 1:numel(names)
    nm = names(i);
    if contains(nm,"ground_truth") || contains(nm,"future") || contains(nm,"outcome") || contains(nm,"audit")
        bad(end+1,1) = nm; %#ok<AGROW>
    elseif contains(nm,"truth") && ~(nm == "truthiness")
        bad(end+1,1) = nm; %#ok<AGROW>
    elseif contains(nm,"residual") && ~(nm == "g_info_resid")
        bad(end+1,1) = nm; %#ok<AGROW>
    end
end
ok = isempty(bad);
end

function T = local_primary_distribution(y)
labels = local_primary_labels();
count = zeros(numel(labels),1);
for i = 1:numel(labels), count(i) = sum(y == labels(i)); end
rate = count ./ max(sum(count),1);
T = table(labels, count, rate, 'VariableNames', {'expert_primary_action','count','rate'});
end

function [ok,badT] = local_validate_flags(S)
allowed = ["info","anxiety_sensitive","resilience","guardrail","capacity","standard"];
row = zeros(0,1); bad_value = strings(0,1);
S = string(S(:));
for i = 1:numel(S)
    parts = local_split_flags(S(i));
    bad = parts(~ismember(parts, allowed));
    if ~isempty(bad)
        row(end+1,1) = i; %#ok<AGROW>
        bad_value(end+1,1) = strjoin(bad, ";"); %#ok<AGROW>
    end
end
badT = table(row, bad_value);
ok = height(badT) == 0;
end

function T = local_flag_distribution(S)
flags = ["info";"anxiety_sensitive";"resilience";"guardrail";"capacity";"standard"];
count = zeros(numel(flags),1);
for i = 1:numel(S)
    parts = local_split_flags(S(i));
    for j = 1:numel(flags)
        if any(parts == flags(j)), count(j) = count(j) + 1; end
    end
end
rate = count ./ max(numel(S),1);
T = table(flags, count, rate, 'VariableNames', {'flag','count','rate'});
end

function parts = local_split_flags(s)
s = lower(strtrim(string(s)));
s = replace(s, ",", ";");
s = replace(s, " ", "_");
if ismissing(s) || strlength(s) == 0, parts = strings(0,1); return; end
parts = split(s, ";");
parts = strtrim(parts);
parts = parts(strlength(parts)>0);
end

function T = local_split_distribution(s)
s = string(s(:));
u = unique(s(strlength(s)>0), 'stable');
count = zeros(numel(u),1);
for i = 1:numel(u), count(i) = sum(s == u(i)); end
rate = count ./ max(sum(count),1);
T = table(u, count, rate, 'VariableNames', {'split','count','rate'});
end

function labels = local_primary_labels()
labels = ["Information supplementation";"Anxiety-sensitive explanation";"Protective financial resilience communication";"Guardrail explanation";"Standard risk-capacity communication"];
end

function y = local_canonical_primary(x)
s = lower(strtrim(string(x(:))));
s = replace(s, "_", " "); s = replace(s, "-", " ");
y = strings(size(s));
for i = 1:numel(s)
    si = s(i);
    if ismissing(si) || strlength(si) == 0, y(i) = "";
    elseif contains(si, "information") || strcmp(si, "info"), y(i) = "Information supplementation";
    elseif contains(si, "anxiety"), y(i) = "Anxiety-sensitive explanation";
    elseif contains(si, "protective") || contains(si, "resilience"), y(i) = "Protective financial resilience communication";
    elseif contains(si, "guardrail"), y(i) = "Guardrail explanation";
    elseif contains(si, "standard") || contains(si, "capacity"), y(i) = "Standard risk-capacity communication";
    else, y(i) = string(x(i)); end
end
end
