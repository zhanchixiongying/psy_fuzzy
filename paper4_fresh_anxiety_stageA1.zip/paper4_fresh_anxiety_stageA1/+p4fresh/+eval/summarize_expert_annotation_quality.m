function summary = summarize_expert_annotation_quality(labelFile, outDir)
%SUMMARIZE_EXPERT_ANNOTATION_QUALITY Summarize v8 expert annotation CSV.

if nargin < 2, outDir = ""; end

try, L = readtable(labelFile, 'VariableNamingRule','preserve', 'TextType','string');
catch, L = readtable(labelFile, 'VariableNamingRule','preserve'); end

if ~ismember("case_id", string(L.Properties.VariableNames)), L.case_id = repmat("ALL", height(L), 1); end
if ~ismember("split", string(L.Properties.VariableNames)), L.split = repmat("", height(L), 1); end
L.expert_primary_action = local_canonical_primary(L.expert_primary_action);

summary = struct();
summary.label_file = string(labelFile);
summary.n = height(L);
summary.by_case = local_count_by_group(L, "case_id");
summary.by_split = local_count_by_group(L, "split");
summary.primary_by_case = local_primary_by_group(L, "case_id");
summary.primary_by_split = local_primary_by_group(L, "split");
summary.primary_by_case_split = local_primary_by_case_split(L);
summary.flag_distribution = local_flag_distribution(L);
summary.rating_summary = local_rating_summary(L);
summary.validation_report = p4fresh.eval.validate_expert_annotation_file(labelFile);

if strlength(string(outDir)) > 0
    if ~exist(outDir, 'dir'), mkdir(outDir); end
    local_write(summary.by_case, fullfile(outDir, 'annotation_by_case.csv'));
    local_write(summary.by_split, fullfile(outDir, 'annotation_by_split.csv'));
    local_write(summary.primary_by_case, fullfile(outDir, 'annotation_primary_by_case.csv'));
    local_write(summary.primary_by_split, fullfile(outDir, 'annotation_primary_by_split.csv'));
    local_write(summary.primary_by_case_split, fullfile(outDir, 'annotation_primary_by_case_split.csv'));
    local_write(summary.flag_distribution, fullfile(outDir, 'annotation_flag_distribution.csv'));
    local_write(summary.rating_summary, fullfile(outDir, 'annotation_rating_summary.csv'));
    local_write(summary.validation_report.summary_table, fullfile(outDir, 'annotation_validation_summary.csv'));
end
end

function local_write(T, fp)
if istable(T), writetable(T, fp); end
end

function T = local_count_by_group(L, groupName)
g = string(L.(groupName));
u = unique(g, 'stable');
count = zeros(numel(u),1);
for i = 1:numel(u), count(i) = sum(g == u(i)); end
rate = count ./ max(sum(count),1);
T = table(u, count, rate, 'VariableNames', {char(groupName),'count','rate'});
end

function T = local_primary_by_group(L, groupName)
labels = local_primary_labels();
groups = unique(string(L.(groupName)), 'stable');
T = table();
for g = 1:numel(groups)
    hit = string(L.(groupName)) == groups(g);
    y = string(L.expert_primary_action(hit));
    for j = 1:numel(labels)
        count = sum(y == labels(j));
        rate = count ./ max(sum(hit),1);
        row = table(groups(g), labels(j), count, rate, 'VariableNames', {char(groupName),'expert_primary_action','count','rate'});
        T = [T; row]; %#ok<AGROW>
    end
end
end

function T = local_primary_by_case_split(L)
labels = local_primary_labels();
cases = unique(string(L.case_id), 'stable');
splits = unique(string(L.split), 'stable');
T = table();
for c = 1:numel(cases)
    for s = 1:numel(splits)
        hit = string(L.case_id)==cases(c) & string(L.split)==splits(s);
        if ~any(hit), continue; end
        y = string(L.expert_primary_action(hit));
        for j = 1:numel(labels)
            count = sum(y == labels(j));
            rate = count ./ max(sum(hit),1);
            row = table(cases(c), splits(s), labels(j), count, rate, ...
                'VariableNames', {'case_id','split','expert_primary_action','count','rate'});
            T = [T; row]; %#ok<AGROW>
        end
    end
end
end

function T = local_flag_distribution(L)
flags = ["info";"anxiety_sensitive";"resilience";"guardrail";"capacity";"standard"];
count = zeros(numel(flags),1);
if ~ismember("expert_secondary_flags", string(L.Properties.VariableNames))
    T = table(flags, count, count, 'VariableNames', {'flag','count','rate'});
    return;
end
S = string(L.expert_secondary_flags);
for i = 1:numel(S)
    parts = local_split_flags(S(i));
    for j = 1:numel(flags)
        if any(parts == flags(j)), count(j) = count(j) + 1; end
    end
end
rate = count ./ max(height(L),1);
T = table(flags, count, rate, 'VariableNames', {'flag','count','rate'});
end

function T = local_rating_summary(L)
ratingNames = ["expert_confidence_1to5","ambiguity_1to5","decision_difficulty_1to5","usefulness_1to5","clarity_1to5","trust_1to5","cognitive_load_1to5"];
field = strings(0,1); n = zeros(0,1); mean_value = zeros(0,1); sd_value = zeros(0,1);
names = string(L.Properties.VariableNames);
for i = 1:numel(ratingNames)
    nm = ratingNames(i);
    if ismember(nm, names)
        x = double(L.(nm));
        field(end+1,1) = nm; %#ok<AGROW>
        n(end+1,1) = sum(isfinite(x)); %#ok<AGROW>
        mean_value(end+1,1) = mean(x,'omitnan'); %#ok<AGROW>
        sd_value(end+1,1) = std(x,'omitnan'); %#ok<AGROW>
    end
end
T = table(field, n, mean_value, sd_value);
end

function parts = local_split_flags(s)
s = lower(strtrim(string(s)));
s = replace(s, ",", ";");
s = replace(s, " ", "_");
if ismissing(s) || strlength(s) == 0, parts = strings(0,1); else
    parts = split(s, ";");
    parts = strtrim(parts);
    parts = parts(strlength(parts)>0);
end
end

function labels = local_primary_labels()
labels = ["Information supplementation";"Anxiety-sensitive explanation";"Protective financial resilience communication";"Guardrail explanation";"Standard risk-capacity communication"];
end

function y = local_canonical_primary(x)
s = lower(strtrim(string(x(:))));
s = replace(s, "_", " "); s = replace(s, "-", " ");
y = strings(size(s));
for i = 1:numel(s)
    si = s(i);
    if ismissing(si) || strlength(si) == 0, y(i) = "";
    elseif contains(si, "information") || strcmp(si, "info"), y(i) = "Information supplementation";
    elseif contains(si, "anxiety"), y(i) = "Anxiety-sensitive explanation";
    elseif contains(si, "protective") || contains(si, "resilience"), y(i) = "Protective financial resilience communication";
    elseif contains(si, "guardrail"), y(i) = "Guardrail explanation";
    elseif contains(si, "standard") || contains(si, "capacity"), y(i) = "Standard risk-capacity communication";
    else, y(i) = string(x(i)); end
end
end
