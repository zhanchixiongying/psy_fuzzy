function bootT = run_profile_bootstrap_ci(transfer, fuzzy_case, nReps, seed)
%RUN_PROFILE_BOOTSTRAP_CI Profile/cluster bootstrap CI with replicate weights.
%
% Duplicate profile draws are preserved. This is not a boolean keep/drop
% bootstrap.

if nargin < 3 || isempty(nReps), nReps = 200; end
if nargin < 4 || isempty(seed), seed = 20261001; end
rng(seed);

pid = string(fuzzy_case.profile_id(:));
[G, profiles] = findgroups(pid); %#ok<ASGLU>
baseW = double(fuzzy_case.case_weight(:));
truth = double(fuzzy_case.ground_truth(:));

scoreNames = ["G_base";"G_support";"G_action_priority"];
scores = {transfer.G_base(:), transfer.G_support(:), transfer.G_action_priority(:)};

nP = numel(profiles);
bootT = table();
for s = 1:numel(scoreNames)
    score = double(scores{s});
    vals = NaN(nReps,2);
    for b = 1:nReps
        drawIdx = randi(nP, nP, 1);
        replicateCount = accumarray(drawIdx, 1, [nP,1], @sum, 0);
        repW = baseW .* replicateCount(G);
        vals(b,1) = local_weighted_spearman(score, truth, repW);
        vals(b,2) = local_weighted_top_bottom_gap(score, truth, repW);
    end
    sp = vals(:,1); gap = vals(:,2);
    row = table(scoreNames(s), mean(sp,'omitnan'), local_quantile(sp,0.025), local_quantile(sp,0.975), ...
        mean(gap,'omitnan'), local_quantile(gap,0.025), local_quantile(gap,0.975), ...
        'VariableNames', {'score','weighted_spearman_mean','weighted_spearman_ci_low','weighted_spearman_ci_high','weighted_gap_mean','weighted_gap_ci_low','weighted_gap_ci_high'});
    bootT = [bootT; row]; %#ok<AGROW>
end
end

function rho = local_weighted_spearman(x,y,w)
rho = local_weighted_corr(local_tied_rank(x), local_tied_rank(y), w);
end

function gap = local_weighted_top_bottom_gap(s,y,w)
s = double(s(:)); y = double(y(:)); w = double(w(:));
mask = isfinite(s) & isfinite(y) & isfinite(w) & w > 0;
s = s(mask); y = y(mask); w = w(mask);
if numel(s) < 3, gap = NaN; return; end
[~,ord] = sort(s,'descend');
n = numel(ord); k = max(1,ceil(.10*n));
gap = local_wmean(y(ord(1:k)),w(ord(1:k))) - local_wmean(y(ord(n-k+1:n)),w(ord(n-k+1:n)));
end

function m = local_wmean(x,w)
mask = isfinite(x) & isfinite(w) & w > 0;
if ~any(mask), m = NaN; else, m = sum(x(mask).*w(mask)) ./ sum(w(mask)); end
end

function r = local_tied_rank(x)
x = double(x(:)); r = NaN(size(x)); [sx,idx] = sort(x); n = numel(x); i = 1;
while i <= n
    if ~isfinite(sx(i)), i = i + 1; continue; end
    j = i;
    while j < n && sx(j+1) == sx(i), j = j + 1; end
    r(idx(i:j)) = (i+j)/2;
    i = j + 1;
end
end

function r = local_weighted_corr(x,y,w)
x = double(x(:)); y = double(y(:)); w = double(w(:));
mask = isfinite(x)&isfinite(y)&isfinite(w)&w>0;
x=x(mask); y=y(mask); w=w(mask);
if numel(x)<3, r=NaN; return; end
w=w/sum(w); mx=sum(w.*x); my=sum(w.*y);
vx=sum(w.*(x-mx).^2); vy=sum(w.*(y-my).^2);
if vx<=eps || vy<=eps, r=NaN; else, r=sum(w.*(x-mx).*(y-my))/sqrt(vx*vy); end
end

function q = local_quantile(x,p)
x = sort(double(x(:))); x = x(isfinite(x));
if isempty(x), q=NaN; return; end
p = min(max(p,0),1); pos=1+(numel(x)-1)*p; lo=floor(pos); hi=ceil(pos);
if lo==hi, q=x(lo); else, q=x(lo)+(pos-lo)*(x(hi)-x(lo)); end
end
