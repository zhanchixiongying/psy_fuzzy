function files = split_combined_expert_annotations(labelFile, outDir)
%SPLIT_COMBINED_EXPERT_ANNOTATIONS Split combined expert-label CSV by case_id.

if nargin < 2 || isempty(outDir), outDir = fileparts(labelFile); end
if ~exist(outDir, 'dir'), mkdir(outDir); end

try, L = readtable(labelFile, 'VariableNamingRule','preserve', 'TextType','string');
catch, L = readtable(labelFile, 'VariableNamingRule','preserve'); end

if ~ismember("case_id", string(L.Properties.VariableNames))
    error('split_combined_expert_annotations:MissingCaseId', 'Combined label file must contain case_id.');
end

cases = unique(string(L.case_id), 'stable');
files = strings(numel(cases),1);
for i = 1:numel(cases)
    caseId = cases(i);
    T = L(string(L.case_id) == caseId, :);
    safe = regexprep(caseId, '[^A-Za-z0-9_\-]', '_');
    fp = fullfile(outDir, char(safe + "_expert_labels.csv"));
    writetable(T, fp);
    files(i) = string(fp);
end
end
