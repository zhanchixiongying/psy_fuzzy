OpenNeuro ds000030 repaired starter

This folder stores the starter files used by build_demo_dataset.m.

Included public-data starter tables:
- participants_ds000030_bart_matched.tsv
- events_ds000030_sub-10227_bart_matched.tsv

Important repair logic now lives in build_demo_dataset.m, not in the TSV.
If the TSV already contains earlier proxy columns, the loader recomputes the
analysis-critical fields from the raw BART decision columns to avoid future-
outcome leakage and random transfer behavior.
