function prepare_all_ds000030_bart_events(cfg)
% Download phenotype tables and as many ds000030 BART event files as possible
% into the configured OpenNeuro data directory. Names are kept compatible
% with p4fresh.io.build_demo_dataset.

if nargin < 1 || isempty(cfg)
    cfg = p4fresh.config.default_config();
end

dataDir = char(cfg.openneuro.data_dir);
if ~exist(dataDir, 'dir')
    mkdir(dataDir);
end

% Reuse the build loader helpers by calling the loader once after enabling fetch.
oldFlag = cfg.openneuro.auto_fetch_missing_events;
cfg.openneuro.auto_fetch_missing_events = true;
try
    p4fresh.io.build_demo_dataset(cfg); %#ok<NASGU>
catch ME
    fprintf('prepare_all_ds000030_bart_events: %s\n', ME.message);
end
cfg.openneuro.auto_fetch_missing_events = oldFlag;
end
