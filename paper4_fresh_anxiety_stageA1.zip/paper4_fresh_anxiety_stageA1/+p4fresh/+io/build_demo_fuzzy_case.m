function fuzzy_cases = build_demo_fuzzy_case(subjects, cfg, trialT)
%BUILD_DEMO_FUZZY_CASE Build FINRA/SCF/SHED B/U/K/C/F/W_tail fuzzy cases.
%
% v8 financial evidence layers:
%   B = benefit evidence
%   U = cost/loss evidence
%   K = low-clarity / complexity / missingness proxy
%   C = change / shock proxy
%   F = financial fragility proxy
%   W_tail = eta*max(U,K,C,F) + (1-eta)*mean(U,K,C,F)
%
% K is not direct ambiguity aversion. It is a low-clarity proxy.

if nargin < 3
    trialT = table(); %#ok<NASGU>
end
if nargin < 2 || isempty(cfg)
    cfg = p4fresh.config.default_config();
end

nS = numel(subjects);
if nS <= 0
    error('build_demo_fuzzy_case:NoSubjects', 'subjects is empty.');
end

dataDir = cfg.financial_fuzzy.data_dir;
unifiedFiles = p4fresh.io.prepare_financial_fuzzy_unified(dataDir, cfg);

caseList = cell(numel(unifiedFiles),1);
for c = 1:numel(unifiedFiles)
    Utab = local_readtable_robust(unifiedFiles(c));
    Utab = local_apply_max_alternatives(Utab, cfg);
    caseList{c} = local_build_case_from_unified(Utab, nS, cfg);
end
fuzzy_cases = [caseList{:}]';
end

function fc = local_build_case_from_unified(T, nS, cfg)
m = height(T);
Bcrit = local_clip01(double([T.B_capability, T.B_liquidity, T.B_experience, T.B_knowledge, T.B_stability]));
Ucrit = local_clip01(double([T.U_debt, T.U_fragility, T.U_low_resilience, T.U_anxiety, T.U_complexity]));
Bcrit = local_impute_columns(Bcrit);
Ucrit = local_impute_columns(Ucrit);

wB = [0.24 0.22 0.18 0.18 0.18];
wU = [0.22 0.23 0.20 0.23 0.12];

baseB = Bcrit * wB(:);
baseU = Ucrit * wU(:);

rowDisp = local_minmax(local_row_std([Bcrit, Ucrit]));
if ismember('A_missingness', string(T.Properties.VariableNames))
    missProxy = local_clip01(double(T.A_missingness));
else
    missProxy = zeros(m,1);
end

% K: low-clarity/complexity/missingness proxy, not direct ambiguity.
baseK = local_clip01(0.45 .* T.U_complexity + 0.25 .* rowDisp + 0.30 .* missProxy);

% C: explicit change/shock proxy where available; otherwise stability deterioration proxy.
baseC = local_clip01(0.55 .* (1 - T.B_stability) + 0.25 .* T.U_fragility + 0.20 .* T.U_anxiety);

% F: financial fragility/resilience pressure, separated from C.
baseF = local_clip01(0.35 .* T.U_fragility + 0.35 .* T.U_low_resilience + 0.30 .* T.U_debt);

eta = 0.65;
if isfield(cfg,'transfer') && isfield(cfg.transfer,'tail') && isfield(cfg.transfer.tail,'eta_max')
    eta = double(cfg.transfer.tail.eta_max);
end
R = [baseU(:), baseK(:), baseC(:), baseF(:)];
baseW = local_clip01(eta .* max(R, [], 2) + (1-eta) .* mean(R, 2, 'omitnan'));

B = repmat(baseB(:)', nS, 1);
U = repmat(baseU(:)', nS, 1);
K = repmat(baseK(:)', nS, 1);
C = repmat(baseC(:)', nS, 1);
F = repmat(baseF(:)', nS, 1);
Wtail = repmat(baseW(:)', nS, 1);

baseScore = local_clip(baseB(:) - baseU(:), -2, 2);

omega = ones(nS,1) / nS;
profileId = local_profile_id(baseB, baseU, baseK, baseC, baseF, cfg);
profile = local_make_profile_struct(profileId, T, baseB, baseU, baseK, baseC, baseF, baseW, baseScore);

fc = struct();
fc.case_id = string(T.source_id(1));
fc.source_name = string(T.source_name(1));
fc.task_label = string(T.task_label(1));
fc.ground_truth_label = string(T.ground_truth_label(1));
fc.alternative_names = string(T.alternative_id(:));
fc.profile_id = profileId(:);

fc.criteria = ["B_benefit";"U_loss_cost";"K_low_clarity";"C_change_shock";"F_fragility";"W_tail"];
fc.B = double(B);
fc.U = double(U);
fc.K = double(K);
fc.C = double(C);
fc.F = double(F);
fc.W_tail = double(Wtail);

fc.B_alt = double(baseB(:));
fc.U_alt = double(baseU(:));
fc.K_alt = double(baseK(:));
fc.C_alt = double(baseC(:));
fc.F_alt = double(baseF(:));
fc.W_tail_alt = double(baseW(:));

fc.omega = omega;
fc.ground_truth = double(T.ground_truth(:));
fc.baseline_score = double(baseScore(:));
fc.case_weight = double(T.case_weight(:));
fc.profile = profile;
fc.is_public_fuzzy_case = true;
fc.financial_schema_version = "financial_BUKCFWtail_schema_apfds_xai_v8";
fc.K_label = "low_clarity_complexity_missingness_proxy_not_direct_ambiguity";
fc.W_tail_label = "tail_risk_proxy_eta_max_plus_mean_not_direct_CVaR_estimate";
fc.transform_note = "B/U/K/C/F/W_tail are built from financial survey evidence only; K is low-clarity proxy; W_tail is tail-risk proxy; ground_truth is held out for validation/audit and is never used by deployable actions.";
end


function profile = local_make_profile_struct(pid, T, B,U,K,C,F,W,baseScore)
pid = string(pid(:));
[G, keys] = findgroups(pid);
nP = numel(keys);
profile = struct();
profile.profile_id = keys;
profile.n_alternatives = splitapply(@numel, pid, G);
profile.weight_sum = splitapply(@local_sum_omitnan, double(T.case_weight(:)), G);
profile.truth_mean = splitapply(@local_weighted_mean_pair, double(T.ground_truth(:)), double(T.case_weight(:)), G);
profile.truth_var = splitapply(@local_var_omitnan, double(T.ground_truth(:)), G);
profile.truth_label = repmat(string(T.ground_truth_label(1)), nP, 1);
profile.B = splitapply(@local_mean_omitnan, B(:), G);
profile.U = splitapply(@local_mean_omitnan, U(:), G);
profile.K = splitapply(@local_mean_omitnan, K(:), G);
profile.C = splitapply(@local_mean_omitnan, C(:), G);
profile.F = splitapply(@local_mean_omitnan, F(:), G);
profile.W_tail = splitapply(@local_mean_omitnan, W(:), G);
profile.G_base = splitapply(@local_mean_omitnan, baseScore(:), G);
PT = table();
PT.profile_id = profile.profile_id;
PT.n_alternatives = profile.n_alternatives;
PT.weight_sum = profile.weight_sum;
PT.truth_mean = profile.truth_mean;
PT.truth_var = profile.truth_var;
PT.B = profile.B;
PT.U = profile.U;
PT.K = profile.K;
PT.C = profile.C;
PT.F = profile.F;
PT.W_tail = profile.W_tail;
PT.G_base = profile.G_base;
profile.table = PT;
end

function y = local_weighted_mean_pair(x,w)
x = double(x(:)); w = double(w(:));
mask = isfinite(x) & isfinite(w) & w > 0;
if ~any(mask), y = NaN; else, y = sum(x(mask).*w(mask)) ./ sum(w(mask)); end
end

function profileId = local_profile_id(B,U,K,C,F,cfg)
prec = 3;
if isfield(cfg,'financial_fuzzy') && isfield(cfg.financial_fuzzy,'profile_precision')
    prec = cfg.financial_fuzzy.profile_precision;
end
X = round([B(:),U(:),K(:),C(:),F(:)] .* 10^prec) ./ 10^prec;
profileId = strings(size(X,1),1);
for i = 1:size(X,1)
    profileId(i) = sprintf('P_%.*f_%.*f_%.*f_%.*f_%.*f', prec,X(i,1),prec,X(i,2),prec,X(i,3),prec,X(i,4),prec,X(i,5));
end
end


function s = local_sum_omitnan(x)
x = double(x(:)); x = x(isfinite(x));
if isempty(x), s = NaN; else, s = sum(x); end
end

function v = local_var_omitnan(x)
x = double(x(:)); x = x(isfinite(x));
if numel(x) <= 1, v = NaN; else, v = var(x,0); end
end

function m = local_mean_omitnan(x)
x = double(x(:)); x = x(isfinite(x));
if isempty(x), m = NaN; else, m = mean(x); end
end

function T = local_apply_max_alternatives(T, cfg)
maxAlt = inf;
if isfield(cfg,'financial_fuzzy') && isfield(cfg.financial_fuzzy,'max_alternatives_per_case')
    maxAlt = double(cfg.financial_fuzzy.max_alternatives_per_case);
end
if isfinite(maxAlt) && maxAlt > 0 && height(T) > maxAlt
    idx = unique(round(linspace(1,height(T),maxAlt)));
    T = T(idx,:);
end
end

function T = local_readtable_robust(fp)
try
    T = readtable(fp, 'VariableNamingRule','preserve', 'TextType','string');
catch
    T = readtable(fp, 'VariableNamingRule','preserve');
end
end

function X = local_impute_columns(X)
X = double(X);
for j = 1:size(X,2)
    x = X(:,j);
    fill = median(x(isfinite(x)), 'omitnan');
    if ~isfinite(fill), fill = 0.5; end
    x(~isfinite(x)) = fill;
    X(:,j) = local_clip01(x);
end
end

function s = local_row_std(X)
X = double(X);
s = zeros(size(X,1),1);
for i = 1:size(X,1)
    row = X(i,:);
    row = row(isfinite(row));
    if numel(row) > 1, s(i) = std(row); end
end
end

function z = local_minmax(x)
x = double(x(:));
z = zeros(size(x));
mask = isfinite(x);
if ~any(mask), z(:) = 0.5; return; end
lo = min(x(mask)); hi = max(x(mask));
if hi <= lo + eps, z(:) = 0.5; else, z(mask) = (x(mask)-lo)./(hi-lo); z(~mask)=0.5; end
z = local_clip01(z);
end

function x = local_clip01(x)
x = local_clip(x,0,1);
end

function x = local_clip(x,lo,hi)
x = min(max(double(x),lo),hi);
end
