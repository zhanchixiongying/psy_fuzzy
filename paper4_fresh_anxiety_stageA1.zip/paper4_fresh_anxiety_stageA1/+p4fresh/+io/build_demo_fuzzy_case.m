function fuzzy_cases = build_demo_fuzzy_case(subjects, cfg, trialT)
%BUILD_DEMO_FUZZY_CASE Build local public fuzzy/ranking-transfer cases.
%
% Keep the original package function name and interface:
%     p4fresh.io.build_demo_fuzzy_case(subjects, cfg, trialT)
%
% This corrected version is written for the current three local public
% datasets only:
%   1) UCI_AIR_QUALITY
%      +io/public_fuzzy_data/AirQualityUCI.xlsx
%   2) UCI_CCPP_POWER_PLANT
%      +io/public_fuzzy_data/Folds5x2_pp.xlsx
%   3) UCI_REAL_ESTATE_VALUATION
%      +io/public_fuzzy_data/Real estate valuation data set.xlsx
%
% Important design choices for paper/reviewer reproducibility:
%   - No internet download is performed here.
%   - The target/ground-truth column is never used to construct B or U.
%   - B and U are constructed from multi-criterion public feature evidence.
%   - Subject-specific criterion weights are generated from available subject
%     trait features, so downstream transfer is not mechanically identical
%     to the feature-only baseline.
%   - baseline_score remains a neutral feature-only aggregation.
%
% Output contract required by +fuzzy/run_transfer.m:
%   fuzzy_case.case_id              starts with UCI_
%   fuzzy_case.alternative_names    nAlternatives x 1 string
%   fuzzy_case.B                    nSubjects x nAlternatives, in [0,1]
%   fuzzy_case.U                    nSubjects x nAlternatives, in [0,1]
%   fuzzy_case.omega                nSubjects x 1 group weights
%   fuzzy_case.ground_truth         nAlternatives x 1 numeric target
%   fuzzy_case.ground_truth_label   text target description
%   fuzzy_case.baseline_score       nAlternatives x 1 feature-only score

%#ok<*INUSD>
if nargin < 3
    trialT = table(); %#ok<NASGU>
end

nS = numel(subjects);
if nS <= 0
    error('build_demo_fuzzy_case:NoSubjects', ...
        'subjects is empty. Public fuzzy transfer requires subject-by-alternative B/U matrices.');
end

ioDir = fileparts(mfilename('fullpath'));
dataDir = fullfile(ioDir, 'public_fuzzy_data');

files = struct();
files.air = fullfile(dataDir, 'AirQualityUCI.xlsx');
files.ccpp = fullfile(dataDir, 'Folds5x2_pp.xlsx');
files.realestate = fullfile(dataDir, 'Real estate valuation data set.xlsx');

local_require_file(files.air, ...
    'UCI_AIR_QUALITY', ...
    'https://archive.ics.uci.edu/static/public/360/air+quality.zip', ...
    dataDir);
local_require_file(files.ccpp, ...
    'UCI_CCPP_POWER_PLANT', ...
    'https://archive.ics.uci.edu/static/public/294/combined+cycle+power+plant.zip', ...
    dataDir);
local_require_file(files.realestate, ...
    'UCI_REAL_ESTATE_VALUATION', ...
    'https://archive.ics.uci.edu/static/public/477/real+estate+valuation+data+set.zip', ...
    dataDir);

profiles = local_subject_profiles(subjects, trialT);

caseList = cell(3, 1);
caseList{1} = local_build_air_quality_case(files.air, subjects, cfg, profiles);
caseList{2} = local_build_ccpp_case(files.ccpp, subjects, cfg, profiles);
caseList{3} = local_build_real_estate_case(files.realestate, subjects, cfg, profiles);

fuzzy_cases = [caseList{:}]';
end

% =========================================================================
% Case 1: UCI Air Quality
% =========================================================================

function fuzzy_case = local_build_air_quality_case(fp, subjects, cfg, profiles)
T = local_readtable(fp);

% UCI Air Quality columns are typically:
% Date, Time, CO(GT), PT08.S1(CO), NMHC(GT), C6H6(GT), PT08.S2(NMHC),
% NOx(GT), PT08.S3(NOx), NO2(GT), PT08.S4(NO2), PT08.S5(O3), T, RH, AH.
% C6H6(GT) is reserved as ground truth only.

y    = local_get_numeric_column(T, {'C6H6(GT)','C6H6GT'}, {'benzene'}, 6);
co   = local_get_numeric_column(T, {'CO(GT)','COGT'}, {'carbonmonoxide'}, 3);
s1   = local_get_numeric_column(T, {'PT08.S1(CO)','PT08S1CO'}, {'pt08s1co','s1co'}, 4);
s2   = local_get_numeric_column(T, {'PT08.S2(NMHC)','PT08S2NMHC'}, {'pt08s2nmhc','s2nmhc'}, 7);
nox  = local_get_numeric_column(T, {'NOx(GT)','NOxGT'}, {'noxgt'}, 9);
s3   = local_get_numeric_column(T, {'PT08.S3(NOx)','PT08S3NOx'}, {'pt08s3nox','s3nox'}, 10);
no2  = local_get_numeric_column(T, {'NO2(GT)','NO2GT'}, {'no2gt'}, 11);
s4   = local_get_numeric_column(T, {'PT08.S4(NO2)','PT08S4NO2'}, {'pt08s4no2','s4no2'}, 12);
s5   = local_get_numeric_column(T, {'PT08.S5(O3)','PT08S5O3'}, {'pt08s5o3','s5o3'}, 13);
temp = local_get_numeric_column(T, {'T'}, {'temperature'}, 14);
rh   = local_get_numeric_column(T, {'RH'}, {'relativehumidity'}, 15);
ah   = local_get_numeric_column(T, {'AH'}, {'absolutehumidity'}, 16);

X = [co s1 s2 nox s3 no2 s4 s5 temp rh ah];

% UCI Air Quality uses -200 for missing values.
y(y <= -100) = NaN;
X(X <= -100) = NaN;
valid = isfinite(y);
y = y(valid);
X = X(valid, :);
X = local_impute_columns(X);

Z = local_minmax_matrix(X);
zCO = Z(:,1);
zS1 = Z(:,2);
zS2 = Z(:,3);
zNOx = Z(:,4);
zS3 = Z(:,5);
zNO2 = Z(:,6);
zS4 = Z(:,7);
zS5 = Z(:,8);
zT = Z(:,9);
zRH = Z(:,10);
zAH = Z(:,11);

pollutionCore = [zCO zS1 zS2 zNOx zNO2 zS4 zS5 1-zS3];
sensorDisagreement = local_minmax(std(pollutionCore, 0, 2));
meteorExtreme = local_clip01((abs(zT-0.5) + abs(zRH-0.5) + abs(zAH-0.5)) ./ 1.5);
meteorContext = local_weighted_mean([zT zRH zAH], [0.20 0.40 0.40]);

% Benefit/cost are multi-criterion, not one scalar copied to every subject.
Bcrit = local_clip01([zCO zS1 zS2 zNOx zNO2 zS4 zS5 1-zS3 meteorContext]);
Ucrit = local_clip01([1-zCO 1-zS2 zS3 1-zNOx 1-zNO2 sensorDisagreement meteorExtreme]);

baseWB = [0.14 0.12 0.17 0.14 0.12 0.10 0.10 0.08 0.03];
baseWU = [0.12 0.16 0.14 0.14 0.12 0.22 0.10];

% Rows = criteria, columns = subject profile dimensions:
% [general_state, uncertainty_worry, affective_load, detail_style].
loadB = [
     0.10  0.05  0.08 -0.04;
     0.05  0.03  0.04  0.02;
     0.12  0.06  0.07  0.05;
     0.10  0.08  0.06 -0.02;
     0.08  0.06  0.06  0.00;
     0.03  0.02  0.02  0.04;
     0.03  0.02  0.02  0.03;
     0.08  0.10  0.05 -0.03;
    -0.08 -0.04 -0.02  0.10];
loadU = [
    -0.05  0.00 -0.02 -0.04;
    -0.04  0.01 -0.02 -0.02;
     0.10  0.12  0.06 -0.04;
    -0.04  0.00 -0.02 -0.02;
    -0.04  0.00 -0.02 -0.02;
     0.12  0.18  0.08  0.05;
     0.06  0.10  0.04  0.08];

[B, U, omega, baselineScore] = local_expand_multicriteria( ...
    Bcrit, Ucrit, baseWB, baseWU, loadB, loadU, subjects, cfg, profiles);

altNames = "AirQuality_" + string((1:numel(y))');
fuzzy_case = local_make_case( ...
    "UCI_AIR_QUALITY", ...
    "UCI Air Quality", ...
    "Rank hourly air-quality observations by benzene concentration", ...
    "benzene concentration C6H6(GT), microg/m^3", ...
    "https://archive.ics.uci.edu/static/public/360/air+quality.zip", ...
    altNames, ...
    ["CO_GT","PT08_S1_CO","PT08_S2_NMHC","NOx_GT","NO2_GT", ...
     "PT08_S4_NO2","PT08_S5_O3","inverse_PT08_S3_NOx","meteor_context"], ...
    B, U, omega, y, baselineScore, ...
    "B/U use public sensor and meteorological evidence only; C6H6(GT) is reserved as external ground truth.");
end

% =========================================================================
% Case 2: UCI Combined Cycle Power Plant
% =========================================================================

function fuzzy_case = local_build_ccpp_case(fp, subjects, cfg, profiles)
T = local_readtable(fp);

AT = local_get_numeric_column(T, {'AT'}, {'ambienttemperature','temperature'}, 1);
V  = local_get_numeric_column(T, {'V'}, {'exhaustvacuum','vacuum'}, 2);
AP = local_get_numeric_column(T, {'AP'}, {'ambientpressure','pressure'}, 3);
RH = local_get_numeric_column(T, {'RH'}, {'relativehumidity','humidity'}, 4);
PE = local_get_numeric_column(T, {'PE'}, {'energyoutput','electricalenergyoutput','netelectrical'}, 5);

X = [AT V AP RH];
valid = isfinite(PE) & all(isfinite(X), 2);
PE = PE(valid);
X = X(valid, :);

Z = local_minmax_matrix(X);
zAT = Z(:,1);
zV  = Z(:,2);
zAP = Z(:,3);
zRH = Z(:,4);

lowAT = 1 - zAT;
lowV = 1 - zV;
highAP = zAP;
lowRH = 1 - zRH;
climateAdvantage = local_weighted_mean([lowAT lowV highAP lowRH], [0.35 0.25 0.25 0.15]);
pressureTempMargin = local_clip01(0.5 .* highAP + 0.5 .* lowAT);
operatingStress = local_weighted_mean([zAT zV 1-zAP zRH], [0.35 0.25 0.25 0.15]);
featureConflict = local_minmax(std([lowAT lowV highAP lowRH], 0, 2));

% PE is not used in B/U construction.
Bcrit = local_clip01([lowAT lowV highAP lowRH climateAdvantage pressureTempMargin]);
Ucrit = local_clip01([zAT zV 1-zAP zRH operatingStress featureConflict]);

baseWB = [0.26 0.22 0.20 0.12 0.12 0.08];
baseWU = [0.25 0.22 0.20 0.13 0.12 0.08];

loadB = [
     0.06  0.04  0.02 -0.02;
     0.04  0.03  0.02  0.03;
     0.02  0.02  0.01  0.05;
     0.04  0.03  0.02  0.02;
     0.08  0.07  0.04  0.05;
     0.05  0.04  0.02  0.08];
loadU = [
     0.08  0.08  0.04 -0.03;
     0.06  0.06  0.03  0.02;
     0.05  0.05  0.03  0.04;
     0.05  0.06  0.03  0.01;
     0.10  0.12  0.06  0.02;
     0.08  0.14  0.06  0.08];

[B, U, omega, baselineScore] = local_expand_multicriteria( ...
    Bcrit, Ucrit, baseWB, baseWU, loadB, loadU, subjects, cfg, profiles);

altNames = "CCPP_" + string((1:numel(PE))');
fuzzy_case = local_make_case( ...
    "UCI_CCPP_POWER_PLANT", ...
    "UCI Combined Cycle Power Plant", ...
    "Rank power-plant operating observations by net electrical energy output", ...
    "net electrical energy output PE, MW", ...
    "https://archive.ics.uci.edu/static/public/294/combined+cycle+power+plant.zip", ...
    altNames, ...
    ["low_AT","low_V","high_AP","low_RH","climate_advantage","pressure_temp_margin"], ...
    B, U, omega, PE, baselineScore, ...
    "B/U use AT, V, AP and RH feature evidence only; PE is reserved as external ground truth.");
end

% =========================================================================
% Case 3: UCI Real Estate Valuation
% =========================================================================

function fuzzy_case = local_build_real_estate_case(fp, subjects, cfg, profiles)
T = local_readtable(fp);

transactionDate = local_get_numeric_column(T, {'X1 transaction date','X1transactiondate'}, {'transactiondate'}, 2);
houseAge        = local_get_numeric_column(T, {'X2 house age','X2houseage'}, {'houseage'}, 3);
distanceMRT     = local_get_numeric_column(T, {'X3 distance to the nearest MRT station','X3distancetothenearestMRTstation'}, {'nearestmrt','mrtstation','distance'}, 4);
convStores      = local_get_numeric_column(T, {'X4 number of convenience stores','X4numberofconveniencestores'}, {'conveniencestores'}, 5);
latitude        = local_get_numeric_column(T, {'X5 latitude','X5latitude'}, {'latitude'}, 6);
longitude       = local_get_numeric_column(T, {'X6 longitude','X6longitude'}, {'longitude'}, 7);
price           = local_get_numeric_column(T, {'Y house price of unit area','Yhousepriceofunitarea'}, {'houseprice','unitarea'}, 8);

X = [transactionDate houseAge distanceMRT convStores latitude longitude];
valid = isfinite(price) & all(isfinite(X), 2);
price = price(valid);
X = X(valid, :);

Z = local_minmax_matrix(X);
zDate = Z(:,1);
zAge  = Z(:,2);
zDist = Z(:,3);
zConv = Z(:,4);
zLat  = Z(:,5);
zLon  = Z(:,6);

newerBuilding = 1 - zAge;
nearMRT = 1 - zDist;
accessibility = local_weighted_mean([nearMRT zConv], [0.65 0.35]);
coordCentrality = local_clip01(1 - 0.5 .* abs(zLat - median(zLat, 'omitnan')) ./ max(local_nanrange(zLat), eps) ...
                                  - 0.5 .* abs(zLon - median(zLon, 'omitnan')) ./ max(local_nanrange(zLon), eps));
coordCentrality = local_minmax(coordCentrality);
locationBenefit = local_weighted_mean([zLat zLon coordCentrality], [0.25 0.25 0.50]);

oldBuilding = zAge;
farMRT = zDist;
fewStores = 1 - zConv;
locationPenalty = 1 - locationBenefit;
ageDistanceStress = local_clip01(0.5 .* oldBuilding + 0.5 .* farMRT);
accessPenalty = local_clip01(0.6 .* farMRT + 0.4 .* fewStores);

% Price is not used in B/U construction.
Bcrit = local_clip01([zDate newerBuilding nearMRT zConv locationBenefit accessibility]);
Ucrit = local_clip01([oldBuilding farMRT fewStores locationPenalty ageDistanceStress accessPenalty]);

baseWB = [0.06 0.18 0.30 0.20 0.14 0.12];
baseWU = [0.18 0.34 0.18 0.10 0.12 0.08];

loadB = [
    -0.02 -0.02  0.00  0.03;
     0.08  0.04  0.03 -0.01;
     0.10  0.08  0.04  0.04;
     0.06  0.05  0.02  0.05;
     0.03  0.04  0.02  0.10;
     0.08  0.08  0.04  0.08];
loadU = [
     0.08  0.06  0.04 -0.02;
     0.12  0.12  0.06  0.03;
     0.06  0.05  0.03  0.04;
     0.06  0.08  0.04  0.10;
     0.10  0.12  0.06  0.04;
     0.08  0.10  0.05  0.06];

[B, U, omega, baselineScore] = local_expand_multicriteria( ...
    Bcrit, Ucrit, baseWB, baseWU, loadB, loadU, subjects, cfg, profiles);

altNames = "RealEstate_" + string((1:numel(price))');
fuzzy_case = local_make_case( ...
    "UCI_REAL_ESTATE_VALUATION", ...
    "UCI Real Estate Valuation", ...
    "Rank real-estate cases by house price of unit area", ...
    "house price of unit area, 10000 New Taiwan Dollar/Ping", ...
    "https://archive.ics.uci.edu/static/public/477/real+estate+valuation+data+set.zip", ...
    altNames, ...
    ["transaction_recency","newer_building","near_MRT", ...
     "convenience_stores","location_benefit","accessibility"], ...
    B, U, omega, price, baselineScore, ...
    "B/U use transaction, age, MRT distance, convenience-store and location evidence only; price is reserved as external ground truth.");
end

% =========================================================================
% Shared case construction helpers
% =========================================================================

function [B, U, omega, baselineScore] = local_expand_multicriteria(Bcrit, Ucrit, baseWB, baseWU, loadB, loadU, subjects, cfg, profiles)
Bcrit = local_clip01(double(Bcrit));
Ucrit = local_clip01(double(Ucrit));
baseWB = local_normalize_weights(baseWB, size(Bcrit,2));
baseWU = local_normalize_weights(baseWU, size(Ucrit,2));

m = size(Bcrit, 1);
nS = numel(subjects);
B = zeros(nS, m);
U = zeros(nS, m);

if size(profiles,1) ~= nS
    profiles = zeros(nS, 4);
end
profiles = local_clip(profiles, -2.5, 2.5) ./ 2.5;  % approximately [-1, 1]

for s = 1:nS
    p = profiles(s, :);
    wB = local_softmax_weights(baseWB, loadB, p);
    wU = local_softmax_weights(baseWU, loadU, p);

    rawB = Bcrit * wB(:);
    rawU = Ucrit * wU(:);

    % Subject-specific, non-target modulation. This prevents every subject
    % from seeing exactly the same public fuzzy evidence while preserving the
    % dataset-level feature signal.
    evidenceBalance = rawB - rawU;
    attention = 0.04 * p(4);
    worry = 0.05 * p(2);
    affect = 0.03 * p(3);

    B(s,:) = local_clip01(rawB(:)' + attention .* local_center01(rawB(:)') + affect .* local_center01(evidenceBalance(:)'));
    U(s,:) = local_clip01(rawU(:)' + worry .* local_center01(rawU(:)') - 0.5 .* affect .* local_center01(evidenceBalance(:)'));
end

baseB = Bcrit * baseWB(:);
baseU = Ucrit * baseWU(:);

% Baseline is deliberately neutral feature-only aggregation. It does not use
% subject profiles, lambda, beta, or ground truth.
baselineScore = local_clip(baseB - baseU, -1, 1);
baselineScore = baselineScore(:);

% Add a very small deterministic numeric tie-breaker only to avoid unstable
% sort ordering when two alternatives have exactly identical feature evidence.
% It is independent of ground truth and far too small to change meaningful
% rankings.
baselineScore = baselineScore + local_tiny_tiebreaker(numel(baselineScore));

if isfield(cfg, 'transfer') && isfield(cfg.transfer, 'omega') && ...
        ~isempty(cfg.transfer.omega) && numel(cfg.transfer.omega) == nS
    omega = double(cfg.transfer.omega(:));
    omega = omega ./ max(sum(omega), eps);
else
    omega = ones(nS, 1) / max(nS, 1);
end
end

function w = local_softmax_weights(baseW, loadM, profileRow)
baseW = local_normalize_weights(baseW, numel(baseW));
if isempty(loadM) || size(loadM,1) ~= numel(baseW)
    loadM = zeros(numel(baseW), numel(profileRow));
end
if size(loadM,2) ~= numel(profileRow)
    L = zeros(numel(baseW), numel(profileRow));
    cols = min(size(loadM,2), numel(profileRow));
    L(:,1:cols) = loadM(:,1:cols);
    loadM = L;
end
z = log(max(baseW(:), 1e-8)) + loadM * double(profileRow(:));
z = z - max(z);
w = exp(z);
w = w ./ max(sum(w), eps);
end

function fuzzy_case = local_make_case(caseId, sourceName, taskLabel, truthLabel, downloadUrl, altNames, featureNames, B, U, omega, truth, baselineScore, note)
fuzzy_case = struct();
fuzzy_case.case_id = string(caseId);
fuzzy_case.source_name = string(sourceName);
fuzzy_case.task_label = string(taskLabel);
fuzzy_case.ground_truth_label = string(truthLabel);
fuzzy_case.download_url = string(downloadUrl);
fuzzy_case.alternative_names = string(altNames(:));
fuzzy_case.feature_names = string(featureNames(:));
fuzzy_case.criteria = string(featureNames(:));
fuzzy_case.omega = double(omega(:));
fuzzy_case.B = double(B);
fuzzy_case.U = double(U);
fuzzy_case.ground_truth = double(truth(:));
fuzzy_case.baseline_score = double(baselineScore(:));
fuzzy_case.transform_note = string(note);
fuzzy_case.is_public_fuzzy_case = true;

if size(fuzzy_case.B, 2) ~= numel(fuzzy_case.alternative_names)
    error('build_demo_fuzzy_case:BadBShape', ...
        'B must be nSubjects x nAlternatives for case %s.', char(caseId));
end
if size(fuzzy_case.U, 2) ~= numel(fuzzy_case.alternative_names)
    error('build_demo_fuzzy_case:BadUShape', ...
        'U must be nSubjects x nAlternatives for case %s.', char(caseId));
end
if size(fuzzy_case.B, 1) ~= numel(fuzzy_case.omega) || size(fuzzy_case.U, 1) ~= numel(fuzzy_case.omega)
    error('build_demo_fuzzy_case:BadOmegaShape', ...
        'omega length must equal nSubjects for case %s.', char(caseId));
end
if numel(fuzzy_case.ground_truth) ~= numel(fuzzy_case.alternative_names)
    error('build_demo_fuzzy_case:BadTruthShape', ...
        'ground_truth length must equal nAlternatives for case %s.', char(caseId));
end
if numel(fuzzy_case.baseline_score) ~= numel(fuzzy_case.alternative_names)
    error('build_demo_fuzzy_case:BadBaselineShape', ...
        'baseline_score length must equal nAlternatives for case %s.', char(caseId));
end
end

% =========================================================================
% Subject-profile helpers
% =========================================================================

function profiles = local_subject_profiles(subjects, trialT)
nS = numel(subjects);
profiles = zeros(nS, 4);

% profile columns:
% 1 general_state, 2 uncertainty_worry, 3 affective_load, 4 detail_style.
for s = 1:nS
    tf = [];
    if isfield(subjects, 'trait_features') && ~isempty(subjects(s).trait_features)
        tf = local_to_double_vector(subjects(s).trait_features);
    end
    tf = tf(:)';
    tf(~isfinite(tf)) = 0;
    if numel(tf) < 4
        tf(1, end+1:4) = 0;
    end

    profiles(s,1) = mean(tf(1:4), 'omitnan');
    profiles(s,2) = 0.5 * tf(2) + 0.5 * tf(4);       % IUS/PSWQ-like worry
    profiles(s,3) = 0.5 * tf(1) + 0.5 * tf(3);       % STAI/MASQ-like affect
    profiles(s,4) = 0.5 * tf(2) - 0.5 * tf(3);       % detail-vs-affect style
end

% Add a weak behavior-derived profile when trialT is available. This uses
% reconstructed task behavior only; it does not use any public fuzzy target.
try
    if istable(trialT) && height(trialT) > 0 && ismember('subject_id', trialT.Properties.VariableNames)
        subjIds = string({subjects.subject_id}');
        tSubj = string(trialT.subject_id);
        extra = zeros(nS, 2);
        for s = 1:nS
            mask = tSubj == subjIds(s);
            if any(mask)
                if ismember('sample_obs', trialT.Properties.VariableNames)
                    extra(s,1) = mean(double(trialT.sample_obs(mask)), 'omitnan');
                end
                if ismember('uncertainty_level', trialT.Properties.VariableNames)
                    extra(s,2) = mean(double(trialT.uncertainty_level(mask)), 'omitnan');
                end
            end
        end
        extra = [local_standardize(extra(:,1)), local_standardize(extra(:,2))];
        profiles(:,2) = profiles(:,2) + 0.15 * extra(:,2);
        profiles(:,4) = profiles(:,4) + 0.10 * extra(:,1);
    end
catch
    % Keep profile construction robust across older MATLAB/table variants.
end

for j = 1:size(profiles,2)
    profiles(:,j) = local_standardize(profiles(:,j));
end
profiles(~isfinite(profiles)) = 0;
end

% =========================================================================
% Robust table and column utilities
% =========================================================================

function T = local_readtable(fp)
try
    T = readtable(fp, 'VariableNamingRule', 'preserve');
catch
    T = readtable(fp);
end
end

function x = local_get_numeric_column(T, exactPatterns, containsPatterns, fallbackIdx)
if nargin < 3
    containsPatterns = {};
end
if nargin < 4
    fallbackIdx = [];
end
idx = local_find_column(T, exactPatterns, containsPatterns);
if isempty(idx) && ~isempty(fallbackIdx) && fallbackIdx >= 1 && fallbackIdx <= width(T)
    idx = fallbackIdx;
end
if isempty(idx)
    msg = strjoin(cellstr(string([exactPatterns(:); containsPatterns(:)])), ', ');
    error('build_demo_fuzzy_case:MissingColumn', ...
        'Could not find required numeric column. Patterns: %s', msg);
end
x = T{:, idx};
x = local_to_double_vector(x);
end

function idx = local_find_column(T, exactPatterns, containsPatterns)
idx = [];
if nargin < 3
    containsPatterns = {};
end

names = string(T.Properties.VariableNames(:));
raw = names;
try
    desc = string(T.Properties.VariableDescriptions(:));
    if numel(desc) == numel(names)
        raw = [raw desc];
    end
catch
end
normRaw = lower(regexprep(raw, '[^a-zA-Z0-9]+', ''));

for p = 1:numel(exactPatterns)
    pat = lower(regexprep(string(exactPatterns{p}), '[^a-zA-Z0-9]+', ''));
    if strlength(pat) == 0
        continue;
    end
    hitRows = find(any(normRaw == pat, 2), 1, 'first');
    if ~isempty(hitRows)
        idx = hitRows;
        return;
    end
end

for p = 1:numel(containsPatterns)
    pat = lower(regexprep(string(containsPatterns{p}), '[^a-zA-Z0-9]+', ''));
    if strlength(pat) < 3
        continue;
    end
    hitRows = find(any(contains(normRaw, pat), 2), 1, 'first');
    if ~isempty(hitRows)
        idx = hitRows;
        return;
    end
end
end

function x = local_to_double_vector(x)
if istable(x)
    x = table2array(x);
end

if isa(x, 'datetime')
    mask = ~isnat(x);
    out = NaN(size(x));
    if any(mask(:))
        x0 = min(x(mask));
        out(mask) = days(x(mask) - x0);
    end
    x = out;
elseif isa(x, 'duration')
    x = seconds(x);
elseif isa(x, 'calendarDuration')
    x = days(x);
end

if iscell(x)
    x = string(x);
end
if iscategorical(x)
    x = string(x);
end
if isstring(x) || ischar(x)
    x = string(x);
    x = strip(x);
    x = replace(x, ',', '.');
    x = replace(x, ';', '.');
    x(ismissing(x) | x == "" | lower(x) == "na" | lower(x) == "nan") = "NaN";
    x = str2double(x);
end

x = double(x);
x = x(:);
end

function X = local_impute_columns(X)
X = double(X);
for j = 1:size(X,2)
    col = X(:,j);
    mask = isfinite(col);
    if any(mask)
        fillVal = median(col(mask), 'omitnan');
        if ~isfinite(fillVal)
            fillVal = mean(col(mask), 'omitnan');
        end
        if ~isfinite(fillVal)
            fillVal = 0;
        end
    else
        fillVal = 0;
    end
    col(~mask) = fillVal;
    X(:,j) = col;
end
end

function local_require_file(fp, caseId, url, dataDir)
if exist(fp, 'file')
    return;
end
[~, name, ext] = fileparts(fp);
error('build_demo_fuzzy_case:MissingPublicFuzzyFile', ...
    ['Missing local public fuzzy file for %s:\n  %s\n\n' ...
     'Please download it from:\n  %s\n\n' ...
     'Then place/extract %s%s into:\n  %s\n\n' ...
     'This build_demo_fuzzy_case.m intentionally does not auto-download data.'], ...
    char(caseId), fp, char(url), name, ext, dataDir);
end

% =========================================================================
% Numeric helpers
% =========================================================================

function Z = local_minmax_matrix(X)
X = double(X);
Z = nan(size(X));
for j = 1:size(X,2)
    Z(:,j) = local_minmax(X(:,j));
end
Z(~isfinite(Z)) = 0.5;
end

function z = local_minmax(x)
x = double(x(:));
mn = min(x, [], 'omitnan');
mx = max(x, [], 'omitnan');
if ~isfinite(mn) || ~isfinite(mx) || abs(mx - mn) < 1e-12
    z = 0.5 * ones(size(x));
else
    z = (x - mn) ./ (mx - mn);
end
z = local_clip01(z);
end

function z = local_standardize(x)
x = double(x(:));
mu = mean(x, 'omitnan');
sd = std(x, 'omitnan');
if ~isfinite(sd) || sd < 1e-12
    z = zeros(size(x));
else
    z = (x - mu) ./ sd;
end
z(~isfinite(z)) = 0;
end

function y = local_weighted_mean(X, w)
X = double(X);
if isempty(w)
    w = ones(1, size(X,2)) / max(size(X,2), 1);
else
    w = local_normalize_weights(w, size(X,2));
end
y = X * w(:);
y = local_clip01(y);
end

function w = local_normalize_weights(w, n)
w = double(w(:)');
if numel(w) ~= n
    w = ones(1, n) / max(n, 1);
    return;
end
w(~isfinite(w)) = 0;
w = max(w, 0);
sw = sum(w);
if ~isfinite(sw) || sw <= eps
    w = ones(1, n) / max(n, 1);
else
    w = w ./ sw;
end
end

function y = local_center01(x)
x = double(x);
y = x - mean(x, 'omitnan');
mx = max(abs(y), [], 'omitnan');
if ~isfinite(mx) || mx < eps
    y = zeros(size(x));
else
    y = y ./ mx;
end
end

function r = local_nanrange(x)
x = double(x(:));
mn = min(x, [], 'omitnan');
mx = max(x, [], 'omitnan');
r = mx - mn;
if ~isfinite(r)
    r = 0;
end
end

function tb = local_tiny_tiebreaker(n)
if n <= 1
    tb = zeros(n, 1);
else
    tb = (1:n)' ./ n;
    tb = (tb - mean(tb)) * 1e-9;
end
end

function x = local_clip01(x)
x = local_clip(x, 0, 1);
end

function x = local_clip(x, lo, hi)
x = min(max(double(x), lo), hi);
end
