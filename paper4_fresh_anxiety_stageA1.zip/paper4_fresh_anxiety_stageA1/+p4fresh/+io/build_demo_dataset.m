function dataset = build_demo_dataset(cfg)
rng(cfg.random_seed, 'twister');

if ~isfield(cfg, 'openneuro') || ~isfield(cfg.openneuro, 'enabled') || ~cfg.openneuro.enabled
    error('This project is configured for real OpenNeuro input. cfg.openneuro.enabled must be true.');
end

dataDir = local_resolve_data_dir(cfg);
local_ensure_phenotype_files(dataDir, cfg);
psychFull = local_load_psychometric_table(dataDir, cfg);
local_fetch_event_files_if_needed(dataDir, psychFull, cfg);

[trialT, mappingInfo] = local_load_trial_table(dataDir, cfg);
if isempty(trialT) || height(trialT) == 0
    error('No usable OpenNeuro BART episodes were found in %s.', dataDir);
end

eventSubjectIds = unique(string(trialT.subject_id), 'stable');
psychT = psychFull(ismember(string(psychFull.subject_id), eventSubjectIds), :);
psychT = sortrows(psychT, 'subject_id');

if isempty(psychT) || height(psychT) == 0
    error('No participant-level phenotype rows matched the event files.');
end

z_stai_full = p4fresh.utils.normalize_z(psychFull.stai_t);
z_ius_full = p4fresh.utils.normalize_z(psychFull.ius);
z_masq_full = p4fresh.utils.normalize_z(psychFull.masq_aa);
z_pswq_full = p4fresh.utils.normalize_z(psychFull.pswq);

[lia, locb] = ismember(string(psychT.subject_id), string(psychFull.subject_id));
if ~all(lia)
    error('Psychometric subject alignment failed while constructing trait features.');
end
z_stai = z_stai_full(locb);
z_ius = z_ius_full(locb);
z_masq = z_masq_full(locb);
z_pswq = z_pswq_full(locb);

trialT = sortrows(trialT, {'subject_id','trial_id'});
subject_ids = unique(string(trialT.subject_id), 'stable');
psychT = psychT(ismember(string(psychT.subject_id), subject_ids), :);
subject_ids = string(psychT.subject_id(:));

nS = numel(subject_ids);
nTrials = height(trialT);
nB = max(double(trialT.block_id));

T = p4fresh.schema.templates();
subjects = repmat(T.subject, nS, 1);
trials = repmat(T.trial, nTrials, 1);

for s = 1:nS
    subj = T.subject;
    subj.subject_idx = int32(s);
    subj.subject_id = subject_ids(s);
    subj.psych_row = psychT(s,:);
    subj.trial_indices = int32(find(string(trialT.subject_id) == subject_ids(s)));
    subj.trait_features = [z_stai(s) z_ius(s) z_masq(s) z_pswq(s)];
    subjects(s,1) = subj;
end

z_vas = p4fresh.utils.normalize_z(trialT.vas);
z_loss = p4fresh.utils.normalize_z(trialT.loss_flag);
z_unc = p4fresh.utils.normalize_z(trialT.uncertainty_level);
z_err = p4fresh.utils.normalize_z(trialT.recent_error);
z_conf = p4fresh.utils.normalize_z(trialT.conflict_level);

for r = 1:nTrials
    tr = T.trial;
    tr.trial_idx = int32(r);
    sid = string(trialT.subject_id(r));
    sidx = find(subject_ids == sid, 1);
    tr.subject_idx = int32(sidx);
    tr.subject_id = sid;
    tr.trial_id = int32(trialT.trial_id(r));
    tr.block_id = int32(trialT.block_id(r));
    tr.vas = double(trialT.vas(r));
    tr.loss_flag = double(trialT.loss_flag(r));
    tr.uncertainty_level = double(trialT.uncertainty_level(r));
    tr.recent_error = double(trialT.recent_error(r));
    tr.conflict_level = double(trialT.conflict_level(r));
    tr.eiv = double(trialT.eiv(r));
    tr.reward_signal = double(trialT.reward_signal(r));
    tr.punishment_signal = double(trialT.punishment_signal(r));
    tr.sample_obs = double(trialT.sample_obs(r));
    tr.choice_obs = double(trialT.choice_obs(r));
    tr.choice_optimal = double(trialT.choice_optimal(r));
    tr.confidence_obs = double(trialT.confidence_obs(r));
    tr.state_features = [z_vas(r) z_loss(r) z_unc(r) z_err(r) z_conf(r)];
    trials(r,1) = tr;
end

fuzzy_case = p4fresh.io.build_demo_fuzzy_case(subjects, cfg, trialT);

dataset = struct();
dataset.meta = struct( ...
    'source', char(cfg.openneuro.source_label), ...
    'dataset_id', char(cfg.openneuro.dataset_id), ...
    'task', char(cfg.openneuro.task), ...
    'trial_unit', 'balloon_episode_terminal_decision', ...
    'n_subjects', nS, ...
    'n_trials', nTrials, ...
    'n_blocks', nB, ...
    'n_psychometric_rows_total', height(psychFull), ...
    'n_psychometric_rows_used', height(psychT), ...
    'n_event_files_used', mappingInfo.n_event_files_used, ...
    'n_complete_episodes', mappingInfo.n_complete_episodes, ...
    'hazard_states_used', mappingInfo.hazard_states_used, ...
    'mapping_version', 'episode_terminal_hazard_v2');
dataset.psychometric_table = psychT;
dataset.trial_table = trialT;
dataset.subjects = subjects;
dataset.trials = trials;
dataset.fuzzy_case = fuzzy_case;
end

function dataDir = local_resolve_data_dir(cfg)
dataDir = char(cfg.openneuro.data_dir);
if ~exist(dataDir, 'dir')
    fallback = fullfile(fileparts(mfilename('fullpath')), 'openneuro_ds000030');
    if exist(fallback, 'dir')
        dataDir = fallback;
    else
        mkdir(dataDir);
    end
end
end

function local_ensure_phenotype_files(dataDir, cfg)
files = cfg.openneuro.files;
base = char(cfg.openneuro.github_raw_base);
need = {
    files.demographics, '/phenotype/demographics.tsv';
    files.barratt, '/phenotype/barratt.tsv';
    files.mpq, '/phenotype/mpq.tsv';
    files.eysenck, '/phenotype/eysenck.tsv';
    files.tci, '/phenotype/tci.tsv';
    files.bart, '/phenotype/bart.tsv'};
for i = 1:size(need,1)
    target = fullfile(dataDir, need{i,1});
    if exist(target, 'file')
        continue;
    end
    url = [base need{i,2}];
    try
        websave(target, url, weboptions('Timeout', 60));
    catch
        if ~exist(target, 'file')
            error('Required phenotype file was not found and could not be downloaded: %s', target);
        end
    end
end
end

function psychFull = local_load_psychometric_table(dataDir, cfg)
files = cfg.openneuro.files;

D = readtable(fullfile(dataDir, files.demographics), 'FileType','text', 'Delimiter', sprintf('\t'));
B = readtable(fullfile(dataDir, files.barratt), 'FileType','text', 'Delimiter', sprintf('\t'));
M = readtable(fullfile(dataDir, files.mpq), 'FileType','text', 'Delimiter', sprintf('\t'));
E = readtable(fullfile(dataDir, files.eysenck), 'FileType','text', 'Delimiter', sprintf('\t'));
T = readtable(fullfile(dataDir, files.tci), 'FileType','text', 'Delimiter', sprintf('\t'));
R = readtable(fullfile(dataDir, files.bart), 'FileType','text', 'Delimiter', sprintf('\t'));

D = local_keep_and_rename(D, {'participant_id','age','gender'}, {'subject_id','age','gender'});
B = local_keep_and_rename(B, {'participant_id','bis_briefbis'}, {'subject_id','ius'});
M = local_keep_and_rename(M, {'participant_id','mpq_score'}, {'subject_id','pswq'});
E = local_keep_and_rename(E, {'participant_id','scoree'}, {'subject_id','masq_aa'});
T = local_keep_and_rename(T, {'participant_id','harmavoidance'}, {'subject_id','stai_t'});
R = local_keep_and_rename(R, {'participant_id','bart_totaladjustedpumps','bart_totalpointssession','bart_meanrt','bart_meanadjustedpumps'}, ...
    {'subject_id','bart_totaladjustedpumps','bart_totalpointssession','bart_meanrt','bart_meanadjustedpumps'});

D.subject_id = string(D.subject_id);
B.subject_id = string(B.subject_id);
M.subject_id = string(M.subject_id);
E.subject_id = string(E.subject_id);
T.subject_id = string(T.subject_id);
R.subject_id = string(R.subject_id);

psychFull = innerjoin(T, B, 'Keys','subject_id');
psychFull = innerjoin(psychFull, E, 'Keys','subject_id');
psychFull = innerjoin(psychFull, M, 'Keys','subject_id');
psychFull = innerjoin(psychFull, D, 'Keys','subject_id');
psychFull = innerjoin(psychFull, R, 'Keys','subject_id');

req = {'stai_t','ius','masq_aa','pswq'};
mask = true(height(psychFull),1);
for i = 1:numel(req)
    mask = mask & ~isnan(psychFull.(req{i}));
end
psychFull = psychFull(mask,:);
psychFull = sortrows(psychFull, 'subject_id');
end

function local_fetch_event_files_if_needed(dataDir, psychFull, cfg)
files = dir(fullfile(dataDir, cfg.openneuro.event_pattern));
rawFiles = files(~contains({files.name}, '_matched'));
if ~cfg.openneuro.auto_fetch_missing_events && ~isempty(rawFiles)
    return;
end
if ~cfg.openneuro.auto_fetch_missing_events
    return;
end
if numel(rawFiles) >= cfg.openneuro.auto_fetch_if_fewer_than
    return;
end

subjectIds = unique(string(psychFull.subject_id), 'stable');
limit = cfg.openneuro.auto_fetch_limit;
if isinf(limit)
    limit = numel(subjectIds);
else
    limit = min(limit, numel(subjectIds));
end
subjectIds = subjectIds(1:limit);
base = char(cfg.openneuro.github_raw_base);
for i = 1:numel(subjectIds)
    sid = char(subjectIds(i));
    localName = sprintf('%s_task-%s_events.tsv', sid, char(cfg.openneuro.task));
    target = fullfile(dataDir, localName);
    if exist(target, 'file')
        continue;
    end
    url = sprintf('%s/%s/func/%s', base, sid, localName);
    try
        websave(target, url, weboptions('Timeout', 60));
    catch
        % Ignore unavailable subjects; keep using everything that was fetched.
    end
end
end

function [trialT, info] = local_load_trial_table(dataDir, cfg)
files = dir(fullfile(dataDir, cfg.openneuro.event_pattern));
files = files(~contains({files.name}, '_matched'));
if isempty(files)
    error('No raw task-bart events files were found in %s.', dataDir);
end

allEpisodes = cell(numel(files),1);
keep = false(numel(files),1);
for k = 1:numel(files)
    fp = fullfile(files(k).folder, files(k).name);
    sid = local_parse_subject_id(files(k).name);
    eventT = readtable(fp, 'FileType','text', 'Delimiter', sprintf('\t'));
    ep = local_extract_subject_episodes(eventT, sid, cfg);
    if ~isempty(ep)
        keep(k) = true;
        allEpisodes{k} = ep;
    end
end
allEpisodes = allEpisodes(keep);
if isempty(allEpisodes)
    trialT = table();
    info = struct('n_event_files_used',0,'n_complete_episodes',0,'hazard_states_used',0);
    return;
end
allEpisodesT = vertcat(allEpisodes{:});
hazardModel = local_build_hazard_model(allEpisodesT, cfg);

subjectIds = unique(string(allEpisodesT.subject_id), 'stable');
outRows = cell(numel(subjectIds),1);
for s = 1:numel(subjectIds)
    sid = subjectIds(s);
    subjEps = allEpisodesT(string(allEpisodesT.subject_id) == sid, :);
    outRows{s} = local_convert_episodes_to_trials(subjEps, hazardModel, cfg);
end
trialT = vertcat(outRows{:});
trialT = sortrows(trialT, {'subject_id','trial_id'});
info = struct();
info.n_event_files_used = numel(subjectIds);
info.n_complete_episodes = height(allEpisodesT);
info.hazard_states_used = numel(hazardModel.states);
end

function sid = local_parse_subject_id(filename)
tok = regexp(filename, '(sub-[A-Za-z0-9]+)', 'tokens', 'once');
if isempty(tok)
    error('Could not parse subject id from %s', filename);
end
sid = string(tok{1});
end

function epT = local_extract_subject_episodes(eventT, sid, cfg)
required = {'trial_number','trial_type','action','explode_trial','trial_value', ...
    'trial_cumulative_value','payoff_level','reaction_time'};
for i = 1:numel(required)
    if ~ismember(required{i}, eventT.Properties.VariableNames)
        error('Events file for %s is missing required column %s.', sid, required{i});
    end
end

trialType = upper(string(eventT.trial_type));
if cfg.openneuro.exclude_control_trials
    keepRows = trialType == "BALOON";
else
    keepRows = true(height(eventT),1);
end
E = eventT(keepRows,:);
trialNum = double(E.trial_number);
uTrials = unique(trialNum, 'stable');

rows = struct('subject_id', {}, 'trial_id', {}, 'terminal_action', {}, 'terminal_explode', {}, ...
    'pumps', {}, 'bank_before_terminal', {}, 'pump_gain', {}, 'decision_rt', {});
ptr = 0;
for i = 1:numel(uTrials)
    g = E(trialNum == uTrials(i), :);
    gAction = upper(string(g.action));
    terminalAction = gAction(end);
    if cfg.openneuro.exclude_incomplete_episodes && ~(terminalAction == "CASHOUT" || terminalAction == "EXPLODE")
        continue;
    end
    acceptMask = gAction == "ACCEPT";
    nPump = sum(acceptMask);
    if nPump < 1
        continue;
    end
    bankBeforeTerminal = double(g.trial_cumulative_value(end));
    gainVals = double(g.trial_value(acceptMask));
    gainVals = gainVals(~isnan(gainVals) & gainVals > 0);
    if isempty(gainVals)
        payoffVals = double(g.payoff_level(~isnan(g.payoff_level) & g.payoff_level > 0));
        if isempty(payoffVals)
            pumpGain = cfg.openneuro.default_pump_gain;
        else
            pumpGain = median(payoffVals);
        end
    else
        pumpGain = median(gainVals);
    end
    decisionRt = local_terminal_rt(g, terminalAction);

    ptr = ptr + 1;
    rows(ptr).subject_id = char(sid);
    rows(ptr).trial_id = double(uTrials(i));
    rows(ptr).terminal_action = char(terminalAction);
    rows(ptr).terminal_explode = double(terminalAction == "EXPLODE");
    rows(ptr).pumps = double(nPump);
    rows(ptr).bank_before_terminal = double(bankBeforeTerminal);
    rows(ptr).pump_gain = double(pumpGain);
    rows(ptr).decision_rt = double(decisionRt);
end
if ptr == 0
    epT = table();
    return;
end
epT = struct2table(rows);
if height(epT) < cfg.openneuro.min_trials_per_subject
    epT = table();
end
end

function rt = local_terminal_rt(g, terminalAction)
rt = NaN;
gAction = upper(string(g.action));
if terminalAction == "CASHOUT"
    idx = find(gAction == "CASHOUT", 1, 'last');
    if ~isempty(idx)
        val = double(g.reaction_time(idx));
        if ~isnan(val) && val > 0
            rt = val;
            return;
        end
    end
end
vals = double(g.reaction_time);
vals = vals(~isnan(vals) & vals > 0);
if ~isempty(vals)
    rt = vals(end);
end
end

function hazardModel = local_build_hazard_model(allEpisodesT, cfg)
maxPumpObserved = max(double(allEpisodesT.pumps));
maxPumpPossible = max(cfg.openneuro.max_successful_pumps, maxPumpObserved);
states = (1:maxPumpPossible)';
explosionProb = zeros(size(states));
survivalProb = zeros(size(states));
alpha0 = double(cfg.openneuro.hazard_prior_alpha);
beta0 = double(cfg.openneuro.hazard_prior_beta);

for i = 1:numel(states)
    k = states(i);
    explodeCount = sum(allEpisodesT.terminal_explode == 1 & allEpisodesT.pumps == k);
    surviveCount = sum(allEpisodesT.pumps > k);
    % Beta-smoothed empirical hazard conditional on taking the risky action at bank=k*pump_gain.
    pExplode = (explodeCount + alpha0) / (explodeCount + surviveCount + alpha0 + beta0);
    explosionProb(i) = min(max(pExplode, 0), 1);
    survivalProb(i) = 1 - explosionProb(i);
end
hazardModel = struct();
hazardModel.states = states(:);
hazardModel.explosion_prob = explosionProb(:);
hazardModel.survival_prob = survivalProb(:);
hazardModel.max_bank = cfg.openneuro.max_successful_pumps * cfg.openneuro.default_pump_gain;
end

function outT = local_convert_episodes_to_trials(epT, hazardModel, cfg)
if isempty(epT)
    outT = table();
    return;
end

n = height(epT);
k = double(epT.pumps(:));
stateIdx = min(max(k, 1), numel(hazardModel.states));
explosionProb = hazardModel.explosion_prob(stateIdx);
survivalProb = hazardModel.survival_prob(stateIdx);

pumpGain = double(epT.pump_gain(:));
bank = double(epT.bank_before_terminal(:));
maxBank = max(hazardModel.max_bank, max(bank + pumpGain));
if maxBank <= 0
    maxBank = 1;
end

safeValue = local_clamp01(bank ./ maxBank);
nextBankValue = local_clamp01((bank + pumpGain) ./ maxBank);
rewardSignal = local_clamp01(survivalProb .* nextBankValue);
punishmentSignal = local_clamp01(explosionProb .* safeValue);
riskyEV = rewardSignal - punishmentSignal;

uncertaintyLevel = local_clamp01(explosionProb);
conflictLevel = local_clamp01(1 - abs(riskyEV - safeValue));
upside = max(nextBankValue - safeValue, 0);
eiv = local_clamp01(0.70 .* (survivalProb .* upside) + 0.30 .* conflictLevel);

sampleObs = local_compute_sample_obs(k, cfg);
choiceObs = ones(n,1);
choiceObs(string(epT.terminal_action) == "EXPLODE") = 2;

choiceOptimal = ones(n,1);
choiceOptimal(riskyEV > safeValue) = 2;

recentError = zeros(n,1);
for r = 2:n
    recentError(r) = double(choiceObs(r-1) ~= choiceOptimal(r-1));
end

confidenceObs = local_inverse_rt_confidence(epT.decision_rt);
vas = 100 .* local_clamp01(0.55 .* uncertaintyLevel + 0.45 .* conflictLevel);
lossFlag = double(epT.terminal_explode(:));
blockId = local_episode_blocks(n, cfg.openneuro.n_blocks);

outT = table();
outT.subject_id = string(epT.subject_id(:));
outT.trial_id = double(epT.trial_id(:));
outT.block_id = double(blockId(:));
outT.vas = double(vas(:));
outT.loss_flag = double(lossFlag(:));
outT.uncertainty_level = double(uncertaintyLevel(:));
outT.recent_error = double(recentError(:));
outT.conflict_level = double(conflictLevel(:));
outT.eiv = double(eiv(:));
outT.reward_signal = double(rewardSignal(:));
outT.punishment_signal = double(punishmentSignal(:));
outT.sample_obs = double(sampleObs(:));
outT.choice_obs = double(choiceObs(:));
outT.confidence_obs = double(confidenceObs(:));
outT.choice_optimal = double(choiceOptimal(:));

outT.terminal_action = string(epT.terminal_action(:));
outT.episode_pumps = double(k(:));
outT.bank_before_terminal = double(bank(:));
outT.decision_rt = double(epT.decision_rt(:));
outT.safe_value_proxy = double(safeValue(:));
outT.risky_ev_proxy = double(riskyEV(:));
outT.explosion_prob_proxy = double(explosionProb(:));
outT.survival_prob_proxy = double(survivalProb(:));
end

function sampleObs = local_compute_sample_obs(pumps, cfg)
pumps = double(pumps(:));
switch lower(string(cfg.openneuro.sample_rule))
    case "subject_median_pumps"
        thr = max(cfg.openneuro.min_pumps_for_sample, median(pumps, 'omitnan'));
        sampleObs = double(pumps >= thr);
    case "at_least_two_pumps"
        sampleObs = double(pumps >= cfg.openneuro.min_pumps_for_sample);
    otherwise
        thr = max(cfg.openneuro.min_pumps_for_sample, median(pumps, 'omitnan'));
        sampleObs = double(pumps >= thr);
end
end

function T = local_keep_and_rename(T, oldNames, newNames)
for i = 1:numel(oldNames)
    if ~ismember(oldNames{i}, T.Properties.VariableNames)
        error('Required phenotype column %s was not found.', oldNames{i});
    end
end
T = T(:, oldNames);
T.Properties.VariableNames = newNames;
end

function y = local_inverse_rt_confidence(rt)
rt = double(rt(:));
pos = rt(~isnan(rt) & rt > 0);
if isempty(pos)
    y = 0.5 .* ones(size(rt));
    return;
end
lo = min(pos);
hi = max(pos);
if hi <= lo + 1e-12
    y = 0.5 .* ones(size(rt));
else
    y = 1 - (rt - lo) ./ (hi - lo);
    y(isnan(y)) = 0.5;
end
y = local_clamp01(y);
end

function b = local_episode_blocks(n, nBlocks)
if nargin < 2 || isempty(nBlocks) || nBlocks <= 1
    b = ones(n,1);
    return;
end
edges = round(linspace(0, n, nBlocks + 1));
b = ones(n,1);
for k = 1:nBlocks
    idx = (edges(k)+1):edges(k+1);
    if isempty(idx)
        continue;
    end
    b(idx) = k;
end
b = max(1, b(:));
end

function y = local_clamp01(x)
y = min(max(double(x), 0), 1);
end
