function dataset = build_demo_dataset(cfg)
%BUILD_DEMO_DATASET Read Ferrari 2025 psychological main matrix.
%
% Expected file:
%   +p4fresh/+io/Charpentier/data_anx_gad7_prior.csv
%
% Required fields:
%   id, state_anx, trait_anx, gad7, rho, lambda, mu
%
% This is subject-level prefit prospect-theory data. No raw-trial refitting
% is performed in v8.

if nargin < 1 || isempty(cfg)
    cfg = p4fresh.config.default_config();
end

fp = local_find_psych_file(cfg);
Traw = local_readtable_robust(fp);
T = local_standardize_ferrari_table(Traw);

n = height(T);
if n < cfg.psych.min_valid_subjects
    error('build_demo_dataset:TooFewSubjects', ...
        'Only %d valid Ferrari subjects found. Expected at least %d.', n, cfg.psych.min_valid_subjects);
end

subjects = repmat(local_empty_subject(), n, 1);
for i = 1:n
    subjects(i).subject_idx = int32(i);
    subjects(i).subject_id = char("FE_" + string(T.id(i)));
    subjects(i).original_id = string(T.id(i));
    subjects(i).age = T.age(i);
    subjects(i).gender = char(T.gender(i));
    subjects(i).gad7 = T.gad7(i);
    subjects(i).state_anx = T.state_anx(i);
    subjects(i).trait_anx = T.trait_anx(i);
    subjects(i).rho = T.rho(i);
    subjects(i).lambda_loss = T.lambda_loss(i);
    subjects(i).mu = T.mu(i);
    subjects(i).p_gamble = T.p_gamble(i);
    subjects(i).p_gamble_mixed = T.p_gamble_mixed(i);
    subjects(i).p_gamble_gain = T.p_gamble_gain(i);
    subjects(i).anx_gad7_median = logical(T.anx_gad7_median(i));
    subjects(i).anx_trait_median = logical(T.anx_trait_median(i));
    subjects(i).anx_state_median = logical(T.anx_state_median(i));

    subjects(i).prefit_behavior_params = struct( ...
        'source', "Ferrari2025_GAD7_STAI_ProspectTheory", ...
        'rho', T.rho(i), ...
        'lambda_loss', T.lambda_loss(i), ...
        'mu', T.mu(i), ...
        'p_gamble', T.p_gamble(i), ...
        'p_gamble_mixed', T.p_gamble_mixed(i), ...
        'p_gamble_gain', T.p_gamble_gain(i));
end

phenotype_table = table();
phenotype_table.subject_idx = int32((1:n)');
phenotype_table.subject_id = string({subjects.subject_id}');
phenotype_table.original_id = string(T.id);
phenotype_table.age = T.age;
phenotype_table.gender = T.gender;
phenotype_table.gad7 = T.gad7;
phenotype_table.state_anx = T.state_anx;
phenotype_table.trait_anx = T.trait_anx;
phenotype_table.anx_gad7_median = logical(T.anx_gad7_median);
phenotype_table.anx_trait_median = logical(T.anx_trait_median);
phenotype_table.anx_state_median = logical(T.anx_state_median);

behavior_table = table();
behavior_table.subject_idx = int32((1:n)');
behavior_table.subject_id = string({subjects.subject_id}');
behavior_table.rho = T.rho;
behavior_table.lambda_loss = T.lambda_loss;
behavior_table.mu = T.mu;
behavior_table.p_gamble = T.p_gamble;
behavior_table.p_gamble_mixed = T.p_gamble_mixed;
behavior_table.p_gamble_gain = T.p_gamble_gain;
behavior_table.rt = T.rt;
behavior_table.rt_mixed = T.rt_mixed;
behavior_table.rt_gain = T.rt_gain;

summary_table = table();
summary_table.subject_idx = int32((1:n)');
summary_table.subject_id = string({subjects.subject_id}');
summary_table.rho = T.rho;
summary_table.lambda_loss = T.lambda_loss;
summary_table.mu = T.mu;
summary_table.gad7 = T.gad7;
summary_table.state_anx = T.state_anx;
summary_table.trait_anx = T.trait_anx;
summary_table.p_gamble = T.p_gamble;
summary_table.is_summary_row = true(n,1);

dataset = struct();
dataset.meta = struct();
dataset.meta.source = "Ferrari et al. 2025 GAD-7/STAI prospect-theory psychological dataset";
dataset.meta.source_type = "ferrari2025_gad7_prior_prefit_prospect";
dataset.meta.raw_file = string(fp);
dataset.meta.n_subjects = n;
dataset.meta.n_trials = height(summary_table);
dataset.meta.has_raw_trials = false;
dataset.meta.has_prefit_behavior_params = true;
dataset.meta.parameter_mapping = "rho/lambda/mu are read directly; tau/ell/beta/gamma are constructed in fit_dataset.";

dataset.subjects = subjects;
dataset.raw_table = Traw;
dataset.standardized_table = T;
dataset.phenotype_table = phenotype_table;
dataset.behavior_table = behavior_table;
dataset.trial_table = summary_table;
end

function T = local_standardize_ferrari_table(Traw)
n = height(Traw);
T = table();
T.id = local_get_string(Traw, "id", string((1:n)'));
T.age = local_get_numeric(Traw, "age", NaN(n,1));
T.gender = local_get_string(Traw, "gender", strings(n,1));

T.state_anx = local_get_numeric(Traw, "state_anx", NaN(n,1));
T.trait_anx = local_get_numeric(Traw, "trait_anx", NaN(n,1));
T.gad7 = local_get_numeric(Traw, "gad7", NaN(n,1));

T.rho = local_get_numeric(Traw, "rho", NaN(n,1));
T.lambda_loss = local_get_numeric(Traw, "lambda", NaN(n,1));
T.mu = local_get_numeric(Traw, "mu", NaN(n,1));

T.anx_gad7_median = local_get_logical(Traw, "anx_gad7_median", T.gad7 >= median(T.gad7,'omitnan'));
T.anx_trait_median = local_get_logical(Traw, "anx_trait_median", T.trait_anx >= median(T.trait_anx,'omitnan'));
T.anx_state_median = local_get_logical(Traw, "anx_state_median", T.state_anx >= median(T.state_anx,'omitnan'));

T.p_gamble = local_get_numeric(Traw, "p_gamble", NaN(n,1));
T.p_gamble_mixed = local_get_numeric(Traw, "p_gamble_mixed", NaN(n,1));
T.p_gamble_gain = local_get_numeric(Traw, "p_gamble_gain", NaN(n,1));
T.rt = local_get_numeric(Traw, "rt", NaN(n,1));
T.rt_mixed = local_get_numeric(Traw, "rt_mixed", NaN(n,1));
T.rt_gain = local_get_numeric(Traw, "rt_gain", NaN(n,1));

valid = isfinite(T.gad7) & isfinite(T.state_anx) & isfinite(T.trait_anx) & ...
        isfinite(T.rho) & isfinite(T.lambda_loss) & isfinite(T.mu) & ...
        T.rho > 0 & T.lambda_loss > 0 & T.mu > 0;
T = T(valid, :);
end

function fp = local_find_psych_file(cfg)
if isfield(cfg,'psych') && isfield(cfg.psych,'data_file') && exist(char(cfg.psych.data_file),'file')
    fp = char(cfg.psych.data_file);
    return;
end
ioDir = fileparts(mfilename('fullpath'));
candidates = { ...
    fullfile(ioDir,'Charpentier','data_anx_gad7_prior.csv'), ...
    fullfile(ioDir,'data_anx_gad7_prior.csv')};
for i = 1:numel(candidates)
    if exist(candidates{i}, 'file')
        fp = candidates{i};
        return;
    end
end
error('build_demo_dataset:MissingFerrariFile', ...
    'Cannot find data_anx_gad7_prior.csv. Put it in +p4fresh/+io/Charpentier/ or set cfg.psych.data_file.');
end

function T = local_readtable_robust(fp)
try
    T = readtable(fp, 'VariableNamingRule','preserve', 'TextType','string');
catch
    T = readtable(fp, 'VariableNamingRule','preserve');
end
end

function x = local_get_numeric(T, name, fallback)
names = string(T.Properties.VariableNames);
idx = find(strcmpi(names, string(name)), 1);
if isempty(idx)
    x = fallback;
    if isscalar(x), x = repmat(x, height(T), 1); end
    x = double(x(:));
    return;
end
x = T{:,idx};
if istable(x), x = table2array(x); end
if iscell(x) || iscategorical(x) || ischar(x) || isstring(x)
    x = str2double(string(x));
end
x = double(x(:));
end

function s = local_get_string(T, name, fallback)
names = string(T.Properties.VariableNames);
idx = find(strcmpi(names, string(name)), 1);
if isempty(idx)
    s = string(fallback(:));
    if numel(s)==1, s = repmat(s, height(T), 1); end
    return;
end
s = string(T{:,idx});
s = s(:);
end

function x = local_get_logical(T, name, fallback)
names = string(T.Properties.VariableNames);
idx = find(strcmpi(names, string(name)), 1);
if isempty(idx)
    x = logical(fallback(:));
    return;
end
v = T{:,idx};
if islogical(v)
    x = v(:);
elseif isnumeric(v)
    x = v(:) ~= 0;
else
    s = lower(string(v(:)));
    x = (s == "true") | (s == "1") | (s == "yes") | (s == "high");
end
end

function s = local_empty_subject()
s = struct();
s.subject_idx = int32(0);
s.subject_id = '';
s.original_id = "";
s.age = NaN;
s.gender = '';
s.gad7 = NaN;
s.state_anx = NaN;
s.trait_anx = NaN;
s.rho = NaN;
s.lambda_loss = NaN;
s.mu = NaN;
s.p_gamble = NaN;
s.p_gamble_mixed = NaN;
s.p_gamble_gain = NaN;
s.anx_gad7_median = false;
s.anx_trait_median = false;
s.anx_state_median = false;
s.latent_anxiety = NaN;
s.high_anxiety = false;
s.prefit_behavior_params = struct();
end
