function unifiedFiles = prepare_financial_fuzzy_unified(dataDir, cfg)
%PREPARE_FINANCIAL_FUZZY_UNIFIED Convert FINRA/SCF/SHED raw CSV files to unified schema.
%
% Unified schema:
%   source_id, source_name, task_label, alternative_id, source_row
%   B_capability, B_liquidity, B_experience, B_knowledge, B_stability
%   U_debt, U_fragility, U_low_resilience, U_anxiety, U_complexity
%   A_missingness, ground_truth, ground_truth_label, case_weight
%
% v8 uses this schema to build B/U/K/C/F/W_tail evidence layers.

if nargin < 1 || isempty(dataDir)
    dataDir = fullfile(fileparts(mfilename('fullpath')), 'public_fuzzy_data');
end
if nargin < 2
    cfg = struct(); %#ok<NASGU>
end

if ~exist(dataDir, 'dir'), mkdir(dataDir); end
unifiedDir = fullfile(dataDir, 'financial_unified');
if ~exist(unifiedDir, 'dir'), mkdir(unifiedDir); end

finraFile = local_find_file(dataDir, {'NFCS 2024 State Data 250623.csv','*NFCS*2024*State*.csv','*NFCS*State*.csv'});
scfFile   = local_find_file(dataDir, {'SCFP2022.csv','*SCFP2022*.csv','*SCF*2022*.csv'});
shedFile  = local_find_file(dataDir, {'public2025.csv','*public2025*.csv','*SHED*2025*.csv'});

U_finra = local_prepare_finra(finraFile);
U_scf   = local_prepare_scf(scfFile);
U_shed  = local_prepare_shed(shedFile);

unifiedFiles = strings(3,1);
unifiedFiles(1) = fullfile(unifiedDir, 'financial_unified_FINRA_NFCS_2024_RISK_TOLERANCE.csv');
unifiedFiles(2) = fullfile(unifiedDir, 'financial_unified_SCF_2022_PORTFOLIO_RISK_EXPOSURE.csv');
unifiedFiles(3) = fullfile(unifiedDir, 'financial_unified_SHED_2025_FINANCIAL_RISK_WILLINGNESS.csv');

writetable(U_finra, unifiedFiles(1));
writetable(U_scf, unifiedFiles(2));
writetable(U_shed, unifiedFiles(3));

fprintf('[financial fuzzy] unified tables written to:\n  %s\n', unifiedDir);
fprintf('  FINRA alternatives: %d\n', height(U_finra));
fprintf('  SCF households:     %d\n', height(U_scf));
fprintf('  SHED alternatives:  %d\n', height(U_shed));
end

% =========================================================================
% FINRA
% =========================================================================
function U = local_prepare_finra(fp)
T = local_readtable_robust(fp);
n = height(T);

id = local_num(local_get(T, 'NFCSID'));
if all(~isfinite(id)), id = (1:n)'; end

J1   = local_clean_special(local_num(local_get(T, 'J1')), [98 99]);
J2   = local_clean_special(local_num(local_get(T, 'J2')), [98 99]);
J4   = local_clean_special(local_num(local_get(T, 'J4')), [98 99]);
J5   = local_clean_special(local_num(local_get(T, 'J5')), [98 99]);
J10  = local_clean_special(local_num(local_get(T, 'J10')), [98 99]);
J20  = local_clean_special(local_num(local_get(T, 'J20')), [98 99]);
J33  = local_clean_special(local_num(local_get(T, 'J33_40')), [98 99]);
J411 = local_clean_special(local_num(local_get(T, 'J41_1')), [98 99]);
J412 = local_clean_special(local_num(local_get(T, 'J41_2')), [98 99]);
J413 = local_clean_special(local_num(local_get(T, 'J41_3')), [98 99]);
J422 = local_clean_special(local_num(local_get(T, 'J42_2')), [98 99]);
J43  = local_clean_special(local_num(local_get(T, 'J43')), [98 99]);

B1 = local_clean_special(local_num(local_get(T, 'B1')), [98 99]);
B2 = local_clean_special(local_num(local_get(T, 'B2')), [98 99]);
M4 = local_clean_special(local_num(local_get(T, 'M4')), [98 99]);

wgt = local_num(local_get(T, 'wgt_n2'));
if all(~isfinite(wgt)), wgt = local_num(local_get(T, 'wgt_s3')); end

truth = local_scale_1n(J2, 10);

satisfaction   = local_scale_1n(J1, 10);
goalConfidence = local_scale_1n(J43, 4);
emergencyFund  = local_yes1_no2(J5);
ability2000    = local_map_codes(J20, [1 2 3 4], [1.00 0.67 0.33 0.00]);
banked         = local_rowmax([local_yes1_no2(B1), local_yes1_no2(B2)]);
knowledge      = local_scale_1n(M4, 7);

billDifficulty   = local_map_codes(J4, [1 2 3], [1.00 0.50 0.00]);
incomeShock      = local_yes1_no2(J10);
finAnxiety       = local_scale_1n(J33, 7);
debtStress       = local_rowmean([local_scale_1n(J411,5), local_scale_1n(J412,5), local_scale_1n(J413,5)]);
futureConstraint = local_scale_1n(J422, 5);

Bcap  = local_rowmean([satisfaction, goalConfidence, banked]);
Bliq  = local_rowmean([emergencyFund, ability2000]);
Bexp  = local_rowmean([banked, knowledge]);
Bknow = knowledge;
Bstab = local_rowmean([1-billDifficulty, 1-incomeShock, emergencyFund]);

Udebt    = local_rowmean([debtStress, futureConstraint]);
Ufrag    = local_rowmean([billDifficulty, incomeShock, 1-ability2000]);
Ulowres  = local_rowmean([1-emergencyFund, 1-ability2000]);
Uanx     = finAnxiety;
Ucomplex = 1 - knowledge;

U = local_make_unified_table( ...
    "FINRA_NFCS_2024_RISK_TOLERANCE", ...
    "FINRA NFCS 2024 State Data", ...
    "Rank respondents by stated financial-investment risk tolerance", ...
    "J2 stated willingness to take financial investment risks, normalized 0-1", ...
    "FINRA_" + string(id(:)), id(:), ...
    Bcap, Bliq, Bexp, Bknow, Bstab, ...
    Udebt, Ufrag, Ulowres, Uanx, Ucomplex, truth, wgt);
end

% =========================================================================
% SCF
% =========================================================================
function U = local_prepare_scf(fp)
T = local_readtable_robust(fp);
n = height(T);

YY1 = local_num(local_get(T, 'YY1'));
if all(~isfinite(YY1)), YY1 = local_num(local_get(T, 'Y1')); end
if all(~isfinite(YY1)), YY1 = (1:n)'; end

WGT       = local_num(local_get(T, 'WGT'));
AGE       = local_num(local_get(T, 'AGE'));
INCOME    = local_num(local_get(T, 'INCOME'));
ASSET     = local_num(local_get(T, 'ASSET'));
NETWORTH  = local_num(local_get(T, 'NETWORTH'));
LIQ       = local_num(local_get(T, 'LIQ'));
SAVING    = local_num(local_get(T, 'SAVING'));
SAVED     = local_num(local_get(T, 'SAVED'));
HSAVING   = local_num(local_get(T, 'HSAVING'));
KNOWL     = local_num(local_get(T, 'KNOWL'));
FINLIT    = local_num(local_get(T, 'FINLIT'));
DEBT      = local_num(local_get(T, 'DEBT'));
DEBT2INC  = local_num(local_get(T, 'DEBT2INC'));
HLIQ      = local_num(local_get(T, 'HLIQ'));
YESRISK   = local_num(local_get(T, 'YESFINRISK'));
NORISK    = local_num(local_get(T, 'NOFINRISK'));
EMERGBORR = local_num(local_get(T, 'EMERGBORR'));
EMERGPSTP = local_num(local_get(T, 'EMERGPSTP'));
EMERGCUT  = local_num(local_get(T, 'EMERGCUT'));
EQUITY    = local_num(local_get(T, 'EQUITY'));
FIN       = local_num(local_get(T, 'FIN'));
RETQLIQ   = local_num(local_get(T, 'RETQLIQ'));
HRETQLIQ  = local_num(local_get(T, 'HRETQLIQ'));

truth = EQUITY ./ max(FIN, 1);
truth(~isfinite(truth)) = NaN;
truth = local_clip(truth, 0, 1);

incomeCap        = local_logminmax(INCOME);
assetCap         = local_logminmax(max(ASSET, 0));
networthCap      = local_signed_logminmax(NETWORTH);
liquidity        = local_logminmax(max(LIQ, 0));
savingBal        = local_rowmean([local_logminmax(max(SAVING,0)), local_clean01(SAVED), local_clean01(HSAVING)]);
knowledge        = local_rowmean([local_minmax(KNOWL), local_minmax(FINLIT)]);
retirementBuffer = local_rowmean([local_logminmax(max(RETQLIQ,0)), local_clean01(HRETQLIQ)]);
ageCapacity      = local_clip01(1 - abs(AGE - 45) ./ 45);

debtLoad         = local_rowmean([local_logminmax(max(DEBT,0)), local_minmax(DEBT2INC)]);
debtAsset        = DEBT ./ max(ASSET, 1);
debtAsset(~isfinite(debtAsset)) = NaN;
debtAsset        = local_logminmax(debtAsset);
emergencyStrain  = local_rowmean([local_clean01(EMERGBORR), local_clean01(EMERGPSTP), local_clean01(EMERGCUT)]);
lowLiq           = 1 - local_rowmean([liquidity, local_clean01(HLIQ)]);
riskAversion     = local_rowmean([local_clean01(NORISK), 1-local_clean01(YESRISK)]);
ageConstraint    = local_clip01((AGE - 55) ./ 35);

Bcap  = local_rowmean([incomeCap, assetCap, networthCap]);
Bliq  = local_rowmean([liquidity, savingBal]);
Bexp  = local_rowmean([retirementBuffer, local_clean01(HRETQLIQ), local_clean01(HLIQ)]);
Bknow = knowledge;
Bstab = local_rowmean([savingBal, liquidity, 1-debtLoad, ageCapacity]);

Udebt    = local_rowmean([debtLoad, debtAsset]);
Ufrag    = local_rowmean([emergencyStrain, lowLiq]);
Ulowres  = local_rowmean([lowLiq, 1-savingBal]);
Uanx     = local_rowmean([riskAversion, emergencyStrain]);
Ucomplex = local_rowmean([1-knowledge, ageConstraint]);

U = local_make_unified_table( ...
    "SCF_2022_PORTFOLIO_RISK_EXPOSURE", ...
    "Federal Reserve SCF 2022", ...
    "Rank households by revealed risky financial-asset exposure", ...
    "EQUITY / FIN risky financial-asset share, normalized 0-1", ...
    "SCF_" + string(YY1(:)), YY1(:), ...
    Bcap, Bliq, Bexp, Bknow, Bstab, ...
    Udebt, Ufrag, Ulowres, Uanx, Ucomplex, truth, WGT);

U = local_collapse_unified_by_source_row(U, "SCF_");
end

% =========================================================================
% SHED
% =========================================================================
function U = local_prepare_shed(fp)
T = local_readtable_robust(fp);
n = height(T);

id = local_num(local_get(T, 'shedid'));
if all(~isfinite(id)), id = (1:n)'; end

W     = local_num(local_get(T, 'weight'));
B2    = local_get(T, 'B2');
B3    = local_get(T, 'B3');
EF1   = local_get(T, 'EF1');
EF3b  = local_get(T, 'EF3_b');
EF3c  = local_get(T, 'EF3_c');
EF3e  = local_get(T, 'EF3_e');
EF3f  = local_get(T, 'EF3_f');
EF3g  = local_get(T, 'EF3_g');
EF3h  = local_get(T, 'EF3_h');
EF5D  = local_get(T, 'EF5D');
K21a  = local_get(T, 'K21_a');
K21b  = local_get(T, 'K21_b');
K21c  = local_get(T, 'K21_c');
K21d  = local_get(T, 'K21_d');
K21e  = local_get(T, 'K21_e');
DC4   = local_get(T, 'DC4');
FL0   = local_get(T, 'FL0');

truthRaw = local_extract_number(FL0);
truth = truthRaw ./ 10;
truth(truthRaw < 0 | truthRaw > 10) = NaN;

finStatus = local_ordered_text(B2, ...
    ["Finding it difficult to get by","Just getting by","Doing okay","Living comfortably"], ...
    [0.00 0.33 0.67 1.00]);
changeStatus = local_ordered_text(B3, ...
    ["Much worse off","Somewhat worse off","About the same","Somewhat better off","Much better off"], ...
    [0.00 0.25 0.50 0.75 1.00]);

emergencyFund = local_yesno_text(EF1);
cashAble      = local_yesno_text(EF3c);
investmentComfort = local_ordered_text(DC4, ...
    ["Not comfortable","Slightly comfortable","Somewhat comfortable","Mostly comfortable","Very comfortable"], ...
    [0.00 0.25 0.40 0.70 1.00]);
assetParticipation = local_rowmean([ ...
    local_yesno_text(K21a), local_yesno_text(K21b), local_yesno_text(K21c), ...
    local_yesno_text(K21d), local_yesno_text(K21e)]);

creditBurden  = local_yesno_text(EF3b);
borrowNeed    = local_rowmean([local_yesno_text(EF3e), local_yesno_text(EF3f), local_yesno_text(EF3g)]);
unablePay     = local_yesno_text(EF3h);
billDifficulty = local_yesno_text(EF5D);

Bcap  = local_rowmean([finStatus, changeStatus]);
Bliq  = local_rowmean([emergencyFund, cashAble]);
Bexp  = assetParticipation;
Bknow = investmentComfort;
Bstab = local_rowmean([finStatus, emergencyFund, changeStatus]);

Udebt    = local_rowmean([creditBurden, billDifficulty]);
Ufrag    = local_rowmean([borrowNeed, unablePay]);
Ulowres  = local_rowmean([1-emergencyFund, 1-cashAble, unablePay]);
Uanx     = local_rowmean([1-finStatus, 1-changeStatus, billDifficulty]);
Ucomplex = 1 - investmentComfort;

U = local_make_unified_table( ...
    "SHED_2025_FINANCIAL_RISK_WILLINGNESS", ...
    "Federal Reserve SHED 2025", ...
    "Rank respondents by stated willingness to take financial risks", ...
    "FL0 stated willingness to take financial risks, normalized 0-1", ...
    "SHED_" + string(id(:)), id(:), ...
    Bcap, Bliq, Bexp, Bknow, Bstab, ...
    Udebt, Ufrag, Ulowres, Uanx, Ucomplex, truth, W);
end

% =========================================================================
% Unified table utilities
% =========================================================================
function U = local_make_unified_table(sourceId, sourceName, taskLabel, truthLabel, altId, sourceRow, Bcap, Bliq, Bexp, Bknow, Bstab, Udebt, Ufrag, Ulowres, Uanx, Ucomplex, truth, weight)
n = numel(sourceRow);

U = table();
U.source_id = repmat(string(sourceId), n, 1);
U.source_name = repmat(string(sourceName), n, 1);
U.task_label = repmat(string(taskLabel), n, 1);
U.alternative_id = string(altId(:));
U.source_row = double(sourceRow(:));

U.B_capability = local_clip01(Bcap(:));
U.B_liquidity = local_clip01(Bliq(:));
U.B_experience = local_clip01(Bexp(:));
U.B_knowledge = local_clip01(Bknow(:));
U.B_stability = local_clip01(Bstab(:));

U.U_debt = local_clip01(Udebt(:));
U.U_fragility = local_clip01(Ufrag(:));
U.U_low_resilience = local_clip01(Ulowres(:));
U.U_anxiety = local_clip01(Uanx(:));
U.U_complexity = local_clip01(Ucomplex(:));

critRaw = [Bcap(:), Bliq(:), Bexp(:), Bknow(:), Bstab(:), Udebt(:), Ufrag(:), Ulowres(:), Uanx(:), Ucomplex(:)];
U.A_missingness = local_clip01(mean(~isfinite(critRaw), 2));

U.ground_truth = local_clip01(truth(:));
U.ground_truth_label = repmat(string(truthLabel), n, 1);

if nargin < 18 || isempty(weight), weight = ones(n,1); end
weight = local_num(weight);
weight(~isfinite(weight) | weight <= 0) = 1;
U.case_weight = double(weight(:));

crit = [U.B_capability U.B_liquidity U.B_experience U.B_knowledge U.B_stability ...
        U.U_debt U.U_fragility U.U_low_resilience U.U_anxiety U.U_complexity];
validCrit = sum(isfinite(crit), 2) >= 6;
validTruth = isfinite(U.ground_truth);
validSource = isfinite(U.source_row);
U = U(validCrit & validTruth & validSource, :);

critNames = ["B_capability","B_liquidity","B_experience","B_knowledge","B_stability", ...
             "U_debt","U_fragility","U_low_resilience","U_anxiety","U_complexity","A_missingness"];
for j = 1:numel(critNames)
    v = U.(critNames(j));
    fill = median(v(isfinite(v)));
    if isempty(fill) || ~isfinite(fill), fill = 0.5; end
    v(~isfinite(v)) = fill;
    U.(critNames(j)) = local_clip01(v);
end
end

function U2 = local_collapse_unified_by_source_row(U, altPrefix)
[G, keys] = findgroups(U.source_row);
nG = numel(keys);

U2 = table();
U2.source_id = repmat(U.source_id(1), nG, 1);
U2.source_name = repmat(U.source_name(1), nG, 1);
U2.task_label = repmat(U.task_label(1), nG, 1);
U2.alternative_id = string(altPrefix) + string(keys(:));
U2.source_row = keys(:);

numFields = ["B_capability","B_liquidity","B_experience","B_knowledge","B_stability", ...
             "U_debt","U_fragility","U_low_resilience","U_anxiety","U_complexity", ...
             "A_missingness", "ground_truth","case_weight"];
for j = 1:numel(numFields)
    U2.(numFields(j)) = splitapply(@local_mean_omitnan, U.(numFields(j)), G);
end
U2.ground_truth_label = repmat(U.ground_truth_label(1), nG, 1);
U2 = U2(isfinite(U2.ground_truth), :);
end

function m = local_mean_omitnan(x)
x = x(isfinite(x));
if isempty(x), m = NaN; else, m = mean(x); end
end

% =========================================================================
% Helpers
% =========================================================================
function fp = local_find_file(dataDir, patterns)
fp = '';
for k = 1:numel(patterns)
    pattern = patterns{k};
    if contains(pattern, '*')
        d = dir(fullfile(dataDir, pattern));
        if ~isempty(d), fp = fullfile(d(1).folder, d(1).name); return; end
    else
        cand = fullfile(dataDir, pattern);
        if exist(cand, 'file'), fp = cand; return; end
    end
end
msg = sprintf('  %s\n', patterns{:});
error('prepare_financial_fuzzy_unified:MissingFile', ...
    ['Missing required financial survey CSV in:\n  %s\n\nExpected one of:\n%s'], dataDir, msg);
end

function T = local_readtable_robust(fp)
try
    opts = detectImportOptions(fp, 'VariableNamingRule', 'preserve');
    try, opts.ExtraColumnsRule = 'ignore'; catch, end
    T = readtable(fp, opts);
catch
    try
        T = readtable(fp, 'VariableNamingRule', 'preserve', 'TextType', 'string');
    catch
        T = readtable(fp, 'VariableNamingRule', 'preserve');
    end
end
end

function x = local_get(T, name)
names = string(T.Properties.VariableNames);
idx = find(strcmpi(names, string(name)), 1, 'first');
if isempty(idx), x = NaN(height(T),1); else, x = T{:, idx}; end
end

function y = local_num(x)
if istable(x), x = table2array(x); end
if isnumeric(x) || islogical(x), y = double(x(:)); return; end
s = local_to_string_vector(x);
y = str2double(local_strip_numeric_string(s));
bad = isnan(y) & ~ismissing(s) & strlength(s) > 0;
if any(bad), y(bad) = local_extract_number(s(bad)); end
y = double(y(:));
end

function s = local_to_string_vector(x)
if iscell(x), x = string(x);
elseif iscategorical(x), x = string(x);
elseif ischar(x), x = string(cellstr(x)); end
try
    s = string(x(:));
catch
    s = strings(numel(x),1);
    s(:) = missing;
end
s = strip(s);
bad = ismissing(s) | lower(s)=="na" | lower(s)=="nan" | lower(s)=="not asked" | ...
      lower(s)=="refused" | lower(s)=="don't know" | lower(s)=="dont know" | lower(s)=="";
s(bad) = missing;
end

function s = local_strip_numeric_string(s)
s = string(s(:));
s(ismissing(s)) = missing;
s = replace(s, ",", "");
end

function y = local_extract_number(x)
s = local_to_string_vector(x);
y = NaN(numel(s),1);
for i = 1:numel(s)
    if ismissing(s(i)) || strlength(s(i)) == 0, continue; end
    tok = regexp(char(s(i)), '[-+]?\d+(\.\d+)?', 'match', 'once');
    if ~isempty(tok), y(i) = str2double(tok); end
end
end

function x = local_clean_special(x, codes)
x = double(x(:));
for c = 1:numel(codes), x(x == codes(c)) = NaN; end
end

function z = local_yes1_no2(x)
x = double(x(:));
z = NaN(size(x));
z(x == 1) = 1; z(x == 2) = 0; z(x == 0) = 0;
end

function z = local_yesno_text(x)
s = lower(local_to_string_vector(x));
z = NaN(numel(s),1);
idx = ~ismissing(s) & contains(s, "not selected"); z(idx) = 0;
idx = ~ismissing(s) & contains(s, "selected") & isnan(z); z(idx) = 1;
idx = ~ismissing(s) & (s == "yes") & isnan(z); z(idx) = 1;
idx = ~ismissing(s) & (s == "no") & isnan(z); z(idx) = 0;
num = str2double(local_strip_numeric_string(s));
z(num == 1) = 1; z(num == 0) = 0; z(num == 2) = 0;
end

function z = local_ordered_text(x, keys, vals)
s = lower(local_to_string_vector(x));
keys = lower(strip(string(keys(:))));
vals = double(vals(:));
z = NaN(numel(s),1);
[~, ord] = sort(strlength(keys), 'descend');
for ii = 1:numel(ord)
    k = ord(ii);
    hit = ~ismissing(s) & contains(s, keys(k));
    z(hit) = vals(k);
end
num = local_extract_number(s);
fallback = isfinite(num) & ~isfinite(z);
if any(fallback)
    mm = local_minmax(num);
    z(fallback) = mm(fallback);
end
end

function z = local_map_codes(x, keys, vals)
x = double(x(:));
z = NaN(size(x));
for k = 1:numel(keys), z(x == keys(k)) = vals(k); end
end

function z = local_scale_1n(x, n)
x = double(x(:));
z = (x - 1) ./ max(n - 1, eps);
z(~isfinite(z)) = NaN;
z = local_clip01(z);
end

function z = local_clean01(x)
x = double(x(:));
z = x;
z(~isfinite(z)) = NaN;
if all(~isfinite(z) | ismember(z, [0 1])), return; end
z = local_minmax(z);
end

function z = local_minmax(x)
x = double(x(:));
z = NaN(size(x));
mask = isfinite(x);
if ~any(mask), return; end
lo = min(x(mask)); hi = max(x(mask));
if hi <= lo + eps, z(mask) = 0.5; else, z(mask) = (x(mask) - lo) ./ (hi - lo); end
z = local_clip01(z);
end

function z = local_logminmax(x)
x = double(x(:));
x(~isfinite(x)) = NaN;
x = max(x, 0);
z = local_minmax(log1p(x));
end

function z = local_signed_logminmax(x)
x = double(x(:));
x(~isfinite(x)) = NaN;
z = local_minmax(sign(x) .* log1p(abs(x)));
end

function y = local_rowmean(M)
M = double(M);
try
    y = mean(M, 2, 'omitnan');
catch
    mask = isfinite(M);
    M2 = M; M2(~mask) = 0;
    y = sum(M2, 2) ./ max(sum(mask, 2), 1);
    y(sum(mask,2)==0) = NaN;
end
end

function y = local_rowmax(M)
M = double(M);
y = NaN(size(M,1),1);
for i = 1:size(M,1)
    row = M(i,:);
    row = row(isfinite(row));
    if ~isempty(row), y(i) = max(row); end
end
end

function x = local_clip01(x)
x = local_clip(x, 0, 1);
end

function x = local_clip(x, lo, hi)
x = min(max(double(x), lo), hi);
end
