function info = indexing_convention()
info = struct();
info.subject = 'l';
info.trial = 't';
info.action = 'a';
info.alternative = 'i';
info.criterion = 'j';
info.ldf_component = 'k';
info.ldf_layout = 'X(l,i,j,k)';
end
