function export_stageA1_tables_csv(diagnostics, cfg)
%EXPORT_STAGEA1_TABLES_CSV Export APF-DS-XAI v8 diagnostics.
%
% v8 export discipline:
%   deployable_outputs/  : truth-free DSS/action/XAI artifacts.
%   posthoc_validation/  : tables that contain held-out truth, validation
%                          metrics, audit residuals, or post-hoc statistics.
%
% This separation prevents deployable risk-communication explanations from
% being confused with validation/audit outputs.

if nargin < 2 || ~isfield(cfg,'report') || ~isfield(cfg.report,'csv_dir')
    outDir = fullfile(pwd, 'paper4_apfds_xai_v8_csv');
else
    outDir = cfg.report.csv_dir;
end
if ~exist(outDir,'dir'), mkdir(outDir); end

deployDir = fullfile(outDir, 'deployable_outputs');
posthocDir = fullfile(outDir, 'posthoc_validation');
if ~exist(deployDir,'dir'), mkdir(deployDir); end
if ~exist(posthocDir,'dir'), mkdir(posthocDir); end

names = fieldnames(diagnostics.tables);
for i = 1:numel(names)
    nm = string(names{i});
    T = diagnostics.tables.(names{i});
    if ~istable(T), continue; end
    if local_is_posthoc_table(nm, T)
        targetDir = posthocDir;
    else
        targetDir = deployDir;
        local_assert_no_deployable_leakage(T, nm);
    end
    writetable(T, fullfile(targetDir, char(nm + ".csv")));
end
end

function tf = local_is_posthoc_table(nm, T)
nm = lower(string(nm));
posthocNames = ["validation","audit","truth","bootstrap","comparison","ablation","support_proxy","profile_validation", ...
    "validation_component","validation_table","weighted_validation","validation_matrix"];
tf = any(contains(nm, posthocNames));
if ~tf
    tf = local_has_forbidden_deployable_vars(T);
end
end

function tf = local_has_forbidden_deployable_vars(T)
names = lower(string(T.Properties.VariableNames));
tf = false;
for i = 1:numel(names)
    nm = names(i);
    if contains(nm,"truth") || contains(nm,"ground_truth") || contains(nm,"expert") || contains(nm,"future") || contains(nm,"outcome") || contains(nm,"audit")
        tf = true; return;
    end
    if contains(nm,"residual") && ~(nm == "g_info_resid")
        tf = true; return;
    end
end
end

function local_assert_no_deployable_leakage(T, nm)
if local_has_forbidden_deployable_vars(T)
    error('export_stageA1_tables_csv:LeakageTableInDeployableOutput', ...
        'Table %s contains truth/audit/outcome columns and cannot be exported as deployable output.', string(nm));
end
end
