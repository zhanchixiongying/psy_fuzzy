function export_stageA1_tables_csv(diagnostics, cfg)
outDir = cfg.report.csv_dir;
if ~exist(outDir, 'dir')
    mkdir(outDir);
end
names = fieldnames(diagnostics.tables);
for i = 1:numel(names)
    nm = names{i};
    T = diagnostics.tables.(nm);
    p4fresh.utils.safe_table_write(T, fullfile(outDir, [nm '.csv']));
end
end
