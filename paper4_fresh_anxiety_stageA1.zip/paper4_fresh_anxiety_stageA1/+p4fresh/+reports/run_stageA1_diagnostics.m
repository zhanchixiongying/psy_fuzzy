function diagnostics = run_stageA1_diagnostics(caseA, transfer, cfg)
T = p4fresh.schema.templates();
subject_results = caseA.subject_results;
nS = numel(subject_results);
fams = string(cfg.model.families(:));

diagCfg = get_diag_cfg(cfg);

subject_rows = repmat(T.diag_subject_row, nS, 1);
parameter_rows = repmat(T.diag_param_row, nS, 1);
anomaly_rows = repmat(T.diag_anomaly_row, nS, 1);

nFamSub = nS * numel(fams);
family_subject_rows = repmat(T.diag_family_subject_row, nFamSub, 1);

fsPtr = 0;
all_alpha = zeros(nS,1); all_kappa=zeros(nS,1); all_csub=zeros(nS,1);
all_lambda=zeros(nS,1); all_beta=zeros(nS,1); all_w=zeros(nS,1);

bestNllVec = nan(nS,1);
sampleRateVec = nan(nS,1);
accVec = nan(nS,1);

for s = 1:nS
    sr = subject_results(s);
    br = sr.best_result;
    bs = br.behavior_summary;

    row = T.diag_subject_row;
    row.subject_idx = sr.subject_idx;
    row.subject_id = sr.subject_id;
    row.best_family = sr.best_family;
    row.mean_A = sr.latent_summary.latent_total_mean;
    row.choice_accuracy = bs.choice_accuracy;
    row.sample_obs_rate = bs.sample_obs_rate;
    row.mean_sample_prob = bs.mean_sample_prob;
    row.mean_confidence_obs = bs.mean_confidence_obs;
    row.mean_confidence_pred = bs.mean_confidence_pred;
    row.best_nll = br.nll;
    subject_rows(s,1) = row;

    prow = T.diag_param_row;
    prow.subject_idx = sr.subject_idx;
    prow.subject_id = sr.subject_id;
    prow.best_family = sr.best_family;
    prow.alpha = bs.mean_alpha;
    prow.kappa = bs.mean_kappa;
    prow.csub = bs.mean_csub;
    prow.lambda = bs.mean_lambda;
    prow.beta = bs.mean_beta;
    prow.w = bs.mean_w;
    parameter_rows(s,1) = prow;

    all_alpha(s)=prow.alpha; all_kappa(s)=prow.kappa; all_csub(s)=prow.csub;
    all_lambda(s)=prow.lambda; all_beta(s)=prow.beta; all_w(s)=prow.w;

    bestNllVec(s) = br.nll;
    sampleRateVec(s) = bs.sample_obs_rate;
    accVec(s) = bs.choice_accuracy;

    fr = sr.family_results;
    nlls = [fr.nll];
    aics = [fr.aic];
    bics = [fr.bic];
    [~, ord] = sort(nlls, 'ascend');
    for r = 1:numel(fr)
        fidx = ord(r);
        fsPtr = fsPtr + 1;
        frow = T.diag_family_subject_row;
        frow.subject_idx = sr.subject_idx;
        frow.subject_id = sr.subject_id;
        frow.family = fr(fidx).family;
        frow.rank = int32(r);
        frow.is_best = (r == 1);
        frow.nll = fr(fidx).nll;
        frow.aic = fr(fidx).aic;
        frow.bic = fr(fidx).bic;
        frow.delta_nll = fr(fidx).nll - min(nlls);
        frow.delta_aic = fr(fidx).aic - min(aics);
        frow.delta_bic = fr(fidx).bic - min(bics);
        family_subject_rows(fsPtr,1) = frow;
    end
end

family_rows = repmat(T.diag_family_row, numel(fams), 1);
for f = 1:numel(fams)
    fam = fams(f);
    mask = string({family_subject_rows.family})' == fam;
    rows = family_subject_rows(mask);
    frow = T.diag_family_row;
    frow.family = fam;
    frow.win_count = int32(sum([rows.is_best]));
    frow.win_rate = mean([rows.is_best]);
    frow.mean_rank = mean(double([rows.rank]));
    frow.mean_nll = mean([rows.nll]);
    frow.mean_aic = mean([rows.aic]);
    frow.mean_bic = mean([rows.bic]);
    family_rows(f,1) = frow;
end

parameter_boundary_rows = repmat(T.diag_param_boundary_row, 6, 1);
vals = {all_alpha, all_kappa, all_csub, all_lambda, all_beta, all_w};
pnames = ["alpha","kappa","csub","lambda","beta","w"];
for p = 1:6
    v = vals{p}(:);
    pb = T.diag_param_boundary_row;
    pb.parameter_name = pnames(p);
    pb.q05 = quantile(v,0.05);
    pb.q50 = quantile(v,0.50);
    pb.q95 = quantile(v,0.95);
    [lb, ub] = get_display_bounds(cfg, pnames(p));
    pb.bounded_upper = true;
    pb.near_lower_count = int32(sum(v <= lb));
    pb.near_lower_rate = mean(v <= lb);
    pb.near_upper_count = int32(sum(v >= ub));
    pb.near_upper_rate = mean(v >= ub);
    parameter_boundary_rows(p,1) = pb;
end

useDistributionFlags = nS >= diagCfg.min_subjects_for_distribution_flags;
if useDistributionFlags
    accThresh = min(quantile(accVec, diagCfg.low_accuracy_quantile), diagCfg.low_accuracy_absolute_ceiling);
    nllThresh = quantile(bestNllVec, diagCfg.high_nll_quantile);
    sampLow = quantile(sampleRateVec, diagCfg.extreme_sampling_lower_quantile);
    sampHigh = quantile(sampleRateVec, diagCfg.extreme_sampling_upper_quantile);
    useSamplingFlag = (sampHigh - sampLow) >= diagCfg.min_sampling_spread_for_flag;
else
    accThresh = NaN;
    nllThresh = NaN;
    sampLow = NaN;
    sampHigh = NaN;
    useSamplingFlag = false;
end

for s = 1:nS
    ar = T.diag_anomaly_row;
    ar.subject_idx = subject_rows(s).subject_idx;
    ar.subject_id = subject_rows(s).subject_id;

    if useDistributionFlags
        ar.flag_low_accuracy = subject_rows(s).choice_accuracy <= accThresh;
        if useSamplingFlag
            ar.flag_extreme_sampling = (subject_rows(s).sample_obs_rate <= sampLow) || (subject_rows(s).sample_obs_rate >= sampHigh);
        else
            ar.flag_extreme_sampling = false;
        end
        ar.flag_high_nll = subject_rows(s).best_nll >= nllThresh;
    else
        ar.flag_low_accuracy = false;
        ar.flag_extreme_sampling = false;
        ar.flag_high_nll = false;
    end

    paramRow = parameter_rows(s);
    nBoundaryBreaches = count_anomaly_boundary_breaches(paramRow, diagCfg.anomaly_boundary);
    ar.flag_parameter_boundary = nBoundaryBreaches >= diagCfg.anomaly_boundary.min_breaches_for_flag;

    ar.n_flags = int32(double(ar.flag_low_accuracy) + ...
                       double(ar.flag_extreme_sampling) + ...
                       double(ar.flag_high_nll) + ...
                       double(ar.flag_parameter_boundary));
    ar.is_anomaly = ar.n_flags >= diagCfg.min_total_flags_for_anomaly;
    anomaly_rows(s,1) = ar;
end

tr = T.transfer_row;
tr.top1_name = transfer.summary.top1_name;
tr.top1_idx = transfer.summary.top1_idx;
tr.top2_name = transfer.summary.top2_name;
tr.top2_idx = transfer.summary.top2_idx;
tr.head_gap = transfer.summary.head_gap;
tr.score_range = transfer.summary.score_range;
tr.head_gap_ratio = transfer.summary.head_gap_ratio;

transfer_alt_rows = repmat(T.transfer_alt_row, numel(transfer.G), 1);
scores = transfer.G(:);
ord = transfer.rank_order(:);
for r = 1:numel(ord)
    altIdx = ord(r);
    row = T.transfer_alt_row;
    row.alternative_idx = int32(altIdx);
    row.alternative_name = transfer.rank_names(r);
    row.rank = int32(r);
    row.score = scores(altIdx);
    row.gap_to_best = scores(ord(1)) - scores(altIdx);
    if r == 1
        row.gap_to_prev = NaN;
    else
        row.gap_to_prev = scores(ord(r-1)) - scores(altIdx);
    end
    transfer_alt_rows(r,1) = row;
end

tables = struct();
tables.subject_table = struct2table(subject_rows);
tables.family_table = struct2table(family_rows);
tables.family_subject_table = struct2table(family_subject_rows);
tables.parameter_table = struct2table(parameter_rows);
tables.parameter_boundary_table = struct2table(parameter_boundary_rows);
tables.anomaly_table = struct2table(anomaly_rows);
tables.transfer_table = struct2table(tr);
tables.transfer_alt_table = struct2table(transfer_alt_rows);

[~, domIdx] = max([family_rows.win_rate]);
bestWin = family_rows(domIdx).win_rate;
otherWins = [family_rows.win_rate];
otherWins(domIdx) = [];
if isempty(otherWins)
    dominanceClear = true;
else
    dominanceClear = (bestWin - max(otherWins)) >= 0.20;
end

summary = struct();
summary.best_family = caseA.summary.best_family;
summary.mean_choice_accuracy = caseA.summary.mean_choice_accuracy;
summary.mean_sample_prob = caseA.summary.mean_sample_prob;
summary.family_dominance_clear = dominanceClear;
summary.n_anomalous_subjects = sum([anomaly_rows.is_anomaly]);
summary.anomaly_rate = mean([anomaly_rows.is_anomaly]);
warningRates = max([[parameter_boundary_rows.near_lower_rate]' [parameter_boundary_rows.near_upper_rate]'], [], 2);
summary.n_parameter_boundary_warnings = sum(warningRates >= diagCfg.parameter_warning_rate_threshold);
summary.head_gap = tr.head_gap;
summary.head_gap_ratio = tr.head_gap_ratio;
summary.head_gap_warning = ~(isnan(tr.head_gap_ratio)) && tr.head_gap_ratio < 0.10;
nonbest = tables.family_subject_table(~tables.family_subject_table.is_best, :);
summary.mean_delta_nll_nonbest = mean(nonbest.delta_nll);
summary.small_sample_guard = ~useDistributionFlags;
summary.low_accuracy_threshold = accThresh;
summary.high_nll_threshold = nllThresh;
summary.parameter_warning_rate_threshold = diagCfg.parameter_warning_rate_threshold;
summary.min_boundary_breaches_for_flag = diagCfg.anomaly_boundary.min_breaches_for_flag;

diagnostics = struct();
diagnostics.meta = struct('stage','A.1','n_subjects',nS,'n_families',numel(fams));
diagnostics.subject_rows = subject_rows;
diagnostics.family_rows = family_rows;
diagnostics.family_subject_rows = family_subject_rows;
diagnostics.parameter_rows = parameter_rows;
diagnostics.parameter_boundary_rows = parameter_boundary_rows;
diagnostics.anomaly_rows = anomaly_rows;
diagnostics.transfer_row = tr;
diagnostics.transfer_alt_rows = transfer_alt_rows;
diagnostics.tables = tables;
diagnostics.summary = summary;
end

function diagCfg = get_diag_cfg(cfg)
if isfield(cfg, 'diagnostics') && ~isempty(cfg.diagnostics)
    diagCfg = cfg.diagnostics;
else
    diagCfg = struct();
end

if ~isfield(diagCfg, 'min_subjects_for_distribution_flags'), diagCfg.min_subjects_for_distribution_flags = 30; end
if ~isfield(diagCfg, 'low_accuracy_quantile'), diagCfg.low_accuracy_quantile = 0.10; end
if ~isfield(diagCfg, 'low_accuracy_absolute_ceiling'), diagCfg.low_accuracy_absolute_ceiling = 0.40; end
if ~isfield(diagCfg, 'high_nll_quantile'), diagCfg.high_nll_quantile = 0.90; end
if ~isfield(diagCfg, 'extreme_sampling_lower_quantile'), diagCfg.extreme_sampling_lower_quantile = 0.02; end
if ~isfield(diagCfg, 'extreme_sampling_upper_quantile'), diagCfg.extreme_sampling_upper_quantile = 0.98; end
if ~isfield(diagCfg, 'min_sampling_spread_for_flag'), diagCfg.min_sampling_spread_for_flag = 0.15; end
if ~isfield(diagCfg, 'min_total_flags_for_anomaly'), diagCfg.min_total_flags_for_anomaly = 2; end
if ~isfield(diagCfg, 'parameter_warning_rate_threshold'), diagCfg.parameter_warning_rate_threshold = 0.20; end

if ~isfield(diagCfg, 'anomaly_boundary') || isempty(diagCfg.anomaly_boundary)
    diagCfg.anomaly_boundary = struct();
end
ab = diagCfg.anomaly_boundary;
if ~isfield(ab, 'lower01'), ab.lower01 = 1e-3; end
if ~isfield(ab, 'upper01'), ab.upper01 = 0.999; end
if ~isfield(ab, 'lowerPos'), ab.lowerPos = 1e-6; end
if ~isfield(ab, 'upperPos'), ab.upperPos = 30.0; end
if ~isfield(ab, 'min_breaches_for_flag'), ab.min_breaches_for_flag = 2; end
diagCfg.anomaly_boundary = ab;
end

function [lb, ub] = get_display_bounds(cfg, pname)
if ismember(string(pname), ["alpha","kappa","lambda","w"])
    lb = cfg.boundary.lower01;
    ub = cfg.boundary.upper01;
else
    lb = cfg.boundary.lowerPos;
    ub = cfg.boundary.upperPos;
end
end

function n = count_anomaly_boundary_breaches(paramRow, ab)
n = 0;
if (paramRow.alpha <= ab.lower01) || (paramRow.alpha >= ab.upper01), n = n + 1; end
if (paramRow.kappa <= ab.lower01) || (paramRow.kappa >= ab.upper01), n = n + 1; end
if (paramRow.lambda <= ab.lower01) || (paramRow.lambda >= ab.upper01), n = n + 1; end
if (paramRow.w <= ab.lower01) || (paramRow.w >= ab.upper01), n = n + 1; end
if (paramRow.csub <= ab.lowerPos) || (paramRow.csub >= ab.upperPos), n = n + 1; end
if (paramRow.beta <= ab.lowerPos) || (paramRow.beta >= ab.upperPos), n = n + 1; end
end
