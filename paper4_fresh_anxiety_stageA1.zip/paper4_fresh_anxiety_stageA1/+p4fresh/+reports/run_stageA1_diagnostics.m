function diagnostics = run_stageA1_diagnostics(caseA, transfer, cfg)
%RUN_STAGEA1_DIAGNOSTICS APF-DS-XAI v8 diagnostics.
%
% v8 separates:
%   risk validation: G_base
%   sanity: G_PT_mean ~= G_base
%   mechanism: D_PT, Pol_PT, D_support, Pol_support, G_mechanism_load
%   deployable actions: leak-free deployable_action_table
%   audit: post-hoc audit_table using truth variance/residuals

if nargin < 3
    cfg = struct(); %#ok<NASGU>
end
P = caseA.parameter_table;

subject_table = P(:, {'subject_idx','subject_id','gad7','state_anx','trait_anx','psi_anxiety','high_anxiety','p_gamble'});
parameter_table = P;

transfer_table = table();
transfer_table.model_mode = string(transfer.model_mode);
transfer_table.primary_score = string(transfer.primary_score);
transfer_table.top1_name = string(transfer.summary.top1_name);
transfer_table.top1_idx = int32(transfer.summary.top1_idx);
transfer_table.top2_name = string(transfer.summary.top2_name);
transfer_table.top2_idx = int32(transfer.summary.top2_idx);
transfer_table.head_gap = transfer.summary.head_gap;
transfer_table.head_gap_rank_key = transfer.summary.head_gap_rank_key;
transfer_table.score_range = transfer.summary.score_range;
transfer_table.head_gap_ratio = transfer.summary.head_gap_ratio;
transfer_table.PT_mean_degeneracy_max_abs = transfer.summary.PT_mean_degeneracy_max_abs;
transfer_table.PT_mean_degeneracy_mean_abs = transfer.summary.PT_mean_degeneracy_mean_abs;
transfer_table.deployable_action_leakage_free = logical(transfer.sanity.deployable_action_leakage_free);

validation_table = local_validation_table(transfer);
validation_matrix = local_validation_matrix();
weighted_validation_table = local_weighted_validation_table(transfer);
score_table = local_score_table(transfer);
mechanism_table = local_mechanism_table(transfer);
sanity_table = local_sanity_table(transfer);

diagnostics = struct();
diagnostics.meta = struct('stage',"apf_ds_xai_v8", 'n_subjects',height(P));
diagnostics.summary = struct();
diagnostics.summary.model_mode = string(transfer.model_mode);
diagnostics.summary.primary_score = string(transfer.primary_score);
diagnostics.summary.mean_risk_tolerance = mean(P.risk_tolerance,'omitnan');
diagnostics.summary.mean_loss_sensitivity = mean(P.loss_sensitivity,'omitnan');
diagnostics.summary.mean_choice_precision = mean(P.choice_precision,'omitnan');
diagnostics.summary.mean_worst_case_sensitivity = mean(P.worst_case_sensitivity,'omitnan');
diagnostics.summary.mean_abs_D_PT = mean(abs(transfer.G_D_PT),'omitnan');
diagnostics.summary.mean_Pol_PT = mean(transfer.G_Pol_PT,'omitnan');
diagnostics.summary.mean_abs_D_support = mean(abs(transfer.G_D_support),'omitnan');
diagnostics.summary.mean_Pol_support = mean(transfer.G_Pol_support,'omitnan');
diagnostics.summary.mean_information_need = mean(transfer.G_information_need,'omitnan');
diagnostics.summary.mean_information_need_resid = mean(transfer.G_information_need_resid,'omitnan');
diagnostics.summary.mean_mechanism_load = mean(transfer.G_mechanism_load,'omitnan');
diagnostics.summary.mean_communication_burden = mean(transfer.G_communication_burden,'omitnan');
if isfield(transfer,'action_flag_rate_table') && ~isempty(transfer.action_flag_rate_table)
    idxAnx = find(transfer.action_flag_rate_table.flag == "anxiety_sensitive", 1);
    if ~isempty(idxAnx), diagnostics.summary.flag_anxiety_rate = transfer.action_flag_rate_table.rate(idxAnx); else, diagnostics.summary.flag_anxiety_rate = NaN; end
else
    diagnostics.summary.flag_anxiety_rate = NaN;
end
diagnostics.summary.PT_mean_degeneracy_max_abs = transfer.sanity.PT_mean_minus_base_max_abs;
diagnostics.summary.deployable_action_leakage_free = logical(transfer.sanity.deployable_action_leakage_free);
diagnostics.summary.head_gap = transfer.summary.head_gap;
diagnostics.summary.head_gap_ratio = transfer.summary.head_gap_ratio;

nAlt = numel(transfer.rank_order);
rank = int32((1:nAlt)');
alternative_idx = int32(transfer.rank_order(:));
alternative_name = string(transfer.rank_names(:));
transfer_alt_table = table(rank, alternative_idx, alternative_name, ...
    transfer.G(alternative_idx), transfer.G_base(alternative_idx), transfer.G_PT_mean(alternative_idx), ...
    transfer.G_D_PT(alternative_idx), transfer.G_Pol_PT(alternative_idx), transfer.G_support(alternative_idx), ...
    transfer.G_D_support(alternative_idx), transfer.G_Pol_support(alternative_idx), ...
    transfer.G_choice_propensity(alternative_idx), transfer.G_information_need(alternative_idx), transfer.G_information_need_resid(alternative_idx), transfer.G_mechanism_load(alternative_idx), transfer.G_communication_burden(alternative_idx), transfer.G_action_priority(alternative_idx), ...
    'VariableNames', {'rank','alternative_idx','alternative_name','primary_score','base_score','PT_mean_score','D_PT_score','Pol_PT_score', ...
    'support_score','D_support_score','Pol_support_score','choice_propensity_score','information_need_score','information_need_resid_score','mechanism_load_score','communication_burden_score','action_priority_score'});

diagnostics.tables = struct();
diagnostics.tables.subject_table = subject_table;
diagnostics.tables.parameter_table = parameter_table;
diagnostics.tables.transfer_table = transfer_table;
diagnostics.tables.validation_matrix = validation_matrix;
diagnostics.tables.validation_table = validation_table;
diagnostics.tables.weighted_validation_table = weighted_validation_table;
diagnostics.tables.score_table = score_table;
diagnostics.tables.mechanism_table = mechanism_table;
diagnostics.tables.sanity_table = sanity_table;
% Deployable/export-safe tables.
diagnostics.tables.deployable_action_table = transfer.deployable_action_table;
diagnostics.tables.deployable_explanation_table = transfer.deployable_explanation_table;
diagnostics.tables.explanation_table = transfer.explanation_table;
% Post-hoc validation/audit tables. These may contain held-out truth and
% must be kept separate from deployable DSS artifacts.
diagnostics.tables.profile_validation_table = transfer.profile_table;
diagnostics.tables.audit_table = transfer.audit_table;
diagnostics.tables.validation_component_table = transfer.validation_component_table;
diagnostics.tables.support_proxy_validation = transfer.support_proxy_validation;
diagnostics.tables.action_flag_rate_table = transfer.action_flag_rate_table;
diagnostics.tables.action_cooccurrence_table = transfer.action_cooccurrence_table;
diagnostics.tables.mechanism_visibility_table = transfer.mechanism_visibility_table;
diagnostics.tables.action_ablation_table = transfer.action_ablation_table;
diagnostics.tables.comparison_table = transfer.comparison_table;
diagnostics.tables.ablation_table = transfer.ablation_table;
diagnostics.tables.bootstrap_table = transfer.bootstrap_table;
diagnostics.tables.transfer_alt_table = transfer_alt_table;
end

function T = local_validation_matrix()
output = ["G_base";"G_PT_mean";"D_PT";"Pol_PT";"G_mechanism_load";"G_support";"G_info_core/resid";"G_communication_burden";"DeployableAction";"AuditFlag"];
proper_target = ["risk truth";"G_base sanity";"psychological mechanism contrast";"psychological disagreement";"mechanism-aware communication burden";"support/safety proxies";"K/C/F/Wtail and expert information labels";"human communication salience";"expert/user communication labels";"post-hoc truth variance and residuals"];
main_metric = ["weighted Spearman / weighted top-bottom gap / bootstrap CI; weighted NDCG auxiliary";"max abs difference from G_base";"distribution, top profiles, action-level ablation";"distribution, flag visibility, top profiles";"proxy alignment with D/Pol and action flags";"proxy correlations and expert/user evaluation";"proxy correlations and human-centered labels";"proxy alignment with information need and mechanism load";"macro-F1, weighted-F1, flag Jaccard/Hamming-F1, kappa";"truth variance and cross-fitted calibrated residual analysis"];
should_compare_to_risk_truth = [true; false; false; false; false; false; false; false; false; true];
uses_ground_truth_in_deployment = [false; false; false; false; false; false; false; false; false; false];
T = table(output, proper_target, main_metric, should_compare_to_risk_truth, uses_ground_truth_in_deployment);
end

function T = local_validation_table(tr)
score_name = ["primary";"base_main";"PT_mean_sanity";"support_diagnostic";"choice_propensity";"softmax";"information_need_diagnostic";"mechanism_load_diagnostic";"communication_burden_diagnostic";"action_priority_diagnostic"];
vals = {tr.validation, tr.validation_base, tr.validation_PT_mean, tr.validation_support, tr.validation_choice_propensity, ...
    tr.validation_softmax, tr.validation_information_need, tr.validation_mechanism_load, tr.validation_communication_burden, tr.validation_action_priority};
available = false(numel(score_name),1);
spearman_rho = NaN(numel(score_name),1);
ndcg_at_10pct = NaN(numel(score_name),1);
ndcg_at_20pct = NaN(numel(score_name),1);
top_bottom_gap_truth = NaN(numel(score_name),1);
interpretation = strings(numel(score_name),1);
for i = 1:numel(score_name)
    v = vals{i};
    if isstruct(v) && isfield(v,'available')
        available(i) = logical(v.available);
        spearman_rho(i) = local_get(v,'spearman_rho');
        ndcg_at_10pct(i) = local_get(v,'ndcg_at_10pct');
        ndcg_at_20pct(i) = local_get(v,'ndcg_at_20pct');
        top_bottom_gap_truth(i) = local_get(v,'top_bottom_gap_truth');
    end
end
interpretation(score_name=="base_main") = "main financial risk-truth validation score: B-U";
interpretation(score_name=="PT_mean_sanity") = "sanity check; expected to equal base";
interpretation(score_name=="support_diagnostic") = "support/safety score; not positive risk-truth target";
interpretation(score_name=="information_need_diagnostic") = "diagnostic only; can be negative vs risk willingness";
interpretation(score_name=="mechanism_load_diagnostic") = "mechanism visibility score; proper target is D/Pol/action visibility, not risk truth";
interpretation(score_name=="communication_burden_diagnostic") = "communication-burden score; proper target is human communication salience, not risk truth";
interpretation(score_name=="action_priority_diagnostic") = "deployable action priority; proper target is expert/user label, not risk truth";
interpretation(score_name=="primary") = "configured primary score";
interpretation(score_name=="choice_propensity") = "behavioral propensity based on support score";
interpretation(score_name=="softmax") = "large-M softmax diagnostic only";
T = table(score_name, available, spearman_rho, ndcg_at_10pct, ndcg_at_20pct, top_bottom_gap_truth, interpretation);
end

function T = local_weighted_validation_table(tr)
score_name = ["primary";"base_main";"PT_mean_sanity";"support_diagnostic";"choice_propensity";"information_need_diagnostic";"mechanism_load_diagnostic";"communication_burden_diagnostic";"action_priority_diagnostic"];
vals = {tr.validation, tr.validation_base, tr.validation_PT_mean, tr.validation_support, tr.validation_choice_propensity, ...
    tr.validation_information_need, tr.validation_mechanism_load, tr.validation_communication_burden, tr.validation_action_priority};
weighted_spearman_rho = NaN(numel(score_name),1);
weighted_ndcg_at_10pct = NaN(numel(score_name),1);
weighted_ndcg_at_20pct = NaN(numel(score_name),1);
weighted_top_bottom_gap_truth = NaN(numel(score_name),1);
for i = 1:numel(score_name)
    v = vals{i};
    if isstruct(v) && isfield(v,'available') && v.available
        weighted_spearman_rho(i) = local_get(v,'weighted_spearman_rho');
        weighted_ndcg_at_10pct(i) = local_get(v,'weighted_ndcg_at_10pct');
        weighted_ndcg_at_20pct(i) = local_get(v,'weighted_ndcg_at_20pct');
        weighted_top_bottom_gap_truth(i) = local_get(v,'weighted_top_bottom_gap_truth');
    end
end
T = table(score_name, weighted_spearman_rho, weighted_ndcg_at_10pct, weighted_ndcg_at_20pct, weighted_top_bottom_gap_truth);
end

function T = local_score_table(tr)
score_name = ["primary";"base";"PT_mean";"D_PT";"Pol_PT";"support";"D_support";"Pol_support";"choice_propensity";"information_need";"information_need_resid";"mechanism_load";"communication_burden";"action_priority"];
scores = {tr.G, tr.G_base, tr.G_PT_mean, tr.G_D_PT, tr.G_Pol_PT, tr.G_support, tr.G_D_support, tr.G_Pol_support, tr.G_choice_propensity, tr.G_information_need, tr.G_information_need_resid, tr.G_mechanism_load, tr.G_communication_burden, tr.G_action_priority};
unique_scores_12dp = zeros(numel(score_name),1);
score_range = NaN(numel(score_name),1);
for i = 1:numel(score_name)
    x = double(scores{i}(:)); x = x(isfinite(x));
    if isempty(x), unique_scores_12dp(i) = 0; else, unique_scores_12dp(i) = numel(unique(round(x*1e12)/1e12)); score_range(i) = max(x)-min(x); end
end
T = table(score_name, unique_scores_12dp, score_range);
end

function T = local_mechanism_table(tr)
metric = ["mean_information_need";"mean_information_need_resid";"mean_mechanism_load";"mean_communication_burden";"mean_Pol_PT";"mean_Pol_support";"mean_abs_D_PT";"mean_abs_D_support";"max_abs_D_PT";"max_abs_D_support";"mean_action_priority"];
value = [mean(tr.G_information_need,'omitnan'); mean(tr.G_information_need_resid,'omitnan'); mean(tr.G_mechanism_load,'omitnan'); mean(tr.G_communication_burden,'omitnan'); mean(tr.G_Pol_PT,'omitnan'); mean(tr.G_Pol_support,'omitnan'); ...
    mean(abs(tr.G_D_PT),'omitnan'); mean(abs(tr.G_D_support),'omitnan'); max(abs(tr.G_D_PT),[],'omitnan'); ...
    max(abs(tr.G_D_support),[],'omitnan'); mean(tr.G_action_priority,'omitnan')];
T = table(metric, value);
end

function T = local_sanity_table(tr)
check_name = ["PT_mean_minus_base_max_abs";"PT_mean_minus_base_mean_abs";"PT_mean_degeneracy_expected";"deployable_action_leakage_free"];
value = [tr.sanity.PT_mean_minus_base_max_abs; tr.sanity.PT_mean_minus_base_mean_abs; double(tr.sanity.PT_mean_degeneracy_expected); double(tr.sanity.deployable_action_leakage_free)];
interpretation = ["Should be near zero under current v8 assumptions"; "Mean absolute degeneration difference"; "1 means degeneracy is expected"; "1 means deployable action table has no truth/residual/expert fields"];
T = table(check_name, value, interpretation);
end

function x = local_get(S,name)
if isstruct(S) && isfield(S,name) && ~isempty(S.(name)), x=double(S.(name)); else, x=NaN; end
end
