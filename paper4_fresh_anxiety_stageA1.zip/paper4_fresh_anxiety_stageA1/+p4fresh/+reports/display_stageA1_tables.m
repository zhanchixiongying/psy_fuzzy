function display_stageA1_tables(diagnostics)
fprintf('\n================ STAGE A.1 TABLES ================\n');
disp(diagnostics.summary);

p4fresh.utils.print_table_head(diagnostics.tables.family_table, height(diagnostics.tables.family_table), 'family_table');
p4fresh.utils.print_table_head(diagnostics.tables.subject_table, min(12,height(diagnostics.tables.subject_table)), 'subject_table');
p4fresh.utils.print_table_head(diagnostics.tables.parameter_table, min(12,height(diagnostics.tables.parameter_table)), 'parameter_table');
p4fresh.utils.print_table_head(diagnostics.tables.parameter_boundary_table, height(diagnostics.tables.parameter_boundary_table), 'parameter_boundary_table');
p4fresh.utils.print_table_head(diagnostics.tables.anomaly_table, min(12,height(diagnostics.tables.anomaly_table)), 'anomaly_table');
p4fresh.utils.print_table_head(diagnostics.tables.transfer_table, height(diagnostics.tables.transfer_table), 'transfer_table');
p4fresh.utils.print_table_head(diagnostics.tables.transfer_alt_table, height(diagnostics.tables.transfer_alt_table), 'transfer_alt_table');

fprintf('==================================================\n');
end
