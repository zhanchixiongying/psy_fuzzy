function display_stageA1_tables(diagnostics)
%DISPLAY_STAGEA1_TABLES Compact APF-DS-XAI v8 display.
fprintf('\n================ APF-DS-XAI v8 DIAGNOSTICS ================\n');
disp(diagnostics.summary);
for nm = ["validation_matrix","validation_table","weighted_validation_table","comparison_table","ablation_table","action_flag_rate_table","action_cooccurrence_table","mechanism_visibility_table","action_ablation_table","support_proxy_validation","score_table","mechanism_table","sanity_table","transfer_table","deployable_action_table","audit_table","profile_table","explanation_table","support_component_table","parameter_table"]
    if isfield(diagnostics.tables, nm)
        T = diagnostics.tables.(nm);
        fprintf('\n--- %s ---\n', nm);
        if istable(T) && height(T) > 0
            disp(T(1:min(height(T),12), :));
        else
            disp(T);
        end
    end
end
fprintf('========================================================\n');
end
