function raw = unpack_power(theta)
theta = theta(:);
if numel(theta) ~= 13
    error('Power theta must have 13 entries.');
end
raw = p4fresh.mapping.unpack_linear(theta(1:12));
raw.p = p4fresh.utils.softplus(theta(13)) + 0.25;
end
