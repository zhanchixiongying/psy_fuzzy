function raw = unpack_linear(theta)
theta = theta(:);
if numel(theta) ~= 12
    error('Linear/logistic theta must have 12 entries.');
end
names = {'alpha','kappa','csub','lambda','beta','w'};
raw = struct();
for i = 1:6
    raw.(names{i}) = theta((2*i-1):(2*i));
end
end
