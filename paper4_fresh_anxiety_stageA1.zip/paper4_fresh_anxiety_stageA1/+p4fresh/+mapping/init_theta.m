function theta = init_theta(family)
switch lower(string(family))
    case {"linear","logistic"}
        theta = zeros(12,1);
        theta(1:2:end) = [0.2; -0.4; 0.4; 0.1; 0.6; 0.0];
        theta(2:2:end) = [-0.5; 0.7; -0.8; -0.4; -0.6; -0.2];
    case "power"
        theta = [zeros(12,1); 1.2];
    case "mspline"
        theta = zeros(24,1);
    otherwise
        error('Unknown family.');
end
end
