function P = apply_mapping_family(A, theta, family)
% theta is family-specific packed vector
A = A(:);
nT = numel(A);

switch lower(string(family))
    case "linear"
        raw = p4fresh.mapping.unpack_linear(theta);
    case "logistic"
        raw = p4fresh.mapping.unpack_linear(theta);
    case "power"
        raw = p4fresh.mapping.unpack_power(theta);
    case "mspline"
        raw = p4fresh.mapping.unpack_mspline(theta);
    otherwise
        error('Unknown family: %s', string(family));
end

parnames = ["alpha","kappa","csub","lambda","beta","w"];
out = struct();
for p = 1:numel(parnames)
    nm = char(parnames(p));
    switch lower(string(family))
        case "linear"
            z = raw.(nm)(1) + raw.(nm)(2) * A;
        case "logistic"
            z = p4fresh.utils.sigmoid(raw.(nm)(1) + raw.(nm)(2) * A);
        case "power"
            z = raw.(nm)(1) + raw.(nm)(2) * (A .^ raw.p);
        case "mspline"
            B1 = A;
            B2 = max(A - 1/3, 0);
            B3 = max(A - 2/3, 0);
            wv = p4fresh.utils.softplus(raw.(nm)(2:4));
            z = raw.(nm)(1) + wv(1)*B1 + wv(2)*B2 + wv(3)*B3;
    end
    out.(nm) = z;
end

P = struct();
P.alpha = p4fresh.utils.sigmoid(out.alpha);
P.kappa = p4fresh.utils.sigmoid(out.kappa);
P.lambda = p4fresh.utils.sigmoid(out.lambda);
P.w = p4fresh.utils.sigmoid(out.w);
P.beta = p4fresh.utils.softplus(out.beta);
P.csub = p4fresh.utils.softplus(out.csub);

for fn = fieldnames(P)'
    P.(fn{1}) = reshape(P.(fn{1}), nT, 1);
end
end
