function raw = unpack_mspline(theta)
theta = theta(:);
if numel(theta) ~= 24
    error('MSpline theta must have 24 entries.');
end
names = {'alpha','kappa','csub','lambda','beta','w'};
raw = struct();
for i = 1:6
    raw.(names{i}) = theta((4*i-3):(4*i));
end
end
