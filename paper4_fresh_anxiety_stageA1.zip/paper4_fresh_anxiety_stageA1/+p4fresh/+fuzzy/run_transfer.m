function transfer = run_transfer(caseA, fuzzy_case, cfg)
%RUN_TRANSFER APF-DS-XAI v8 leak-free profile-level transfer.
%
% v8 separates performance validation, mechanism interpretation, deployable
% actions, and post-hoc audit:
%
% 1) Financial baseline:
%      G_base_m = B_m - U_m
%    Default positive risk-truth validation score.
%
% 2) PT mechanism:
%      V_PT_im = tau_i*B_m - ell_i*U_m
%      G_PT_mean_m = mean_i(V_PT_im)
%    Under external-subject averaging with mean-normalized tau/ell and shared
%    financial evidence, G_PT_mean is expected to equal G_base. It is only a
%    sanity check, not evidence of psychological ranking improvement.
%
% 3) Support layer:
%      V_sup_im = V_PT_im
%        - wK*kappa_i*K_m - wC*chi_i*C_m - wF*phi_i*F_m - wW*gamma_i*Wtail_m
%
% 4) Leak-free deployable action:
%      Uses B/U/K/C/F/Wtail, model outputs, and profile size only.
%      It never uses ground_truth, truth_mean, truth_var, residuals, or future outcomes.
%
% 5) Audit layer:
%      Uses observed truth variance and residuals only after validation.

if nargin < 3 || isempty(cfg)
    cfg = p4fresh.config.default_config();
end

params = local_extract_params(caseA.subject_results);
nS = numel(params.tau);
altNames = string(fuzzy_case.alternative_names(:));
m = numel(altNames);
omega = local_get_omega(fuzzy_case, nS);

B = local_expand_layer(fuzzy_case, 'B', nS, m);
U = local_expand_layer(fuzzy_case, 'U', nS, m);
K = local_expand_layer(fuzzy_case, 'K', nS, m);
C = local_expand_layer(fuzzy_case, 'C', nS, m);
F = local_expand_layer(fuzzy_case, 'F', nS, m);
Wtail = local_expand_layer(fuzzy_case, 'W_tail', nS, m);

sw = cfg.transfer.support_weights;
infoCfg = cfg.transfer.info;

Vpt = zeros(nS,m);
Vsupport = zeros(nS,m);
Q = zeros(nS,m);
Psoft = zeros(nS,m);
H = zeros(nS,m);

for i = 1:nS
    Vpt(i,:) = params.tau(i).*B(i,:) - params.ell(i).*U(i,:);
    Vsupport(i,:) = Vpt(i,:) ...
        - sw.w_K .* params.kappa(i).*K(i,:) ...
        - sw.w_C .* params.chi(i).*C(i,:) ...
        - sw.w_F .* params.phi(i).*F(i,:) ...
        - sw.w_W .* params.gamma(i).*Wtail(i,:);

    Z = local_row_zscore(Vsupport(i,:));
    Q(i,:) = local_sigmoid(params.beta(i).*Z);
    z = params.beta(i).*Z;
    z = z - max(z);
    ex = exp(z);
    Psoft(i,:) = ex ./ max(sum(ex), eps);

    H(i,:) = local_sigmoid(infoCfg.k0 ...
        + infoCfg.k_K.*params.kappa(i).*K(i,:) ...
        + infoCfg.k_C.*params.chi(i).*C(i,:) ...
        + infoCfg.k_F.*params.phi(i).*F(i,:) ...
        + infoCfg.k_W.*params.gamma(i).*Wtail(i,:));
end

G_base = double(fuzzy_case.B_alt(:) - fuzzy_case.U_alt(:));
G_PT_mean = (omega' * Vpt)';
G_support = (omega' * Vsupport)';
G_choice = (omega' * Q)';
G_softmax = (omega' * Psoft)';
G_info = (omega' * H)';
G_info_resid = local_residualize_info_by_profile(fuzzy_case, G_info, G_support, G_base, cfg);
G_Pol_PT = std(Vpt, 0, 1)';
G_Pol_support = std(Vsupport, 0, 1)';

high = params.high_anxiety(:);
if any(high) && any(~high)
    G_PT_high = mean(Vpt(high,:), 1, 'omitnan')';
    G_PT_low = mean(Vpt(~high,:), 1, 'omitnan')';
    G_support_high = mean(Vsupport(high,:), 1, 'omitnan')';
    G_support_low = mean(Vsupport(~high,:), 1, 'omitnan')';
else
    G_PT_high = NaN(m,1);
    G_PT_low = NaN(m,1);
    G_support_high = NaN(m,1);
    G_support_low = NaN(m,1);
end
G_D_PT = G_PT_low - G_PT_high;
G_D_support = G_support_low - G_support_high;
G_mechanism_load = local_mechanism_load(G_D_PT, G_Pol_PT, G_D_support, G_Pol_support, cfg);

[deployActionT, auditT, G_action_priority, G_action_flags, G_communication_burden] = local_deployable_and_audit_actions( ...
    fuzzy_case, G_base, G_support, G_info, G_info_resid, G_D_PT, G_Pol_PT, G_D_support, G_Pol_support, G_mechanism_load, cfg);

primaryRaw = lower(char(string(cfg.transfer.primary_score)));
switch primaryRaw
    case {'base','baseline'}
        G = G_base; primary = "base";
    case {'pt','pt_mean','prospect','risk'}
        G = G_PT_mean; primary = "pt_mean";
    case {'support','mixed','value'}
        G = G_support; primary = "support";
    case 'choice_propensity'
        G = G_choice; primary = "choice_propensity";
    case 'information_need'
        G = G_info; primary = "information_need";
    case 'action_priority'
        G = G_action_priority; primary = "action_priority";
    case {'communication_burden','comm_burden'}
        G = G_communication_burden; primary = "communication_burden";
    case {'mechanism_load','mechanism'}
        G = G_mechanism_load; primary = "mechanism_load";
    otherwise
        error('run_transfer:BadPrimaryScore', ...
            'primary_score must be base, pt_mean/pt, support, choice_propensity, information_need, action_priority, communication_burden, or mechanism_load.');
end

rankKey = G(:) + 1e-12 .* local_unsupervised_tiebreaker(fuzzy_case, m);
[sortedRankKey, ord] = sort(rankKey, 'descend');
scoreRange = max(G) - min(G);
if numel(ord) >= 2
    headGap = G(ord(1)) - G(ord(2));
    headGapRankKey = sortedRankKey(1) - sortedRankKey(2);
else
    headGap = NaN;
    headGapRankKey = NaN;
end
if scoreRange <= 1e-12, headGapRatio = NaN; else, headGapRatio = headGap ./ scoreRange; end

ptDegeneracyMaxAbs = max(abs(G_PT_mean(:) - G_base(:)), [], 'omitnan');
ptDegeneracyMeanAbs = mean(abs(G_PT_mean(:) - G_base(:)), 'omitnan');

transfer = struct();
transfer.model_mode = "apf_ds_xai_v8";
transfer.primary_score = primary;
transfer.score_mode_used = primary;
transfer.G = G(:);
transfer.G_primary = G(:);

transfer.G_base = G_base(:);
transfer.G_PT_mean = G_PT_mean(:);
transfer.G_PT_high = G_PT_high(:);
transfer.G_PT_low = G_PT_low(:);
transfer.G_D_PT = G_D_PT(:);
transfer.G_Pol_PT = G_Pol_PT(:);

transfer.G_support = G_support(:);
transfer.G_support_high = G_support_high(:);
transfer.G_support_low = G_support_low(:);
transfer.G_D_support = G_D_support(:);
transfer.G_Pol_support = G_Pol_support(:);

transfer.G_choice_propensity = G_choice(:);
transfer.G_softmax = G_softmax(:);
transfer.G_information_need = G_info(:);
transfer.G_information_need_core = G_info(:);
transfer.G_information_need_resid = G_info_resid(:);
transfer.G_info_core = G_info(:);
transfer.G_info_resid = G_info_resid(:);
transfer.G_mechanism_load = G_mechanism_load(:);
transfer.G_communication_burden = G_communication_burden(:);
transfer.G_action_priority = G_action_priority(:);
transfer.G_action_flags = G_action_flags;
transfer.G_polarization = G_Pol_support(:);

transfer.G_high_anxiety_PT = G_PT_high(:);
transfer.G_low_anxiety_PT = G_PT_low(:);
transfer.G_high_low_PT_divergence = G_D_PT(:);
transfer.G_high_anxiety_support = G_support_high(:);
transfer.G_low_anxiety_support = G_support_low(:);
transfer.G_high_low_support_divergence = G_D_support(:);

transfer.rank_key = rankKey(:);
transfer.rank_order = ord(:);
transfer.rank_names = altNames(ord);
transfer.subject_value_PT = Vpt;
transfer.subject_value_support = Vsupport;
transfer.subject_choice_propensity = Q;
transfer.subject_information_need = H;
transfer.subject_softmax = Psoft;

transfer.subject_risk_tolerance = params.tau(:);
transfer.subject_loss_sensitivity = params.ell(:);
transfer.subject_choice_precision = params.beta(:);
transfer.subject_low_clarity_sensitivity = params.kappa(:);
transfer.subject_change_sensitivity = params.chi(:);
transfer.subject_fragility_sensitivity = params.phi(:);
transfer.subject_worst_case_sensitivity = params.gamma(:);
transfer.subject_anxiety = params.psi(:);
transfer.subject_high_anxiety = params.high_anxiety(:);
transfer.subject_omega = omega(:);

transfer.summary = struct();
transfer.summary.model_mode = "apf_ds_xai_v8";
transfer.summary.primary_score = primary;
transfer.summary.top1_idx = int32(ord(1));
transfer.summary.top1_name = altNames(ord(1));
transfer.summary.top2_idx = int32(ord(min(2,numel(ord))));
transfer.summary.top2_name = altNames(ord(min(2,numel(ord))));
transfer.summary.head_gap = headGap;
transfer.summary.head_gap_rank_key = headGapRankKey;
transfer.summary.score_range = scoreRange;
transfer.summary.head_gap_ratio = headGapRatio;
transfer.summary.PT_mean_degeneracy_max_abs = ptDegeneracyMaxAbs;
transfer.summary.PT_mean_degeneracy_mean_abs = ptDegeneracyMeanAbs;

transfer.sanity = struct();
transfer.sanity.PT_mean_degeneracy_expected = true;
transfer.sanity.PT_mean_minus_base_max_abs = ptDegeneracyMaxAbs;
transfer.sanity.PT_mean_minus_base_mean_abs = ptDegeneracyMeanAbs;
transfer.sanity.PT_mean_note = "G_PT_mean is expected to equal G_base when tau/ell are mean-normalized and B/U are shared across external psychological subjects.";
transfer.sanity.deployable_action_leakage_free = local_check_action_leakage(deployActionT);

transfer.validation = local_validate_ranking(transfer.G, fuzzy_case);
transfer.validation_primary = transfer.validation;
transfer.validation_base = local_validate_ranking(transfer.G_base, fuzzy_case);
transfer.validation_PT_mean = local_validate_ranking(transfer.G_PT_mean, fuzzy_case);
transfer.validation_support = local_validate_ranking(transfer.G_support, fuzzy_case);
transfer.validation_choice_propensity = local_validate_ranking(transfer.G_choice_propensity, fuzzy_case);
transfer.validation_softmax = local_validate_ranking(transfer.G_softmax, fuzzy_case);
transfer.validation_information_need = local_validate_ranking(transfer.G_information_need, fuzzy_case);
transfer.validation_mechanism_load = local_validate_ranking(transfer.G_mechanism_load, fuzzy_case);
transfer.validation_communication_burden = local_validate_ranking(transfer.G_communication_burden, fuzzy_case);
transfer.validation_action_priority = local_validate_ranking(transfer.G_action_priority, fuzzy_case);

% Post-hoc validation tables may contain held-out truth; do not expose them as deployable XAI artifacts.
transfer.validation_component_table = local_validation_component_table(transfer, fuzzy_case);
transfer.support_component_table = transfer.validation_component_table;
transfer.profile_table = local_profile_validation_table(transfer, fuzzy_case);
transfer.deployable_action_table = deployActionT;
transfer.audit_table = auditT;
transfer.deployable_explanation_table = local_explanation_table(transfer, fuzzy_case);
transfer.explanation_table = transfer.deployable_explanation_table;
transfer.support_proxy_validation = local_support_proxy_validation(transfer, fuzzy_case);
transfer.comparison_table = local_comparison_table(transfer, fuzzy_case, cfg);
transfer.ablation_table = local_ablation_table(transfer, fuzzy_case, params, sw);
transfer.action_flag_rate_table = local_action_flag_rate_table(deployActionT);
transfer.action_cooccurrence_table = local_action_cooccurrence_table(deployActionT);
transfer.mechanism_visibility_table = local_mechanism_visibility_table(transfer, deployActionT);
transfer.action_ablation_table = local_action_ablation_table(deployActionT);
if isfield(cfg,'bootstrap') && isfield(cfg.bootstrap,'enabled') && cfg.bootstrap.enabled
    transfer.bootstrap_table = local_bootstrap_table(transfer, fuzzy_case, cfg);
else
    transfer.bootstrap_table = table();
end
transfer.diagnostics = local_diagnostics(transfer);
end

% =========================================================================
% Action and audit
% =========================================================================
function [deployT, auditT, actionAlt, flagAlt, communicationAlt] = local_deployable_and_audit_actions(fc, G_base, G_support, G_info, G_info_resid, D_PT, Pol_PT, D_support, Pol_support, G_mechanism_load, cfg)
pid = string(fc.profile_id(:));
[G, keys] = findgroups(pid);
nP = numel(keys);

B = local_get_vector(fc,'B_alt',numel(pid),0);
U = local_get_vector(fc,'U_alt',numel(pid),0);
K = local_get_vector(fc,'K_alt',numel(pid),0);
C = local_get_vector(fc,'C_alt',numel(pid),0);
F = local_get_vector(fc,'F_alt',numel(pid),0);
W = local_get_vector(fc,'W_tail_alt',numel(pid),0);
truth = local_get_vector(fc,'ground_truth',numel(pid),NaN);
wCase = local_get_vector(fc,'case_weight',numel(pid),1);

n_alt = splitapply(@numel, pid, G);
weight_sum = splitapply(@local_sum_omitnan, wCase, G);
B_m = splitapply(@local_mean_omitnan, B, G);
U_m = splitapply(@local_mean_omitnan, U, G);
K_m = splitapply(@local_mean_omitnan, K, G);
C_m = splitapply(@local_mean_omitnan, C, G);
F_m = splitapply(@local_mean_omitnan, F, G);
W_m = splitapply(@local_mean_omitnan, W, G);
base_m = splitapply(@local_mean_omitnan, G_base(:), G);
support_m = splitapply(@local_mean_omitnan, G_support(:), G);
info_m = splitapply(@local_mean_omitnan, G_info(:), G);
infoResid_m = splitapply(@local_mean_omitnan, G_info_resid(:), G);
absDpt_m = splitapply(@local_mean_abs_omitnan, D_PT(:), G);
polpt_m = splitapply(@local_mean_omitnan, Pol_PT(:), G);
absDsup_m = splitapply(@local_mean_abs_omitnan, D_support(:), G);
polsup_m = splitapply(@local_mean_omitnan, Pol_support(:), G);
mech_m = splitapply(@local_mean_omitnan, G_mechanism_load(:), G);

% Deployable normalized inputs: no truth used.
zInfo = local_minmax01(info_m);
zInfoResidPos = local_minmax01(max(infoResid_m,0));
zK = local_minmax01(K_m);
zC = local_minmax01(C_m);
zAbsDsup = local_minmax01(absDsup_m);
zPolsup = local_minmax01(polsup_m);
zAbsDpt = local_minmax01(absDpt_m);
zMech = local_minmax01(mech_m);
zF = local_minmax01(F_m);
zW = local_minmax01(W_m);
zBase = local_minmax01(base_m);

rw = cfg.action.score_weights;
aw = local_score_weight(rw, 'anxiety', [0.35 0.25 0.15 0.25]);
cbw = local_score_weight(rw, 'communication_burden', [0.40 0.40 0.20]);
riskPressureRaw = max([K_m, C_m, F_m, W_m], [], 2);
zRiskPressure = local_minmax01(riskPressureRaw);
S_info = rw.info(1).*zInfo + rw.info(2).*zK + rw.info(3).*zC + rw.info(4).*zInfoResidPos;
S_anxiety = aw(1).*zAbsDsup + aw(2).*zPolsup + aw(3).*zAbsDpt + aw(4).*zMech;
S_resilience = rw.resilience(1).*zF + rw.resilience(2).*zW + rw.resilience(3).*(1-zBase);
S_guardrail = rw.guardrail(1).*zBase + rw.guardrail(2).*local_minmax01(max(F_m,W_m));
S_capacity = rw.capacity(1).*zBase + rw.capacity(2).*(1-zInfo) + rw.capacity(3).*(1-zF) + rw.capacity(4).*(1-zW);
S_communication_burden = cbw(1).*zInfo + cbw(2).*zMech + cbw(3).*zRiskPressure;

thr = 0.75;
if isfield(cfg,'action') && isfield(cfg.action,'flag_threshold_pct'), thr = cfg.action.flag_threshold_pct; end
flag_info = S_info >= local_quantile(S_info, thr);
flag_anxiety = S_anxiety >= local_quantile(S_anxiety, thr);
flag_resilience = S_resilience >= local_quantile(S_resilience, thr);
flag_guardrail = S_guardrail >= local_quantile(S_guardrail, thr);
flag_capacity = S_capacity >= local_quantile(S_capacity, thr);

scoreMat = [S_info, S_anxiety, S_resilience, S_guardrail, S_capacity];
[priority, ~] = max(scoreMat, [], 2);
primary_action = local_final_guideline_primary_policy(S_info, S_anxiety, S_resilience, S_guardrail, S_capacity, ...
    zInfo, zInfoResidPos, zK, zC, zAbsDsup, zPolsup, zAbsDpt, zF, zW, zBase);

% Keep secondary flags consistent with the final primary-action guideline.
flag_info = flag_info | primary_action == "Information supplementation";
flag_anxiety = flag_anxiety | primary_action == "Anxiety-sensitive explanation";
flag_resilience = flag_resilience | primary_action == "Protective financial resilience communication";
flag_guardrail = flag_guardrail | primary_action == "Guardrail explanation";
flag_capacity = flag_capacity | primary_action == "Standard risk-capacity communication";

secondary_flags = strings(nP,1);
primary_rationale = strings(nP,1);
secondary_cautions = strings(nP,1);
top_drivers = strings(nP,1);
rationale = strings(nP,1);

for p = 1:nP
    flags = strings(0,1);
    if flag_info(p), flags(end+1,1) = "info"; end %#ok<AGROW>
    if flag_anxiety(p), flags(end+1,1) = "anxiety_sensitive"; end %#ok<AGROW>
    if flag_resilience(p), flags(end+1,1) = "resilience"; end %#ok<AGROW>
    if flag_guardrail(p), flags(end+1,1) = "guardrail"; end %#ok<AGROW>
    if flag_capacity(p), flags(end+1,1) = "capacity"; end %#ok<AGROW>
    if isempty(flags), flags = "standard"; end
    secondary_flags(p) = strjoin(flags, ";");

    primary_rationale(p) = local_primary_rationale(primary_action(p));
    secondary_cautions(p) = local_secondary_cautions(flags);
    top_drivers(p) = local_top_drivers(["B","U","K","C","F","W_tail","abs_D_PT","Pol_PT","abs_D_support","Pol_support","G_info","G_info_resid","G_mechanism_load","S_communication_burden"], ...
        [B_m(p), U_m(p), K_m(p), C_m(p), F_m(p), W_m(p), absDpt_m(p), polpt_m(p), absDsup_m(p), polsup_m(p), info_m(p), max(infoResid_m(p),0), mech_m(p), S_communication_burden(p)]);
    rationale(p) = "Primary: " + primary_rationale(p) + " Secondary: " + secondary_cautions(p) + " Drivers: " + top_drivers(p);
end

deployT = table(keys, n_alt, weight_sum, B_m, U_m, K_m, C_m, F_m, W_m, base_m, support_m, info_m, infoResid_m, mech_m, ...
    absDpt_m, polpt_m, absDsup_m, polsup_m, S_info, S_anxiety, S_resilience, S_guardrail, S_capacity, S_communication_burden, ...
    priority, primary_action, secondary_flags, flag_info, flag_anxiety, flag_resilience, flag_guardrail, flag_capacity, primary_rationale, secondary_cautions, top_drivers, rationale, ...
    'VariableNames', {'profile_id','n_alternatives','weight_sum','B','U','K','C','F','W_tail','G_base','G_support','G_info_core','G_info_resid','G_mechanism_load', ...
    'abs_D_PT','Pol_PT','abs_D_support','Pol_support','S_info','S_anxiety','S_resilience','S_guardrail','S_capacity','S_communication_burden', ...
    'action_priority','primary_action','secondary_flags','flag_info','flag_anxiety','flag_resilience','flag_guardrail','flag_capacity','primary_rationale','secondary_cautions','top_drivers','rationale'});
deployT = sortrows(deployT, 'action_priority', 'descend');

% Map priority and flags back to alternatives.
priorityByGroup = priority(G);
actionAlt = priorityByGroup(:);
communicationAlt = S_communication_burden(G);
communicationAlt = communicationAlt(:);
flagAlt = table();
flagAlt.flag_info = flag_info(G);
flagAlt.flag_anxiety = flag_anxiety(G);
flagAlt.flag_resilience = flag_resilience(G);
flagAlt.flag_guardrail = flag_guardrail(G);
flagAlt.flag_capacity = flag_capacity(G);

% Post-hoc audit layer: truth is allowed here only.
% v8 uses cross-fitted monotone calibration residuals rather than direct
% minmax residuals. This avoids mixing scale mismatch with true model error.
truth_mean = splitapply(@local_weighted_mean_pair, truth, wCase, G);
truth_var = splitapply(@local_var_omitnan, truth, G);
[yhat_calibrated, residual_calibrated] = local_crossfit_calibrated_residual(base_m, truth_mean, weight_sum, cfg);
[yhat_support_calibrated, residual_support] = local_crossfit_calibrated_residual(support_m, truth_mean, weight_sum, cfg);
nMin = cfg.action.min_profile_n_for_audit;
qVar = local_quantile(truth_var, 0.75);
qRes = local_quantile(abs(residual_calibrated), local_get_audit_residual_pct(cfg));
audit_heterogeneity = n_alt >= nMin & isfinite(truth_var) & truth_var >= qVar;
audit_residual = isfinite(residual_calibrated) & abs(residual_calibrated) >= qRes;
audit_note = strings(nP,1);
for p = 1:nP
    if audit_heterogeneity(p) && audit_residual(p)
        audit_note(p) = "Post-hoc heterogeneity and residual warning; request finer-grained data or expert review.";
    elseif audit_heterogeneity(p)
        audit_note(p) = "Post-hoc profile heterogeneity warning; truth dispersion is high within the same profile.";
    elseif audit_residual(p)
        audit_note(p) = "Post-hoc residual warning; observed truth differs from baseline calibration.";
    else
        audit_note(p) = "No major post-hoc audit warning.";
    end
end
auditT = table(keys, n_alt, truth_mean, truth_var, yhat_calibrated, residual_calibrated, yhat_support_calibrated, residual_support, audit_heterogeneity, audit_residual, audit_note, ...
    'VariableNames', {'profile_id','n_alternatives','truth_mean','truth_var','yhat_calibrated','residual_calibrated','yhat_support_calibrated','residual_support','audit_heterogeneity','audit_residual','audit_note'});
auditT = sortrows(auditT, {'audit_heterogeneity','audit_residual','truth_var'}, {'descend','descend','descend'});
end

function ok = local_check_action_leakage(actionT)
% Leak check blocks true labels/outcomes/audit residuals, while allowing
% G_info_resid because it is an unsupervised residualized diagnostic that
% does not use ground truth.
names = lower(string(actionT.Properties.VariableNames));
ok = true;
for i = 1:numel(names)
    nm = names(i);
    if contains(nm,"truth") || contains(nm,"ground_truth") || contains(nm,"expert") || contains(nm,"future") || contains(nm,"outcome") || contains(nm,"audit")
        ok = false; return;
    end
    if contains(nm,"residual") && ~(nm == "g_info_resid")
        ok = false; return;
    end
end
end

% =========================================================================
% Tables and diagnostics
% =========================================================================
function T = local_validation_component_table(tr, fc)
%LOCAL_VALIDATION_COMPONENT_TABLE Post-hoc component table.
% This table contains held-out truth for validation/audit reporting only.
% It must never be used as deployable XAI input or expert-label input.
m = numel(tr.G_base);
idx = int32((1:m)');
name = string(fc.alternative_names(:));
profile_id = strings(m,1);
if isfield(fc,'profile_id'), profile_id = string(fc.profile_id(:)); end
truth = local_get_vector(fc, 'ground_truth', m, NaN);
case_weight = local_get_vector(fc, 'case_weight', m, 1);
B = local_get_vector(fc, 'B_alt', m, NaN);
U = local_get_vector(fc, 'U_alt', m, NaN);
K = local_get_vector(fc, 'K_alt', m, NaN);
C = local_get_vector(fc, 'C_alt', m, NaN);
F = local_get_vector(fc, 'F_alt', m, NaN);
W_tail = local_get_vector(fc, 'W_tail_alt', m, NaN);
T = table(idx, name, profile_id, case_weight, truth, B, U, K, C, F, W_tail, ...
    tr.G_base(:), tr.G_PT_mean(:), tr.G_PT_high(:), tr.G_PT_low(:), tr.G_D_PT(:), tr.G_Pol_PT(:), ...
    tr.G_support(:), tr.G_support_high(:), tr.G_support_low(:), tr.G_D_support(:), tr.G_Pol_support(:), ...
    tr.G_information_need(:), tr.G_information_need_resid(:), tr.G_mechanism_load(:), tr.G_communication_burden(:), tr.G_action_priority(:), ...
    'VariableNames', {'alternative_idx','alternative_name','profile_id','case_weight','truth','B','U','K','C','F','W_tail', ...
    'G_base','G_PT_mean','G_PT_high','G_PT_low','D_PT','Pol_PT','G_support','G_support_high','G_support_low', ...
    'D_support','Pol_support','G_info_core','G_info_resid','G_mechanism_load','G_communication_burden','G_action_priority'});
end

function profileT = local_profile_validation_table(tr, fc)
pid = string(fc.profile_id(:));
[G, keys] = findgroups(pid);
profileT = table();
profileT.profile_id = keys;
profileT.n_alternatives = splitapply(@numel, pid, G);
profileT.mean_truth = splitapply(@local_mean_omitnan, double(fc.ground_truth(:)), G);
profileT.var_truth = splitapply(@local_var_omitnan, double(fc.ground_truth(:)), G);
profileT.mean_base = splitapply(@local_mean_omitnan, tr.G_base(:), G);
profileT.mean_PT_mean = splitapply(@local_mean_omitnan, tr.G_PT_mean(:), G);
profileT.mean_D_PT = splitapply(@local_mean_omitnan, tr.G_D_PT(:), G);
profileT.mean_abs_D_PT = splitapply(@local_mean_abs_omitnan, tr.G_D_PT(:), G);
profileT.mean_Pol_PT = splitapply(@local_mean_omitnan, tr.G_Pol_PT(:), G);
profileT.mean_support = splitapply(@local_mean_omitnan, tr.G_support(:), G);
profileT.mean_info = splitapply(@local_mean_omitnan, tr.G_information_need(:), G);
profileT.mean_info_resid = splitapply(@local_mean_omitnan, tr.G_information_need_resid(:), G);
profileT.mean_mechanism_load = splitapply(@local_mean_omitnan, tr.G_mechanism_load(:), G);
profileT.mean_communication_burden = splitapply(@local_mean_omitnan, tr.G_communication_burden(:), G);
profileT.mean_D_support = splitapply(@local_mean_omitnan, tr.G_D_support(:), G);
profileT.mean_abs_D_support = splitapply(@local_mean_abs_omitnan, tr.G_D_support(:), G);
profileT.mean_Pol_support = splitapply(@local_mean_omitnan, tr.G_Pol_support(:), G);
profileT.mean_action_priority = splitapply(@local_mean_omitnan, tr.G_action_priority(:), G);
profileT = sortrows(profileT, "mean_abs_D_support", "descend");
end

function T = local_explanation_table(tr, fc)
%LOCAL_EXPLANATION_TABLE Deployable, truth-free XAI table.
%
% This table is safe for DSS review and expert-facing explanation review.
% It deliberately excludes ground_truth, truth_mean, truth_var, audit fields,
% calibrated residuals, future outcomes, and expert labels.

m = numel(tr.G_base);
idx = int32((1:m)');
name = string(fc.alternative_names(:));
profile_id = strings(m,1);
if isfield(fc,'profile_id'), profile_id = string(fc.profile_id(:)); end
B = local_get_vector(fc, 'B_alt', m, NaN);
U = local_get_vector(fc, 'U_alt', m, NaN);
K = local_get_vector(fc, 'K_alt', m, NaN);
C = local_get_vector(fc, 'C_alt', m, NaN);
F = local_get_vector(fc, 'F_alt', m, NaN);
W_tail = local_get_vector(fc, 'W_tail_alt', m, NaN);

T = table(idx, name, profile_id, B, U, K, C, F, W_tail, ...
    tr.G_base(:), tr.G_PT_mean(:), tr.G_D_PT(:), tr.G_Pol_PT(:), ...
    tr.G_support(:), tr.G_D_support(:), tr.G_Pol_support(:), ...
    tr.G_information_need(:), tr.G_information_need_resid(:), tr.G_mechanism_load(:), tr.G_communication_burden(:), tr.G_action_priority(:), ...
    'VariableNames', {'alternative_idx','alternative_name','profile_id','B','U','K','C','F','W_tail', ...
    'G_base','G_PT_mean','D_PT','Pol_PT','G_support','D_support','Pol_support', ...
    'G_info_core','G_info_resid','G_mechanism_load','G_communication_burden','G_action_priority'});

% Attach profile-level deployable action labels and rationales without truth.
if isfield(tr,'deployable_action_table') && istable(tr.deployable_action_table) && height(tr.deployable_action_table) > 0
    A = tr.deployable_action_table;
    [tf,loc] = ismember(T.profile_id, string(A.profile_id));
    T.primary_action = strings(height(T),1);
    T.secondary_flags = strings(height(T),1);
    T.primary_rationale = strings(height(T),1);
    T.secondary_cautions = strings(height(T),1);
    T.top_drivers = strings(height(T),1);
    T.primary_action(tf) = string(A.primary_action(loc(tf)));
    T.secondary_flags(tf) = string(A.secondary_flags(loc(tf)));
    T.primary_rationale(tf) = string(A.primary_rationale(loc(tf)));
    T.secondary_cautions(tf) = string(A.secondary_cautions(loc(tf)));
    T.top_drivers(tf) = string(A.top_drivers(loc(tf)));
else
    T.primary_action = strings(height(T),1);
    T.secondary_flags = strings(height(T),1);
    T.primary_rationale = strings(height(T),1);
    T.secondary_cautions = strings(height(T),1);
    T.top_drivers = strings(height(T),1);
end

T.explanation_summary = strings(height(T),1);
for i = 1:height(T)
    T.explanation_summary(i) = "base=" + string(round(T.G_base(i),4)) + ...
        "; support=" + string(round(T.G_support(i),4)) + ...
        "; info=" + string(round(T.G_info_core(i),4)) + ...
        "; mechanism=" + string(round(T.G_mechanism_load(i),4)) + ...
        "; communication_burden=" + string(round(T.G_communication_burden(i),4)) + ...
        "; action=" + string(T.primary_action(i)) + ...
        "; drivers: U=" + string(round(T.U(i),3)) + ...
        ", K=" + string(round(T.K(i),3)) + ...
        ", C=" + string(round(T.C(i),3)) + ...
        ", F=" + string(round(T.F(i),3)) + ...
        ", Wtail=" + string(round(T.W_tail(i),3));
end
local_assert_no_deployable_leakage(T, 'explanation_table');
end


function proxyT = local_support_proxy_validation(tr, fc)
K = local_get_vector(fc, 'K_alt', numel(tr.G_base), NaN);
C = local_get_vector(fc, 'C_alt', numel(tr.G_base), NaN);
F = local_get_vector(fc, 'F_alt', numel(tr.G_base), NaN);
W = local_get_vector(fc, 'W_tail_alt', numel(tr.G_base), NaN);
name = ["G_info_vs_K";"G_info_vs_C";"G_info_vs_F";"G_info_vs_Wtail";"G_info_resid_vs_K";"G_info_resid_vs_Wtail";"G_support_vs_F";"G_support_vs_Wtail";"abs_D_support_vs_Wtail";"MechanismLoad_vs_abs_D_support";"MechanismLoad_vs_Pol_support";"CommunicationBurden_vs_G_info";"CommunicationBurden_vs_G_mechanism_load";"ActionPriority_vs_G_info";"ActionPriority_vs_Wtail"];
rho = [local_spearman(tr.G_information_need,K); local_spearman(tr.G_information_need,C); local_spearman(tr.G_information_need,F); local_spearman(tr.G_information_need,W); local_spearman(tr.G_information_need_resid,K); local_spearman(tr.G_information_need_resid,W); ...
    local_spearman(tr.G_support,F); local_spearman(tr.G_support,W); local_spearman(abs(tr.G_D_support),W); ...
    local_spearman(tr.G_mechanism_load,abs(tr.G_D_support)); local_spearman(tr.G_mechanism_load,tr.G_Pol_support); ...
    local_spearman(tr.G_communication_burden,tr.G_information_need); local_spearman(tr.G_communication_burden,tr.G_mechanism_load); ...
    local_spearman(tr.G_action_priority,tr.G_information_need); local_spearman(tr.G_action_priority,W)];
ww = local_get_vector(fc,'case_weight',numel(K),1);
weighted_rho = [local_weighted_spearman(tr.G_information_need,K,ww); ...
    local_weighted_spearman(tr.G_information_need,C,ww); ...
    local_weighted_spearman(tr.G_information_need,F,ww); ...
    local_weighted_spearman(tr.G_information_need,W,ww); ...
    local_weighted_spearman(tr.G_information_need_resid,K,ww); ...
    local_weighted_spearman(tr.G_information_need_resid,W,ww); ...
    local_weighted_spearman(tr.G_support,F,ww); ...
    local_weighted_spearman(tr.G_support,W,ww); ...
    local_weighted_spearman(abs(tr.G_D_support),W,ww); ...
    local_weighted_spearman(tr.G_mechanism_load,abs(tr.G_D_support),ww); ...
    local_weighted_spearman(tr.G_mechanism_load,tr.G_Pol_support,ww); ...
    local_weighted_spearman(tr.G_communication_burden,tr.G_information_need,ww); ...
    local_weighted_spearman(tr.G_communication_burden,tr.G_mechanism_load,ww); ...
    local_weighted_spearman(tr.G_action_priority,tr.G_information_need,ww); ...
    local_weighted_spearman(tr.G_action_priority,W,ww)];
interpretation = ["Information need should align with low clarity"; "Information need should align with change/shock"; ...
    "Information need should align with fragility"; "Information need should align with tail-risk"; "Residualized information diagnostic vs low clarity"; "Residualized information diagnostic vs tail-risk"; ...
    "Support may be lower when fragility is high"; "Support may be lower when tail-risk is high"; ...
    "Divergence may be larger for tail-risk profiles"; "Mechanism load should reflect high-low support divergence"; "Mechanism load should reflect support polarization"; ...
    "Communication burden should align with information need"; "Communication burden should align with mechanism load"; "Action priority should align with info need"; ...
    "Action priority should align with tail-risk/guardrail need"];
proxyT = table(name, rho, weighted_rho, interpretation);
end

function compT = local_comparison_table(tr, fc, cfg)
scores = struct();
scores.G_base = tr.G_base(:);
scores.fuzzy_topsis = local_topsis_score(fc);
scores.fuzzy_vikor = local_vikor_score(fc, cfg);
scores.entropy_fuzzy = local_entropy_fuzzy_score(fc);
scores.G_support_diagnostic = tr.G_support(:);
scores.G_mechanism_load_diagnostic = tr.G_mechanism_load(:);
scores.G_communication_burden_diagnostic = tr.G_communication_burden(:);
scores.G_action_priority_diagnostic = tr.G_action_priority(:);

names = string(fieldnames(scores));
compT = table();
for i = 1:numel(names)
    val = local_validate_ranking(scores.(names(i)), fc);
    row = table(names(i), val.spearman_rho, val.weighted_spearman_rho, val.ndcg_at_10pct, val.weighted_ndcg_at_10pct, ...
        val.top_bottom_gap_truth, val.weighted_top_bottom_gap_truth, ...
        'VariableNames', {'model','spearman','weighted_spearman','ndcg10','weighted_ndcg10','top_bottom_gap','weighted_top_bottom_gap'});
    compT = [compT; row]; %#ok<AGROW>
end
end

function abT = local_ablation_table(tr, fc, params, sw)
K = local_get_vector(fc,'K_alt',numel(tr.G_base),0);
C = local_get_vector(fc,'C_alt',numel(tr.G_base),0);
F = local_get_vector(fc,'F_alt',numel(tr.G_base),0);
W = local_get_vector(fc,'W_tail_alt',numel(tr.G_base),0);
meanGamma = mean(params.gamma,'omitnan');
variants = struct();
variants.full_support = tr.G_support(:);
variants.no_K = tr.G_support(:) + sw.w_K .* K;
variants.no_C = tr.G_support(:) + sw.w_C .* C;
variants.no_F = tr.G_support(:) + sw.w_F .* F;
variants.no_Wtail = tr.G_support(:) + sw.w_W .* meanGamma .* W;
variants.no_profile_proxy = tr.G_base(:);

names = string(fieldnames(variants));
abT = table();
for i = 1:numel(names)
    val = local_validate_ranking(variants.(names(i)), fc);
    corrInfo = local_spearman(variants.(names(i)), tr.G_information_need);
    note = "Risk-ranking ablation only; psychological mechanism contribution is evaluated through D/Pol/mechanism-load/action tables, not as a claim of improved risk ranking.";
    row = table(names(i), val.spearman_rho, val.weighted_spearman_rho, val.ndcg_at_10pct, val.weighted_ndcg_at_10pct, corrInfo, note, ...
        'VariableNames', {'ablation','spearman','weighted_spearman','ndcg10','weighted_ndcg10','corr_with_G_info','interpretation_note'});
    abT = [abT; row]; %#ok<AGROW>
end
end

function bootT = local_bootstrap_table(tr, fc, cfg)
% Profile bootstrap with replicate weights; duplicate profile draws are retained.
bootT = p4fresh.eval.run_profile_bootstrap_ci(tr, fc, cfg.bootstrap.n_reps, cfg.bootstrap.seed);
end

function diag = local_diagnostics(tr)
diag = struct();
diag.unique_primary_scores_12dp = local_nunique_round(tr.G, 12);
diag.unique_base_scores_12dp = local_nunique_round(tr.G_base, 12);
diag.unique_PT_mean_scores_12dp = local_nunique_round(tr.G_PT_mean, 12);
diag.unique_support_scores_12dp = local_nunique_round(tr.G_support, 12);
diag.unique_choice_scores_12dp = local_nunique_round(tr.G_choice_propensity, 12);
diag.unique_information_need_scores_12dp = local_nunique_round(tr.G_information_need, 12);
diag.unique_mechanism_load_scores_12dp = local_nunique_round(tr.G_mechanism_load, 12);
diag.unique_communication_burden_scores_12dp = local_nunique_round(tr.G_communication_burden, 12);
diag.unique_D_PT_scores_12dp = local_nunique_round(tr.G_D_PT, 12);
diag.unique_D_support_scores_12dp = local_nunique_round(tr.G_D_support, 12);
diag.unique_action_priority_scores_12dp = local_nunique_round(tr.G_action_priority, 12);
diag.PT_mean_minus_base_max_abs = tr.sanity.PT_mean_minus_base_max_abs;
diag.PT_mean_minus_base_mean_abs = tr.sanity.PT_mean_minus_base_mean_abs;
diag.deployable_action_leakage_free = tr.sanity.deployable_action_leakage_free;
if isfield(tr,'action_flag_rate_table') && ~isempty(tr.action_flag_rate_table)
    diag.flag_anxiety_rate = tr.action_flag_rate_table.rate(tr.action_flag_rate_table.flag == "anxiety_sensitive");
else
    diag.flag_anxiety_rate = NaN;
end
end

% =========================================================================
% v8 action visibility, co-occurrence, ablation, and calibration helpers
% =========================================================================
function T = local_action_flag_rate_table(actionT)
flags = ["info";"anxiety_sensitive";"resilience";"guardrail";"capacity";"standard"];
n = height(actionT);
count = zeros(numel(flags),1);
rate = zeros(numel(flags),1);
for i = 1:numel(flags)
    count(i) = sum(contains(";" + string(actionT.secondary_flags) + ";", ";" + flags(i) + ";"));
    rate(i) = count(i) ./ max(n,1);
end
T = table(flags, count, rate, 'VariableNames', {'flag','count','rate'});
end

function T = local_action_cooccurrence_table(actionT)
flags = ["info";"anxiety_sensitive";"resilience";"guardrail";"capacity"];
n = height(actionT);
rows = strings(0,1); cols = strings(0,1); count = zeros(0,1); rate = zeros(0,1);
S = ";" + string(actionT.secondary_flags) + ";";
for i = 1:numel(flags)
    for j = 1:numel(flags)
        hit = contains(S, ";" + flags(i) + ";") & contains(S, ";" + flags(j) + ";");
        rows(end+1,1) = flags(i); %#ok<AGROW>
        cols(end+1,1) = flags(j); %#ok<AGROW>
        count(end+1,1) = sum(hit); %#ok<AGROW>
        rate(end+1,1) = sum(hit) ./ max(n,1); %#ok<AGROW>
    end
end
T = table(rows, cols, count, rate, 'VariableNames', {'flag_i','flag_j','count','rate'});
end

function T = local_mechanism_visibility_table(tr, actionT)
flagT = local_action_flag_rate_table(actionT);
getRate = @(nm) flagT.rate(find(flagT.flag == string(nm),1));
metric = ["mean_abs_D_PT";"mean_Pol_PT";"mean_abs_D_support";"mean_Pol_support";"mean_mechanism_load";"mean_communication_burden";"flag_anxiety_rate";"flag_info_rate";"flag_resilience_rate";"flag_guardrail_rate"];
value = [mean(abs(tr.G_D_PT),'omitnan'); mean(tr.G_Pol_PT,'omitnan'); mean(abs(tr.G_D_support),'omitnan'); mean(tr.G_Pol_support,'omitnan'); mean(tr.G_mechanism_load,'omitnan'); mean(tr.G_communication_burden,'omitnan'); ...
    getRate("anxiety_sensitive"); getRate("info"); getRate("resilience"); getRate("guardrail")];
interpretation = ["High-low anxiety PT divergence";"PT psychological disagreement";"Support divergence";"Support psychological disagreement";"Label-free mechanism-load summary";"Label-free communication-burden summary"; ...
    "Psychology mechanism visible in secondary flags";"Information-need visibility";"Fragility/resilience visibility";"Guardrail visibility"];
T = table(metric, value, interpretation);
end

function T = local_action_ablation_table(actionT)
% True action-level ablation recomputation without expert labels.
% Expert/user labels can be evaluated later with p4fresh.eval.evaluate_human_labels.
fullPrimary = string(actionT.primary_action);
fullFlags = string(actionT.secondary_flags);
variants = ["A_full";"A_no_psych";"A_no_mechanism_load";"A_no_info";"A_no_resilience";"A_no_guardrail";"A_single_label"];
description = ["All deployable scores and multi-label flags"; ...
    "Remove S_anxiety and anxiety-sensitive secondary flag"; ...
    "Remove only G_mechanism_load contribution inside S_anxiety"; ...
    "Remove S_info and information secondary flag"; ...
    "Remove S_resilience and resilience secondary flag"; ...
    "Remove S_guardrail and guardrail secondary flag"; ...
    "Keep primary action only and remove all secondary flags"];
primary_changed_rate = NaN(numel(variants),1);
flag_jaccard_distance = NaN(numel(variants),1);
mean_flags_per_profile = NaN(numel(variants),1);
can_run_without_expert_labels = true(numel(variants),1);
for v = 1:numel(variants)
    [p2, f2] = local_recompute_action_variant(actionT, variants(v));
    primary_changed_rate(v) = mean(p2 ~= fullPrimary, 'omitnan');
    flag_jaccard_distance(v) = mean(local_flag_jaccard_distance(fullFlags, f2), 'omitnan');
    mean_flags_per_profile(v) = mean(local_count_flags(f2), 'omitnan');
end
T = table(variants, description, primary_changed_rate, flag_jaccard_distance, mean_flags_per_profile, can_run_without_expert_labels, ...
    'VariableNames', {'action_ablation','description','primary_changed_rate','flag_jaccard_distance','mean_flags_per_profile','can_run_without_expert_labels'});
end

function [primary_action, secondary_flags] = local_recompute_action_variant(actionT, variant)
%LOCAL_RECOMPUTE_ACTION_VARIANT Recompute action variants using final-guideline hierarchy.
%
% Important fix:
%   Do NOT use simple argmax here. The deployable primary action in v8 uses
%   the same final-guideline hierarchical communication policy as the main
%   deployable table. This keeps action_ablation_table consistent with
%   run_action_ablation_against_labels.m.
%
% No truth, audit, future outcome, or expert label is used.

variant = string(variant);

S_info = double(actionT.S_info);
S_anxiety = double(actionT.S_anxiety);
S_resilience = double(actionT.S_resilience);
S_guardrail = double(actionT.S_guardrail);
S_capacity = double(actionT.S_capacity);

flagNames = ["info","anxiety_sensitive","resilience","guardrail","capacity"];
flag_info = logical(actionT.flag_info);
flag_anxiety = logical(actionT.flag_anxiety);
flag_resilience = logical(actionT.flag_resilience);
flag_guardrail = logical(actionT.flag_guardrail);
flag_capacity = logical(actionT.flag_capacity);

% Use NaN to disable a gate. Do not use -Inf, because quantile(-Inf) can
% make "score >= threshold" true for all rows.
switch variant
    case "A_no_psych"
        S_anxiety(:) = NaN;
        flag_anxiety(:) = false;
    case "A_no_mechanism_load"
        % Recomputed below after normalized D/Pol fields are available.
    case "A_no_info"
        S_info(:) = NaN;
        flag_info(:) = false;
    case "A_no_resilience"
        S_resilience(:) = NaN;
        flag_resilience(:) = false;
    case "A_no_guardrail"
        S_guardrail(:) = NaN;
        flag_guardrail(:) = false;
    case "A_single_label"
        flag_info(:) = false;
        flag_anxiety(:) = false;
        flag_resilience(:) = false;
        flag_guardrail(:) = false;
        flag_capacity(:) = false;
    otherwise
        % A_full or unknown handled as full.
end

zInfo = local_minmax01(actionT.G_info_core);
zInfoResidPos = local_minmax01(max(actionT.G_info_resid,0));
zK = local_minmax01(actionT.K);
zC = local_minmax01(actionT.C);
zAbsDsup = local_minmax01(actionT.abs_D_support);
zPolsup = local_minmax01(actionT.Pol_support);
zAbsDpt = local_minmax01(actionT.abs_D_PT);
zF = local_minmax01(actionT.F);
zW = local_minmax01(actionT.W_tail);
zBase = local_minmax01(actionT.G_base);

if variant == "A_no_mechanism_load"
    S_anxiety = local_anxiety_without_mechanism(zAbsDsup, zPolsup, zAbsDpt);
end

primary_action = local_final_guideline_primary_policy(S_info, S_anxiety, S_resilience, S_guardrail, S_capacity, ...
    zInfo, zInfoResidPos, zK, zC, zAbsDsup, zPolsup, zAbsDpt, zF, zW, zBase);

flag_info = flag_info | primary_action == "Information supplementation";
flag_anxiety = flag_anxiety | primary_action == "Anxiety-sensitive explanation";
flag_resilience = flag_resilience | primary_action == "Protective financial resilience communication";
flag_guardrail = flag_guardrail | primary_action == "Guardrail explanation";
flag_capacity = flag_capacity | primary_action == "Standard risk-capacity communication";

if variant == "A_no_psych", flag_anxiety(:) = false; end
if variant == "A_no_info", flag_info(:) = false; end
if variant == "A_no_resilience", flag_resilience(:) = false; end
if variant == "A_no_guardrail", flag_guardrail(:) = false; end

flags = [flag_info, flag_anxiety, flag_resilience, flag_guardrail, flag_capacity];
secondary_flags = strings(size(primary_action));

for i = 1:numel(primary_action)
    if variant == "A_single_label"
        secondary_flags(i) = "standard";
    else
        fs = flagNames(flags(i,:));
        if isempty(fs)
            secondary_flags(i) = "standard";
        else
            secondary_flags(i) = strjoin(fs, ";");
        end
    end
end
end


function S = local_anxiety_without_mechanism(zAbsDsup, zPolsup, zAbsDpt)
w = [0.35 0.25 0.15];
w = w ./ sum(w);
S = w(1).*zAbsDsup + w(2).*zPolsup + w(3).*zAbsDpt;
end

function d = local_flag_jaccard_distance(a,b)
allFlags = ["info","anxiety_sensitive","resilience","guardrail","capacity"];
d = NaN(numel(a),1);
for i = 1:numel(a)
    A = local_flag_bool(a(i), allFlags);
    B = local_flag_bool(b(i), allFlags);
    uni = sum(A|B); inter = sum(A&B);
    if uni == 0, d(i) = 0; else, d(i) = 1 - inter/uni; end
end
end

function c = local_count_flags(s)
allFlags = ["info","anxiety_sensitive","resilience","guardrail","capacity"];
c = zeros(numel(s),1);
for i = 1:numel(s), c(i) = sum(local_flag_bool(s(i), allFlags)); end
end

function b = local_flag_bool(s, allFlags)
s = ";" + lower(string(s)) + ";";
s = replace(s, ",", ";");
s = replace(s, " ", "_");
b = false(1,numel(allFlags));
for j = 1:numel(allFlags), b(j) = contains(s,";"+allFlags(j)+";"); end
end

function pct = local_get_audit_residual_pct(cfg)
pct = 0.75;
if isfield(cfg,'audit') && isfield(cfg.audit,'residual_pct'), pct = cfg.audit.residual_pct; return; end
if isfield(cfg,'action') && isfield(cfg.action,'audit_residual_pct'), pct = cfg.action.audit_residual_pct; end
end

function [yhat, residual] = local_crossfit_calibrated_residual(score, truth, w, cfg)
score = double(score(:)); truth = double(truth(:)); w = double(w(:));
n = numel(score); yhat = NaN(n,1); residual = NaN(n,1);
mask = isfinite(score) & isfinite(truth) & isfinite(w) & w > 0;
if sum(mask) < 5
    yhat(mask) = local_weighted_mean(truth(mask), w(mask));
    residual(mask) = truth(mask) - yhat(mask);
    return;
end
K = 5;
if isfield(cfg,'audit') && isfield(cfg.audit,'calibration_folds'), K = cfg.audit.calibration_folds; end
K = max(2, min(K, sum(mask)));
idxAll = find(mask);
[~,ord] = sort(score(idxAll));
idxAll = idxAll(ord);
foldId = mod((1:numel(idxAll))'-1, K) + 1;
for k = 1:K
    test = idxAll(foldId == k);
    train = idxAll(foldId ~= k);
    if numel(train) < 5
        yhat(test) = local_weighted_mean(truth(train), w(train));
    else
        model = local_fit_isotonic(score(train), truth(train), w(train));
        yhat(test) = local_predict_isotonic(model, score(test));
    end
end
bad = mask & ~isfinite(yhat);
yhat(bad) = local_weighted_mean(truth(mask), w(mask));
yhat = local_clip01(yhat);
residual(mask) = truth(mask) - yhat(mask);
end

function model = local_fit_isotonic(x, y, w)
x = double(x(:)); y = double(y(:)); w = double(w(:));
mask = isfinite(x) & isfinite(y) & isfinite(w) & w > 0;
x = x(mask); y = y(mask); w = w(mask);
[x,ord] = sort(x); y = y(ord); w = w(ord);
% Collapse duplicate x values first.
[grp, ux] = findgroups(x);
yc = splitapply(@local_weighted_mean_pair, y, w, grp);
wc = splitapply(@local_sum_omitnan, w, grp);
% Pool adjacent violators algorithm for nondecreasing y.
level = yc(:); weight = wc(:); left = (1:numel(level))'; right = left;
i = 1;
while i < numel(level)
    if level(i) <= level(i+1) + 1e-12
        i = i + 1;
    else
        newW = weight(i) + weight(i+1);
        newLevel = (level(i)*weight(i) + level(i+1)*weight(i+1)) ./ max(newW, eps);
        level(i) = newLevel; weight(i) = newW; right(i) = right(i+1);
        level(i+1) = []; weight(i+1) = []; left(i+1) = []; right(i+1) = [];
        if i > 1, i = i - 1; end
    end
end
xBlock = zeros(numel(level),1);
for b = 1:numel(level)
    xBlock(b) = mean(ux(left(b):right(b)), 'omitnan');
end
model.x = xBlock;
model.y = local_clip01(level);
end

function yhat = local_predict_isotonic(model, xnew)
xnew = double(xnew(:));
if numel(model.x) == 1
    yhat = repmat(model.y(1), size(xnew));
else
    yhat = interp1(model.x, model.y, xnew, 'linear', 'extrap');
end
yhat = local_clip01(yhat);
end


function residAlt = local_residualize_info_by_profile(fc, info, support, base, cfg)
% Unsupervised cross-fitted residualized information diagnostic.
% Predicts G_info from G_support and G_base without using any ground truth.
pid = string(fc.profile_id(:));
[G, keys] = findgroups(pid); %#ok<ASGLU>
infoP = splitapply(@local_mean_omitnan, double(info(:)), G);
supP = splitapply(@local_mean_omitnan, double(support(:)), G);
baseP = splitapply(@local_mean_omitnan, double(base(:)), G);
nP = numel(infoP);
pred = NaN(nP,1);
Kfold = 5;
ridge = 1e-6;
if isfield(cfg,'info_resid') && isfield(cfg.info_resid,'folds'), Kfold = cfg.info_resid.folds; end
if isfield(cfg,'info_resid') && isfield(cfg.info_resid,'ridge'), ridge = cfg.info_resid.ridge; end
mask = isfinite(infoP) & isfinite(supP) & isfinite(baseP);
idxAll = find(mask);
if numel(idxAll) < 5
    pred(mask) = mean(infoP(mask),'omitnan');
else
    Kfold = max(2, min(Kfold, numel(idxAll)));
    [~,ord] = sort(supP(idxAll) + 0.01*baseP(idxAll));
    idxAll = idxAll(ord);
    fold = mod((1:numel(idxAll))'-1, Kfold) + 1;
    for k = 1:Kfold
        test = idxAll(fold==k);
        train = idxAll(fold~=k);
        Xtr = [ones(numel(train),1), local_zscore(supP(train)), local_zscore(baseP(train))];
        ytr = infoP(train);
        ok = all(isfinite(Xtr),2) & isfinite(ytr);
        Xtr = Xtr(ok,:); ytr = ytr(ok);
        if numel(ytr) < 3
            pred(test) = mean(infoP(train),'omitnan');
        else
            I = eye(size(Xtr,2)); I(1,1) = 0;
            b = (Xtr'*Xtr + ridge*I) \ (Xtr'*ytr);
            Xte = [ones(numel(test),1), local_zscore_with_ref(supP(test),supP(train)), local_zscore_with_ref(baseP(test),baseP(train))];
            pred(test) = Xte*b;
        end
    end
end
bad = mask & ~isfinite(pred);
pred(bad) = mean(infoP(mask),'omitnan');
residP = infoP - pred;
residP(~isfinite(residP)) = 0;
residAlt = residP(G);
end

function z = local_zscore_with_ref(x, ref)
mu = mean(ref,'omitnan'); sd = std(ref,'omitnan');
if ~isfinite(sd) || sd < 1e-12, z = zeros(size(x)); else, z = (x-mu)./sd; end
z(~isfinite(z)) = 0;
end

function primary_action = local_final_guideline_primary_policy(S_info, S_anxiety, S_resilience, S_guardrail, S_capacity, zInfo, zInfoResidPos, zK, zC, zAbsDsup, zPolsup, zAbsDpt, zF, zW, zBase)
%LOCAL_FINAL_GUIDELINE_PRIMARY_POLICY v8 final-guideline hierarchical action policy.
%
% Why not simple argmax?
%   Simple argmax tends to collapse primary_action into Standard/Protective
%   because S_capacity and S_resilience dominate many profiles. The final
%   expert-guideline policy gives priority to human communication blockers:
%   information insufficiency, psychological divergence, and guardrail need.
%
% Priority order:
%   1. Information supplementation
%   2. Anxiety-sensitive explanation
%   3. Guardrail explanation
%   4. Protective financial resilience communication
%   5. Standard risk-capacity communication
%
% Only deployable variables are used. No truth, audit, residual_calibrated,
% future outcome, or expert labels are used.

n = numel(S_info);
primary_action = repmat("Standard risk-capacity communication", n, 1);

riskPressure = max(zF, zW);

infoGate = S_info >= local_quantile(S_info, 0.68) & ...
    (zInfo >= local_quantile(zInfo, 0.68) | ...
     zInfoResidPos >= local_quantile(zInfoResidPos, 0.68) | ...
     zK >= local_quantile(zK, 0.62) | ...
     zC >= local_quantile(zC, 0.70));

anxietyGate = S_anxiety >= local_quantile(S_anxiety, 0.68) & ...
    (zAbsDsup >= local_quantile(zAbsDsup, 0.62) | ...
     zPolsup >= local_quantile(zPolsup, 0.62) | ...
     zAbsDpt >= local_quantile(zAbsDpt, 0.62));

guardrailGate = S_guardrail >= local_quantile(S_guardrail, 0.62) & ...
    zBase >= local_quantile(zBase, 0.55) & ...
    riskPressure >= local_quantile(riskPressure, 0.55);

resilienceGate = S_resilience >= local_quantile(S_resilience, 0.55) & ...
    (zF >= local_quantile(zF, 0.55) | ...
     zW >= local_quantile(zW, 0.55) | ...
     zBase <= local_quantile(zBase, 0.40));

% Apply the communication-priority hierarchy. These are not fitted to truth.
primary_action(resilienceGate) = "Protective financial resilience communication";
primary_action(guardrailGate) = "Guardrail explanation";
primary_action(anxietyGate) = "Anxiety-sensitive explanation";
primary_action(infoGate) = "Information supplementation";

% Capacity override only when the profile is clearly capacity-oriented and
% no higher-priority blocker is present.
capacityGate = S_capacity >= local_quantile(S_capacity, 0.70) & ...
    zBase >= local_quantile(zBase, 0.65) & ...
    riskPressure <= local_quantile(riskPressure, 0.55) & ...
    ~infoGate & ~anxietyGate & ~guardrailGate & ~resilienceGate;
primary_action(capacityGate) = "Standard risk-capacity communication";
end

function txt = local_primary_rationale(action)
switch string(action)
    case "Information supplementation"
        txt = "Low clarity or high explanation load; clarify missing, complex, or shock-related evidence before risk communication.";
    case "Anxiety-sensitive explanation"
        txt = "Psychological divergence or support polarization is high; adapt the explanation to anxiety-sensitive risk perception.";
    case "Protective financial resilience communication"
        txt = "Fragility or tail-risk pressure is high; prioritize buffers, resilience, and downside-risk explanation.";
    case "Guardrail explanation"
        txt = "Risk-capacity baseline is high but fragility or tail-risk pressure is also elevated; add protective boundary conditions.";
    otherwise
        txt = "Risk-capacity evidence is relatively clear; standard risk-capacity communication is acceptable.";
end
end

function txt = local_secondary_cautions(flags)
flags = string(flags(:));
if isempty(flags) || any(flags == "standard")
    txt = "No additional secondary caution beyond the primary communication action.";
    return;
end
parts = strings(0,1);
for i = 1:numel(flags)
    switch flags(i)
        case "info"
            parts(end+1,1) = "information clarification"; %#ok<AGROW>
        case "anxiety_sensitive"
            parts(end+1,1) = "anxiety-sensitive framing"; %#ok<AGROW>
        case "resilience"
            parts(end+1,1) = "financial resilience protection"; %#ok<AGROW>
        case "guardrail"
            parts(end+1,1) = "risk guardrail boundary"; %#ok<AGROW>
        case "capacity"
            parts(end+1,1) = "risk-capacity confirmation"; %#ok<AGROW>
    end
end
if isempty(parts), txt = "No additional secondary caution."; else, txt = strjoin(unique(parts,'stable'), "; "); end
end

function txt = local_top_drivers(names, values)
names = string(names(:)); values = double(values(:));
values(~isfinite(values)) = -Inf;
[~,ord] = sort(values, 'descend');
ord = ord(1:min(3,numel(ord)));
parts = strings(numel(ord),1);
for i = 1:numel(ord)
    parts(i) = names(ord(i)) + "=" + string(round(values(ord(i)),3));
end
txt = strjoin(parts, "; ");
end


function z = local_mechanism_load(D_PT, Pol_PT, D_support, Pol_support, cfg)
%LOCAL_MECHANISM_LOAD Label-free communication-burden mechanism score.
%
% This score summarizes anxiety-related divergence and polarization. It is
% used for risk communication support and action policy, not as a supervised
% expert-label target and not as the main financial risk-truth score.
w = [0.25 0.20 0.30 0.25];
if isfield(cfg,'transfer') && isfield(cfg.transfer,'mechanism_load_weights')
    mw = cfg.transfer.mechanism_load_weights;
    cand = [local_getnum(mw,'pt_divergence',w(1)), local_getnum(mw,'pt_polarization',w(2)), ...
            local_getnum(mw,'support_divergence',w(3)), local_getnum(mw,'support_polarization',w(4))];
    if all(isfinite(cand)) && sum(cand) > eps, w = cand ./ sum(cand); end
end
X = [local_minmax01(abs(D_PT(:))), local_minmax01(Pol_PT(:)), local_minmax01(abs(D_support(:))), local_minmax01(Pol_support(:))];
z = X * w(:);
z = local_minmax01(z);
end

function w = local_score_weight(S, name, fallback)
w = double(fallback(:))';
if isstruct(S) && isfield(S, name)
    cand = double(S.(name)(:))';
    if numel(cand) == numel(w) && all(isfinite(cand)) && sum(cand) > eps
        w = cand ./ sum(cand);
    end
else
    w = w ./ max(sum(w), eps);
end
end

function local_assert_no_deployable_leakage(T, tableName)
names = lower(string(T.Properties.VariableNames));
for i = 1:numel(names)
    nm = names(i);
    if contains(nm,"truth") || contains(nm,"ground_truth") || contains(nm,"expert") || contains(nm,"future") || contains(nm,"outcome") || contains(nm,"audit")
        error('run_transfer:DeployableLeakageColumn', '%s contains forbidden leakage column: %s', string(tableName), nm);
    end
    if contains(nm,"residual") && ~(nm == "g_info_resid")
        error('run_transfer:DeployableLeakageColumn', '%s contains forbidden residual column: %s', string(tableName), nm);
    end
end
end

% =========================================================================
% Baseline scores
% =========================================================================
function X = local_benefit_matrix(fc)
B = local_get_vector(fc,'B_alt',numel(fc.B_alt),0.5);
U = local_get_vector(fc,'U_alt',numel(B),0.5);
K = local_get_vector(fc,'K_alt',numel(B),0.5);
C = local_get_vector(fc,'C_alt',numel(B),0.5);
F = local_get_vector(fc,'F_alt',numel(B),0.5);
X = local_clip01([B, 1-U, 1-K, 1-C, 1-F]);
end

function s = local_entropy_fuzzy_score(fc)
X = local_benefit_matrix(fc);
w = local_entropy_weights(X);
s = X*w(:);
end

function s = local_topsis_score(fc)
X = local_benefit_matrix(fc);
w = local_entropy_weights(X);
Xw = X .* w(:)';
ideal = max(Xw,[],1);
nadir = min(Xw,[],1);
dPlus = sqrt(sum((Xw - ideal).^2,2));
dMinus = sqrt(sum((Xw - nadir).^2,2));
s = dMinus ./ max(dPlus + dMinus, eps);
end

function s = local_vikor_score(fc, cfg)
X = local_benefit_matrix(fc);
w = local_entropy_weights(X);
fstar = max(X,[],1);
fminus = min(X,[],1);
den = max(fstar - fminus, eps);
Rmat = (fstar - X) ./ den;
S = Rmat * w(:);
R = max(Rmat .* w(:)', [], 2);
v = 0.5;
if isfield(cfg,'experiment') && isfield(cfg.experiment,'vikor_v'), v = cfg.experiment.vikor_v; end
Q = v .* local_minmax01(S) + (1-v) .* local_minmax01(R);
s = 1 - Q;
end

function w = local_entropy_weights(X)
X = local_clip01(double(X));
[n,k] = size(X);
colsum = sum(X,1);
P = X ./ max(colsum, eps);
P(P<=0) = eps;
E = -sum(P.*log(P),1) ./ max(log(n), eps);
D = 1 - E;
if sum(D) <= eps || any(~isfinite(D))
    w = ones(k,1)/k;
else
    w = D(:) ./ sum(D);
end
end

% =========================================================================
% Validation
% =========================================================================
function val = local_validate_ranking(scores, fc)
val = struct('available',false,'ground_truth_label',"",'spearman_rho',NaN,'weighted_spearman_rho',NaN, ...
    'ndcg_at_10pct',NaN,'weighted_ndcg_at_10pct',NaN,'ndcg_at_20pct',NaN,'weighted_ndcg_at_20pct',NaN, ...
    'top10pct_mean_truth',NaN,'bottom10pct_mean_truth',NaN,'top_bottom_gap_truth',NaN, ...
    'weighted_top_bottom_gap_truth',NaN,'n_alternatives',int32(numel(scores)));
if ~isfield(fc,'ground_truth') || numel(fc.ground_truth) ~= numel(scores), return; end
s = double(scores(:)); y = double(fc.ground_truth(:));
w = local_get_vector(fc,'case_weight',numel(s),1);
mask = isfinite(s) & isfinite(y) & isfinite(w) & w > 0;
s = s(mask); y = y(mask); w = w(mask);
if numel(y) < 3 || max(y) <= min(y) || max(s) <= min(s), return; end
val.available = true;
if isfield(fc,'ground_truth_label'), val.ground_truth_label = string(fc.ground_truth_label); end
val.n_alternatives = int32(numel(y));
val.spearman_rho = local_spearman(s,y);
val.weighted_spearman_rho = local_weighted_spearman(s,y,w);
val.ndcg_at_10pct = local_ndcg_at_pct(s,y,0.10);
val.weighted_ndcg_at_10pct = local_weighted_ndcg_at_pct(s,y,w,0.10);
val.ndcg_at_20pct = local_ndcg_at_pct(s,y,0.20);
val.weighted_ndcg_at_20pct = local_weighted_ndcg_at_pct(s,y,w,0.20);
[~,ord] = sort(s,'descend');
n = numel(y); k = max(1,ceil(0.10*n));
val.top10pct_mean_truth = mean(y(ord(1:k)),'omitnan');
val.bottom10pct_mean_truth = mean(y(ord(n-k+1:n)),'omitnan');
val.top_bottom_gap_truth = val.top10pct_mean_truth - val.bottom10pct_mean_truth;
val.weighted_top_bottom_gap_truth = local_weighted_mean(y(ord(1:k)),w(ord(1:k))) - local_weighted_mean(y(ord(n-k+1:n)),w(ord(n-k+1:n)));
end

function rho = local_spearman(x,y)
rho = local_pearson(local_tied_rank(x), local_tied_rank(y));
end

function rho = local_weighted_spearman(x,y,w)
rho = local_weighted_corr(local_tied_rank(x), local_tied_rank(y), w);
end

function ndcg = local_ndcg_at_pct(scores, truth, pct)
n = numel(scores); k = max(1,min(n,ceil(pct*n)));
rel = local_minmax01(truth(:));
[~,ord] = sort(scores(:),'descend');
[~,ideal] = sort(rel(:),'descend');
den = local_dcg(rel(ideal(1:k)));
if den <= eps, ndcg = NaN; else, ndcg = local_dcg(rel(ord(1:k)))/den; end
end

function ndcg = local_weighted_ndcg_at_pct(scores, truth, w, pct)
n = numel(scores); k = max(1,min(n,ceil(pct*n)));
rel = local_minmax01(truth(:));
[~,ord] = sort(scores(:),'descend');
[~,ideal] = sort(rel(:),'descend');
den = local_weighted_dcg(rel(ideal(1:k)), w(ideal(1:k)));
if den <= eps, ndcg = NaN; else, ndcg = local_weighted_dcg(rel(ord(1:k)), w(ord(1:k)))/den; end
end

function d = local_dcg(rel)
rel = double(rel(:)); pos = (1:numel(rel))';
d = sum((2.^rel - 1) ./ log2(pos + 1));
end

function d = local_weighted_dcg(rel,w)
rel = double(rel(:)); w = double(w(:)); pos = (1:numel(rel))';
d = sum(w .* (2.^rel - 1) ./ log2(pos + 1));
end

% =========================================================================
% Utility functions
% =========================================================================
function params = local_extract_params(sr)
n = numel(sr);
fields = {'tau','ell','beta','kappa','chi','phi','gamma','psi'};
for f = 1:numel(fields), params.(fields{f}) = NaN(n,1); end
params.high_anxiety = false(n,1);
for i = 1:n
    bs = sr(i).best_result.behavior_summary;
    params.tau(i) = local_getnum(bs, 'risk_tolerance', NaN);
    params.ell(i) = local_getnum(bs, 'loss_sensitivity', NaN);
    params.beta(i) = local_getnum(bs, 'choice_precision', NaN);
    params.kappa(i) = local_getnum(bs, 'low_clarity_sensitivity', NaN);
    params.chi(i) = local_getnum(bs, 'change_sensitivity', NaN);
    params.phi(i) = local_getnum(bs, 'fragility_sensitivity', NaN);
    params.gamma(i) = local_getnum(bs, 'worst_case_sensitivity', NaN);
    params.psi(i) = local_getnum(bs, 'latent_anxiety', NaN);
    if isfield(bs,'high_anxiety'), params.high_anxiety(i) = logical(bs.high_anxiety); end
end
params.tau = local_fill(params.tau, 1);
params.ell = local_fill(params.ell, 1);
params.beta = max(local_fill(params.beta, 1), 1e-6);
params.kappa = local_fill(params.kappa, 1);
params.chi = local_fill(params.chi, 1);
params.phi = local_fill(params.phi, 1);
params.gamma = local_clip(local_fill(params.gamma, 0.25), 0, 1);
params.psi = local_zscore(local_fill(params.psi, 0));
if ~any(params.high_anxiety) || ~any(~params.high_anxiety)
    params.high_anxiety = params.psi >= median(params.psi,'omitnan');
end
end

function X = local_expand_layer(fc, name, nS, m)
if ~isfield(fc, name)
    if any(strcmp(name, {'K','C','F'})), X = zeros(nS,m); return; end
    error('run_transfer:MissingLayer', 'fuzzy_case.%s is missing.', name);
end
X = double(fc.(name));
if isvector(X), X = X(:)'; end
if size(X,1) == 1 && nS > 1, X = repmat(X, nS, 1); end
if size(X,1) ~= nS || size(X,2) ~= m
    error('run_transfer:BadLayerShape', 'Layer %s must be nSubjects x nAlternatives. Got %dx%d, expected %dx%d.', name, size(X,1), size(X,2), nS, m);
end
end

function x = local_get_vector(S, name, n, fallback)
if isstruct(S) && isfield(S, name)
    x = double(S.(name)(:));
    if numel(x) == n, return; end
end
x = repmat(double(fallback), n, 1);
end

function tie = local_unsupervised_tiebreaker(fc, m)
B = local_get_vector(fc, 'B_alt', m, 0);
U = local_get_vector(fc, 'U_alt', m, 0);
K = local_get_vector(fc, 'K_alt', m, 0);
C = local_get_vector(fc, 'C_alt', m, 0);
F = local_get_vector(fc, 'F_alt', m, 0);
W = local_get_vector(fc, 'W_tail_alt', m, 0);
tie = 0.35*B - 0.25*U - 0.12*K - 0.10*C - 0.10*F - 0.08*W;
tie = tie - mean(tie,'omitnan');
den = max(abs(tie), [], 'omitnan');
if ~isfinite(den) || den <= eps, tie = ((1:m)'./max(m,1) - 0.5); else, tie = tie ./ den; end
tie = double(tie(:));
end

function r = local_tied_rank(x)
x = double(x(:)); r = NaN(size(x)); [sx,idx] = sort(x); n = numel(x); i = 1;
while i <= n
    if ~isfinite(sx(i)), i = i + 1; continue; end
    j = i;
    while j < n && sx(j+1) == sx(i), j = j + 1; end
    r(idx(i:j)) = (i+j)/2;
    i = j + 1;
end
end

function r = local_pearson(x,y)
x = double(x(:)); y = double(y(:)); mask = isfinite(x)&isfinite(y); x=x(mask); y=y(mask);
if numel(x)<3 || std(x)<=eps || std(y)<=eps, r=NaN; return; end
x=x-mean(x); y=y-mean(y); r=sum(x.*y)./sqrt(sum(x.^2).*sum(y.^2));
end

function r = local_weighted_corr(x,y,w)
x = double(x(:)); y = double(y(:)); w = double(w(:));
mask = isfinite(x)&isfinite(y)&isfinite(w)&w>0; x=x(mask); y=y(mask); w=w(mask);
if numel(x)<3, r=NaN; return; end
w = w ./ sum(w);
mx = sum(w.*x); my = sum(w.*y);
vx = sum(w.*(x-mx).^2); vy = sum(w.*(y-my).^2);
if vx<=eps || vy<=eps, r=NaN; else, r=sum(w.*(x-mx).*(y-my))./sqrt(vx*vy); end
end

function z = local_row_zscore(x)
x=double(x(:))'; mu=mean(x,'omitnan'); sd=std(x,'omitnan');
if ~isfinite(sd)||sd<1e-12, z=zeros(size(x)); else, z=(x-mu)./sd; end
z(~isfinite(z))=0;
end

function z = local_zscore(x)
x=double(x(:)); mu=mean(x,'omitnan'); sd=std(x,'omitnan');
if ~isfinite(sd)||sd<1e-12, z=zeros(size(x)); else, z=(x-mu)./sd; end
z(~isfinite(z))=0;
end

function y = local_sigmoid(x)
x=max(min(double(x),30),-30); y=1./(1+exp(-x));
end

function x = local_fill(x, fill)
x=double(x(:)); x(~isfinite(x))=fill;
end

function x = local_clip(x,lo,hi)
x=min(max(double(x),lo),hi);
end

function z = local_clip01(z)
z = local_clip(z,0,1);
end

function z = local_minmax01(x)
x=double(x(:)); z=zeros(size(x)); mask=isfinite(x);
if ~any(mask), z(:)=0.5; return; end
lo=min(x(mask)); hi=max(x(mask));
if hi<=lo+eps, z(:)=0.5; else, z(mask)=(x(mask)-lo)./(hi-lo); z(~mask)=0.5; end
z=min(max(z,0),1);
end

function q = local_quantile(x, p)
x = sort(double(x(:))); x = x(isfinite(x));
if isempty(x), q = NaN; return; end
p = min(max(double(p),0),1);
pos = 1 + (numel(x)-1)*p;
lo = floor(pos); hi = ceil(pos);
if lo == hi, q = x(lo); else, q = x(lo) + (pos-lo)*(x(hi)-x(lo)); end
end

function m = local_mean_omitnan(x)
x = double(x(:)); x = x(isfinite(x)); if isempty(x), m=NaN; else, m=mean(x); end
end

function m = local_mean_abs_omitnan(x)
x = abs(double(x(:))); x = x(isfinite(x)); if isempty(x), m=NaN; else, m=mean(x); end
end

function v = local_var_omitnan(x)
x = double(x(:)); x = x(isfinite(x)); if numel(x)<=1, v=NaN; else, v=var(x,0); end
end

function s = local_sum_omitnan(x)
x = double(x(:)); x = x(isfinite(x)); if isempty(x), s=NaN; else, s=sum(x); end
end

function y = local_weighted_mean(x,w)
x = double(x(:)); w = double(w(:));
mask = isfinite(x)&isfinite(w)&w>0;
if ~any(mask), y=NaN; else, y=sum(x(mask).*w(mask))./sum(w(mask)); end
end

function y = local_weighted_mean_pair(x,w)
y = local_weighted_mean(x,w);
end

function v = local_getnum(S,name,fallback)
if isstruct(S)&&isfield(S,name)&&~isempty(S.(name)), v=double(S.(name)); else, v=fallback; end
if ~isscalar(v)||~isfinite(v), v=fallback; end
end

function omega = local_get_omega(fc,nS)
if isfield(fc,'omega'), omega=double(fc.omega(:)); else, omega=[]; end
if isempty(omega)||numel(omega)~=nS, omega=ones(nS,1)/nS; else, omega=omega./max(sum(omega),eps); end
end

function n = local_nunique_round(x,d)
x=double(x(:)); x=x(isfinite(x));
if isempty(x), n=0; else, scale=10^d; n=numel(unique(round(x*scale)/scale)); end
end
