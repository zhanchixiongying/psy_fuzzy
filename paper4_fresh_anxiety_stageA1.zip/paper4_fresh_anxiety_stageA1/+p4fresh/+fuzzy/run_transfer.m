function transfer = run_transfer(caseA, fuzzy_case, cfg)
%RUN_TRANSFER Behaviorally calibrated transfer plus external ranking validation.
%
% Keeps the original function name and call signature:
%     p4fresh.fuzzy.run_transfer(caseA, fuzzy_case, cfg)
%
% Required fuzzy_case fields:
%     alternative_names, B, U, omega
% Optional validation fields:
%     ground_truth, ground_truth_label, baseline_score

%#ok<INUSD>
subjRes = caseA.subject_results;
nS = numel(subjRes);
altNames = fuzzy_case.alternative_names(:);
m = numel(altNames);

lambda = zeros(nS,1);
beta = zeros(nS,1);
for s = 1:nS
    br = subjRes(s).best_result;
    lambda(s) = br.behavior_summary.mean_lambda;
    beta(s) = br.behavior_summary.mean_beta;
end

omega = [];
if isfield(fuzzy_case, 'omega')
    omega = double(fuzzy_case.omega(:));
end
if isempty(omega)
    omega = ones(nS,1) / max(nS,1);
elseif numel(omega) ~= nS
    warning('run_transfer:OmegaSizeMismatch', ...
        'fuzzy_case.omega length does not match subjects; using uniform weights.');
    omega = ones(nS,1) / max(nS,1);
else
    omega = omega ./ max(sum(omega), eps);
end

B = double(fuzzy_case.B);
U = double(fuzzy_case.U);
if size(B,1) == 1 && nS > 1
    B = repmat(B, nS, 1);
end
if size(U,1) == 1 && nS > 1
    U = repmat(U, nS, 1);
end
if size(B,1) ~= nS || size(U,1) ~= nS || size(B,2) ~= m || size(U,2) ~= m
    error('run_transfer:BadFuzzyCaseShape', ...
        'Expected B and U to be n_subjects x n_alternatives. Got B=%dx%d, U=%dx%d, nS=%d, m=%d.', ...
        size(B,1), size(B,2), size(U,1), size(U,2), nS, m);
end

V = zeros(size(B));
P = zeros(size(B));
for s = 1:nS
    V(s,:) = lambda(s) .* B(s,:) - (1 - lambda(s)) .* U(s,:);
    z = beta(s) .* V(s,:);
    z = z - max(z); % stable softmax
    ex = exp(z);
    P(s,:) = ex ./ max(sum(ex), eps);
end

G = omega' * P;
[scoresSorted, ord] = sort(G, 'descend');
headGap = scoresSorted(1) - scoresSorted(2);
scoreRange = max(G) - min(G);
if scoreRange <= 1e-12
    ratio = NaN;
else
    ratio = headGap / scoreRange;
end

transfer = struct();
transfer.G = G(:);
transfer.rank_order = ord(:);
transfer.rank_names = altNames(ord);
transfer.subject_lambda = lambda(:);
transfer.subject_beta = beta(:);
transfer.subject_omega = omega(:);
transfer.subject_value = V;
transfer.subject_preference = P;
transfer.summary = struct( ...
    'top1_idx', int32(ord(1)), ...
    'top1_name', altNames(ord(1)), ...
    'top2_idx', int32(ord(2)), ...
    'top2_name', altNames(ord(2)), ...
    'head_gap', headGap, ...
    'score_range', scoreRange, ...
    'head_gap_ratio', ratio );

transfer.validation = local_validate_ranking(transfer.G, fuzzy_case);
transfer.baseline = local_make_baseline(B, U, fuzzy_case, altNames);
end

function baseline = local_make_baseline(B, U, fuzzy_case, altNames)
m = numel(altNames);
if isfield(fuzzy_case, 'baseline_score') && numel(fuzzy_case.baseline_score) == m
    score = double(fuzzy_case.baseline_score(:));
else
    score = mean(B - U, 1)';
end

[sortedScore, ord] = sort(score, 'descend');
if numel(sortedScore) >= 2
    headGap = sortedScore(1) - sortedScore(2);
else
    headGap = NaN;
end
scoreRange = max(score) - min(score);
if scoreRange <= 1e-12
    ratio = NaN;
else
    ratio = headGap / scoreRange;
end

baseline = struct();
baseline.G = score(:);
baseline.rank_order = ord(:);
baseline.rank_names = altNames(ord);
baseline.summary = struct( ...
    'top1_idx', int32(ord(1)), ...
    'top1_name', altNames(ord(1)), ...
    'top2_idx', int32(ord(min(2,numel(ord)))), ...
    'top2_name', altNames(ord(min(2,numel(ord)))), ...
    'head_gap', headGap, ...
    'score_range', scoreRange, ...
    'head_gap_ratio', ratio );
baseline.validation = local_validate_ranking(score, fuzzy_case);
end

function val = local_validate_ranking(scores, fuzzy_case)
val = struct();
val.available = false;
val.ground_truth_label = "";
val.spearman_rho = NaN;
val.ndcg_at_10pct = NaN;
val.ndcg_at_20pct = NaN;
val.top10pct_mean_truth = NaN;
val.bottom10pct_mean_truth = NaN;
val.n_alternatives = int32(numel(scores));

if ~isfield(fuzzy_case, 'ground_truth') || numel(fuzzy_case.ground_truth) ~= numel(scores)
    return;
end

y = double(fuzzy_case.ground_truth(:));
s = double(scores(:));
mask = isfinite(y) & isfinite(s);
y = y(mask);
s = s(mask);
if numel(y) < 3 || max(y) <= min(y) || max(s) <= min(s)
    return;
end

if isfield(fuzzy_case, 'ground_truth_label')
    val.ground_truth_label = string(fuzzy_case.ground_truth_label);
else
    val.ground_truth_label = "ground_truth";
end

val.available = true;
val.n_alternatives = int32(numel(y));
val.spearman_rho = local_spearman(s, y);
val.ndcg_at_10pct = local_ndcg_at_pct(s, y, 0.10);
val.ndcg_at_20pct = local_ndcg_at_pct(s, y, 0.20);

[~, ord] = sort(s, 'descend');
n = numel(y);
k10 = max(1, ceil(0.10*n));
val.top10pct_mean_truth = mean(y(ord(1:k10)));
val.bottom10pct_mean_truth = mean(y(ord((n-k10+1):n)));
end

function rho = local_spearman(x, y)
rx = local_tied_rank(x(:));
ry = local_tied_rank(y(:));
rho = local_pearson_corr(rx, ry);
end

function ndcg = local_ndcg_at_pct(scores, truth, pct)
n = numel(scores);
k = max(1, ceil(pct * n));
k = min(k, n);
rel = local_minmax01(truth(:));
[~, ord] = sort(scores(:), 'descend');
[~, idealOrd] = sort(rel(:), 'descend');
ndcg = local_dcg(rel(ord(1:k))) / max(local_dcg(rel(idealOrd(1:k))), eps);
end

function d = local_dcg(rel)
rel = double(rel(:));
pos = (1:numel(rel))';
d = sum((2.^rel - 1) ./ log2(pos + 1));
end

function r = local_tied_rank(x)
x = double(x(:));
r = NaN(size(x));
[sorted, idx] = sort(x);
n = numel(x);
i = 1;
while i <= n
    if ~isfinite(sorted(i))
        r(idx(i)) = NaN;
        i = i + 1;
        continue;
    end
    j = i;
    while j < n && sorted(j+1) == sorted(i)
        j = j + 1;
    end
    r(idx(i:j)) = (i + j) / 2;
    i = j + 1;
end
end

function y = local_minmax01(x)
x = double(x(:));
y = zeros(size(x));
mask = isfinite(x);
if ~any(mask)
    y(:) = 0.5;
    return;
end
lo = min(x(mask));
hi = max(x(mask));
if hi <= lo + eps
    y(:) = 0.5;
else
    y(mask) = (x(mask) - lo) ./ (hi - lo);
    y(~mask) = 0.5;
end
y = min(max(y, 0), 1);
end

function r = local_pearson_corr(x, y)
x = double(x(:));
y = double(y(:));
mask = isfinite(x) & isfinite(y);
x = x(mask);
y = y(mask);
if numel(x) < 3 || std(x) <= eps || std(y) <= eps
    r = NaN;
    return;
end
x = x - mean(x);
y = y - mean(y);
r = sum(x .* y) ./ sqrt(sum(x.^2) .* sum(y.^2));
end
