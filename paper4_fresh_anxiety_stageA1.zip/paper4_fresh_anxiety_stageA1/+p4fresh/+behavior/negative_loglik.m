function [nll, stats] = negative_loglik(theta, family, subjTrials, latentA, cfg)
pred = p4fresh.behavior.compute_trial_predictions(subjTrials, latentA, theta, family, cfg);

sample_obs = reshape([subjTrials.sample_obs], numel(subjTrials), 1);
choice_obs = reshape([subjTrials.choice_obs], numel(subjTrials), 1);
conf_obs = reshape([subjTrials.confidence_obs], numel(subjTrials), 1);

epsv = 1e-8;
pS = min(max(pred.sample_prob, epsv), 1-epsv);
ll_sample = sample_obs .* log(pS) + (1-sample_obs) .* log(1-pS);

pChoice = pred.choice_prob_safe;
pChoice(choice_obs==2) = pred.choice_prob_conflict(choice_obs==2);
pChoice = min(max(pChoice, epsv), 1-epsv);
ll_choice = log(pChoice);

sigma = cfg.model.conf_sigma;
ll_conf = -0.5*log(2*pi*sigma^2) - 0.5*((conf_obs - pred.conf_mean)./sigma).^2;

nll = -sum(ll_sample + ll_choice + ll_conf);

stats = struct();
stats.pred = pred;
stats.mean_choice_accuracy = mean((choice_obs == 1 & pred.choice_prob_safe >= 0.5) | (choice_obs == 2 & pred.choice_prob_conflict > 0.5));
stats.mean_sample_prob = mean(pred.sample_prob);
stats.sample_obs_rate = mean(sample_obs);
stats.mean_confidence_obs = mean(conf_obs);
stats.mean_confidence_pred = mean(pred.conf_mean);
end
