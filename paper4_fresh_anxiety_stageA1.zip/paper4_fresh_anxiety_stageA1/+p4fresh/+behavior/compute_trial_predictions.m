function pred = compute_trial_predictions(subjTrials, latentA, theta, family, cfg)
%#ok<INUSD>
nT = numel(subjTrials);
A = latentA(:);
P = p4fresh.mapping.apply_mapping_family(A, theta, family);

reward_signal = reshape([subjTrials.reward_signal], nT, 1);
punishment_signal = reshape([subjTrials.punishment_signal], nT, 1);
eiv = reshape([subjTrials.eiv], nT, 1);
uncertainty = reshape([subjTrials.uncertainty_level], nT, 1);

sample_logit = -0.1 + 1.3*eiv - 1.1*P.csub + 0.35*P.kappa - 0.25*P.alpha + 0.15*uncertainty;
sample_prob = p4fresh.utils.sigmoid(sample_logit);

vConflict = P.lambda .* reward_signal - (1-P.lambda).*punishment_signal + 0.15*P.alpha - 0.20*P.kappa;
vSafe = 0.65 .* reward_signal + 0.10 .* P.w;
pConflict = exp(P.beta .* vConflict) ./ (exp(P.beta .* vConflict) + exp(P.beta .* vSafe));
pSafe = 1 - pConflict;

gap = abs(vConflict - vSafe);
conf_mean = p4fresh.utils.sigmoid(-0.2 + 1.0*P.beta.*gap - 0.20*P.kappa + 0.10*sample_prob);

pred = struct();
pred.params = P;
pred.sample_prob = sample_prob;
pred.choice_prob_safe = pSafe;
pred.choice_prob_conflict = pConflict;
pred.conf_mean = conf_mean;
pred.v_safe = vSafe;
pred.v_conflict = vConflict;
pred.gap = gap;
end
