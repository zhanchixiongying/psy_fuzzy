function cfg = default_config()
cfg = struct();

cfg.random_seed = 20261001;

cfg.demo = struct();
cfg.demo.n_subjects = 12;
cfg.demo.trials_per_subject = 64;
cfg.demo.n_blocks = 4;

cfg.latent = struct();
cfg.latent.trait_weights = [0.40 0.30 0.20 0.10];
cfg.latent.state_weights = [0.45 0.15 0.20 0.10 0.10];
cfg.latent.rho0 = -0.10;
cfg.latent.rhoT = 1.10;
cfg.latent.rhoS = 0.90;
cfg.latent.subject_sd = 0.15;

cfg.model = struct();
cfg.model.families = {'linear','logistic','power','mspline'};
cfg.model.max_iter = 500;
cfg.model.max_fun_eval = 2000;
cfg.model.conf_sigma = 0.15;

% Display/reporting boundary bands. These are intentionally looser than the
% original demo defaults because the OpenNeuro real-data fit naturally
% produces heavier tails, especially for beta and near-zero regularizers.
cfg.boundary = struct();
cfg.boundary.lower01 = 0.01;
cfg.boundary.upper01 = 0.99;
cfg.boundary.lowerPos = 1e-3;
cfg.boundary.upperPos = 25.00;

% Diagnostic policy for real-data runs.
cfg.diagnostics = struct();
cfg.diagnostics.min_subjects_for_distribution_flags = 30;
cfg.diagnostics.low_accuracy_quantile = 0.10;
cfg.diagnostics.low_accuracy_absolute_ceiling = 0.40;
cfg.diagnostics.high_nll_quantile = 0.90;
cfg.diagnostics.extreme_sampling_lower_quantile = 0.02;
cfg.diagnostics.extreme_sampling_upper_quantile = 0.98;
cfg.diagnostics.min_sampling_spread_for_flag = 0.15;
cfg.diagnostics.min_total_flags_for_anomaly = 2;

% Stricter anomaly-only bounds so that a single near-boundary parameter does
% not automatically make a subject anomalous.
cfg.diagnostics.anomaly_boundary = struct();
cfg.diagnostics.anomaly_boundary.lower01 = 1e-3;
cfg.diagnostics.anomaly_boundary.upper01 = 0.999;
cfg.diagnostics.anomaly_boundary.lowerPos = 1e-6;
cfg.diagnostics.anomaly_boundary.upperPos = 30.00;
cfg.diagnostics.anomaly_boundary.min_breaches_for_flag = 2;

% Summary-level warning: count a parameter as a warning only when a material
% fraction of subjects are near a display/report boundary.
cfg.diagnostics.parameter_warning_rate_threshold = 0.20;

cfg.transfer = struct();
cfg.transfer.n_alternatives = 4;
cfg.transfer.n_criteria = 5;
cfg.transfer.names = ["Alt1","Alt2","Alt3","Alt4"];
cfg.transfer.criteria = ["C1","C2","C3","C4","C5"];
cfg.transfer.cost_idx = [4 5];
cfg.transfer.omega = [];

cfg.report = struct();
cfg.report.csv_dir = fullfile(pwd, 'paper4_fresh_stageA1_csv');
cfg.report.display_n = 12;

pkgRoot = fileparts(fileparts(mfilename('fullpath')));
dataDir = fullfile(pkgRoot, '+io', 'openneuro_ds000030');

cfg.openneuro = struct();
cfg.openneuro.enabled = true;
cfg.openneuro.dataset_id = "ds000030";
cfg.openneuro.task = "bart";
cfg.openneuro.source_label = "OpenNeuro ds000030 BART episode-level hazard mapping";
cfg.openneuro.data_dir = dataDir;
cfg.openneuro.event_pattern = 'sub-*_task-bart_events.tsv';
cfg.openneuro.exclude_control_trials = true;
cfg.openneuro.exclude_incomplete_episodes = true;
cfg.openneuro.min_trials_per_subject = 5;
cfg.openneuro.n_blocks = 4;
cfg.openneuro.sample_rule = "subject_median_pumps";
cfg.openneuro.confidence_proxy = "inverse_terminal_rt";
cfg.openneuro.min_pumps_for_sample = 2;
cfg.openneuro.max_successful_pumps = 12;
cfg.openneuro.default_pump_gain = 5;
cfg.openneuro.hazard_prior_alpha = 1.0;
cfg.openneuro.hazard_prior_beta = 1.0;

cfg.openneuro.auto_fetch_missing_events = true;
cfg.openneuro.auto_fetch_limit = inf;
cfg.openneuro.auto_fetch_if_fewer_than = 10;
cfg.openneuro.github_raw_base = 'https://raw.githubusercontent.com/OpenNeuroDatasets/ds000030/master';

cfg.openneuro.files = struct();
cfg.openneuro.files.demographics = 'demographics.tsv';
cfg.openneuro.files.barratt = 'barratt.tsv';
cfg.openneuro.files.mpq = 'mpq.tsv';
cfg.openneuro.files.eysenck = 'eysenck.tsv';
cfg.openneuro.files.tci = 'tci.tsv';
cfg.openneuro.files.bart = 'bart_phenotype.tsv';
end
