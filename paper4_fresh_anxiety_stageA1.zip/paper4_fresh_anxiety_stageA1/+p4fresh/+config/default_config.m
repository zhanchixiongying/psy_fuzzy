function cfg = default_config()
%DEFAULT_CONFIG APF-DS-XAI v8 leak-free profile-level risk communication config.
%
% v8 principle:
%   This is a profile-level financial risk communication decision-support
%   framework, not a pure ranking-performance model.
%
% Main outputs:
%   G_base            : financial risk baseline, B - U; main risk-truth validation.
%   G_PT_mean         : degeneration sanity check; expected to equal G_base.
%   D_PT, Pol_PT      : high-low anxiety prospect-theory mechanism contrast.
%   G_support         : anxiety-sensitive safety/support score.
%   G_info            : information/explanation-need score.
%   G_mechanism_load  : label-free anxiety divergence/polarization burden.
%   G_communication_burden : label-free information/mechanism communication burden.
%   DeployableAction  : leak-free multi-label communication action.
%   DeployableExplanation : truth-free XAI table for DSS/expert review.
%   AuditFlag         : post-hoc audit using truth variance/residuals only after validation.
%
% Hard rule:
%   DeployableAction must not use ground_truth, truth_mean, truth_var, residuals,
%   future outcomes, or expert disagreement. Those are allowed only in audit.

cfg = struct();
cfg.random_seed = 20261001;

pkgRoot = fileparts(fileparts(mfilename('fullpath')));

cfg.psych = struct();
cfg.psych.dataset_id = "ferrari2025_gad7_prior";
cfg.psych.source_label = "Ferrari et al. 2025 GAD-7/STAI prospect-theory matrix";
cfg.psych.data_file = fullfile(pkgRoot, '+io', 'Charpentier', 'data_anx_gad7_prior.csv');
cfg.psych.min_valid_subjects = 30;

cfg.financial_fuzzy = struct();
cfg.financial_fuzzy.data_dir = fullfile(pkgRoot, '+io', 'public_fuzzy_data');
cfg.financial_fuzzy.max_alternatives_per_case = inf;
cfg.financial_fuzzy.profile_precision = 3;

cfg.transfer = struct();
cfg.transfer.model_mode = "apf_ds_xai_v8";
% Valid primary scores:
%   "base"              -> G_base, main risk-truth validation score
%   "pt_mean" / "pt"    -> G_PT_mean, sanity check only
%   "support"           -> G_support, safety/support interpretation
%   "information_need"  -> G_info, information/action signal
%   "action_priority"   -> leak-free deployable action priority mapped to alternatives
%   "communication_burden" -> label-free mechanism/information communication-burden diagnostic
%   "mechanism_load"     -> label-free D/Pol mechanism visibility diagnostic
cfg.transfer.primary_score = "base";
cfg.transfer.omega = [];

% Fixed scale constants. Do not tune with FINRA/SCF/SHED truth.
cfg.transfer.scales = struct();
cfg.transfer.scales.s_tau = 0.50;
cfg.transfer.scales.s_ell = 0.50;
cfg.transfer.scales.s_beta = 0.50;
cfg.transfer.scales.s_kappa = 0.30;
cfg.transfer.scales.s_chi = 0.30;
cfg.transfer.scales.s_phi = 0.30;
cfg.transfer.scales.min_multiplier = 0.25;
cfg.transfer.scales.max_multiplier = 4.00;

% Fixed support-layer theoretical penalties.
cfg.transfer.support_weights = struct();
cfg.transfer.support_weights.w_K = 0.30;
cfg.transfer.support_weights.w_C = 0.30;
cfg.transfer.support_weights.w_F = 0.30;
cfg.transfer.support_weights.w_W = 0.50;

% Conservative worst-case sensitivity proxy.
% Ferrari has no direct PSWQ/IUS/Catastrophizing measure.
cfg.transfer.gamma = struct();
cfg.transfer.gamma.g0 = -1.35;
cfg.transfer.gamma.g_psi = 0.35;
cfg.transfer.gamma.g_ra = 0.15;
cfg.transfer.gamma.g_la = 0.20;
cfg.transfer.gamma.g_cp = 0.15;
cfg.transfer.gamma.min_gamma = 0.02;
cfg.transfer.gamma.max_gamma = 0.65;

% Tail-risk proxy layer.
cfg.transfer.tail = struct();
cfg.transfer.tail.eta_max = 0.65;


% Mechanism-load score. This is a communication-burden diagnostic, not a
% financial risk-willingness score and not a supervised expert-label score.
cfg.transfer.mechanism_load_weights = struct();
cfg.transfer.mechanism_load_weights.pt_divergence = 0.25;
cfg.transfer.mechanism_load_weights.pt_polarization = 0.20;
cfg.transfer.mechanism_load_weights.support_divergence = 0.30;
cfg.transfer.mechanism_load_weights.support_polarization = 0.25;

% Information-need score. Diagnostic/action signal, not risk willingness.
cfg.transfer.info = struct();
cfg.transfer.info.k0 = -0.50;
cfg.transfer.info.k_K = 1.00;
cfg.transfer.info.k_C = 0.90;
cfg.transfer.info.k_F = 0.90;
cfg.transfer.info.k_W = 1.20;

% Leak-free deployable action-policy.
cfg.action = struct();
cfg.action.high_pct = 0.75;
cfg.action.low_pct = 0.25;
cfg.action.flag_threshold_pct = 0.75;
cfg.action.capacity_threshold_pct = 0.75;
cfg.action.min_profile_n_for_audit = 2;
cfg.action.audit_residual_pct = 0.75;
cfg.action.score_weights = struct();
cfg.action.score_weights.info = [0.45 0.25 0.15 0.15]; % [G_info_core, K, C, positive G_info_resid]
cfg.action.score_weights.anxiety = [0.35 0.25 0.15 0.25];    % [|D_support|, Pol_support, |D_PT|, G_mechanism_load]
cfg.action.score_weights.communication_burden = [0.40 0.40 0.20]; % [G_info_core, G_mechanism_load, max(K,C,F,W_tail)]
cfg.action.score_weights.resilience = [0.45 0.45 0.10]; % [F, Wtail, -G_base]
cfg.action.score_weights.guardrail = [0.50 0.50];       % [G_base, max(F,Wtail)]
cfg.action.score_weights.capacity = [0.40 0.20 0.20 0.20]; % [G_base, 1-G_info, 1-F, 1-Wtail]

% Unsupervised residualized information settings. No ground truth is used.
cfg.info_resid = struct();
cfg.info_resid.folds = 5;
cfg.info_resid.ridge = 1e-6;

% Cross-fitted audit calibration settings. Used only in audit, never in deployable actions.
cfg.audit = struct();
cfg.audit.calibration_folds = 5;
cfg.audit.min_train_profiles = 20;
cfg.audit.residual_pct = 0.75;

% Optional bootstrap. For large surveys, default off.
cfg.bootstrap = struct();
cfg.bootstrap.enabled = false; % keep off by default for large public surveys; use eval/run_profile_bootstrap_ci.m for profile replicate-weight CI
cfg.bootstrap.n_reps = 200;
cfg.bootstrap.seed = 20261001;
cfg.bootstrap.level = 0.95;

% Comparison, ablation, and action-level evaluation settings.
cfg.experiment = struct();
cfg.experiment.run_comparisons = true;
cfg.experiment.run_ablation = true;
cfg.experiment.run_action_ablation = true;
cfg.experiment.vikor_v = 0.50;

cfg.report = struct();
cfg.report.csv_dir = fullfile(pwd, 'paper4_apfds_xai_v8_csv');
cfg.report.top_n = 10;             % diagnostic only
cfg.report.profile_top_n = 20;     % preferred display
end
