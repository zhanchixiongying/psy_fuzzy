function safe_table_write(T, filepath)
folder = fileparts(filepath);
if ~isempty(folder) && ~exist(folder,'dir')
    mkdir(folder);
end
writetable(T, filepath);
end
