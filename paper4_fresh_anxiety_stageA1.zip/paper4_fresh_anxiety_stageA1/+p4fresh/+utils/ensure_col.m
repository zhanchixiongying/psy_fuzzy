function x = ensure_col(x)
if isempty(x)
    x = zeros(0,1);
else
    x = x(:);
end
end
