function y = softplus(x)
y = log1p(exp(-abs(x))) + max(x,0);
end
