function print_table_head(T, n, titleStr)
if nargin < 2 || isempty(n)
    n = min(10, height(T));
end
if nargin >= 3 && ~isempty(titleStr)
    fprintf('\n--- %s ---\n', titleStr);
end
if isempty(T) || height(T)==0
    fprintf('[empty table]\n');
    return;
end
disp(T(1:min(n,height(T)), :));
end
