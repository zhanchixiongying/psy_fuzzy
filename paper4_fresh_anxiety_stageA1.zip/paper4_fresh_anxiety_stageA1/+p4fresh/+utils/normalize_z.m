function z = normalize_z(x)
x = double(x(:));
mu = mean(x,'omitnan');
sd = std(x,0,'omitnan');
if isnan(sd) || sd <= 1e-12
    z = zeros(size(x));
else
    z = (x - mu) ./ sd;
end
end
