function arr = safe_struct_assign(arr, idx, value, template)
if nargin < 4
    error('safe_struct_assign requires arr, idx, value, and template.');
end
if isempty(arr)
    arr = repmat(template, idx, 1);
elseif numel(arr) < idx
    arr(end+1:idx,1) = repmat(template, idx-numel(arr), 1);
end
if ~isequal(sort(fieldnames(value)), sort(fieldnames(template)))
    error('Struct assignment failed: field mismatch between value and template.');
end
arr(idx,1) = value;
end
