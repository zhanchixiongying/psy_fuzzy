function subject_result = fit_subject(subject_struct, all_trials, cfg)
T = p4fresh.schema.templates();
famTemplate = T.family_result;
subjTemplate = T.subject_result;

idx = double(subject_struct.trial_indices);
subjTrials = all_trials(idx);
latentA = reshape([subjTrials.latent_total], numel(subjTrials), 1);

families = cfg.model.families;
famResults = repmat(famTemplate, numel(families), 1);

for f = 1:numel(families)
    fam = string(families{f});
    theta0 = p4fresh.mapping.init_theta(fam);
    objfun = @(th) p4fresh.behavior.negative_loglik(th, fam, subjTrials, latentA, cfg);
    opts = optimset('Display','off','MaxIter',cfg.model.max_iter,'MaxFunEvals',cfg.model.max_fun_eval);
    [theta_hat, fval, exitflag] = fminsearch(@(th) objfun(th), theta0, opts);
    [nll, stats] = p4fresh.behavior.negative_loglik(theta_hat, fam, subjTrials, latentA, cfg);
    k = numel(theta_hat);
    n = numel(subjTrials) * 3;
    aic = 2*k + 2*nll;
    bic = log(max(n,1))*k + 2*nll;

    fr = famTemplate;
    fr.family = fam;
    fr.params = stats.pred.params;
    fr.theta_vec = theta_hat(:);
    fr.exitflag = int32(exitflag);
    fr.objective = fval;
    fr.nll = nll;
    fr.aic = aic;
    fr.bic = bic;
    fr.behavior_summary = struct( ...
        'choice_accuracy', stats.mean_choice_accuracy, ...
        'sample_obs_rate', stats.sample_obs_rate, ...
        'mean_sample_prob', stats.mean_sample_prob, ...
        'mean_confidence_obs', stats.mean_confidence_obs, ...
        'mean_confidence_pred', stats.mean_confidence_pred, ...
        'mean_alpha', mean(stats.pred.params.alpha), ...
        'mean_kappa', mean(stats.pred.params.kappa), ...
        'mean_csub', mean(stats.pred.params.csub), ...
        'mean_lambda', mean(stats.pred.params.lambda), ...
        'mean_beta', mean(stats.pred.params.beta), ...
        'mean_w', mean(stats.pred.params.w));
    famResults(f,1) = fr;
end

[~, ord] = sort([famResults.nll], 'ascend');
famResults = famResults(ord);
best = famResults(1);

subject_result = subjTemplate;
subject_result.subject_idx = subject_struct.subject_idx;
subject_result.subject_id = subject_struct.subject_id;
subject_result.best_family = best.family;
subject_result.best_rank = int32(1);
subject_result.family_results = famResults;
subject_result.best_result = best;
subject_result.behavior_summary = best.behavior_summary;
subject_result.latent_summary = struct( ...
    'latent_trait', subject_struct.latent_trait, ...
    'latent_state_mean', subject_struct.latent_state_mean, ...
    'latent_total_mean', subject_struct.latent_total_mean);
end
