function caseA = fit_dataset(dataset, cfg)
%FIT_DATASET Build APF-DS-XAI v8 psychological parameter table from Ferrari data.
%
% No raw-trial refitting is performed. The Ferrari matrix already contains
% subject-level prospect-theory parameters rho, lambda, and mu.
%
% v8 parameter layer:
%   tau   = risk-tolerance multiplier from RA=-log(rho)
%   ell   = loss-sensitivity multiplier from LA=log(lambda)
%   beta  = choice-precision multiplier from CP=log(mu)
%   kappa = low-clarity sensitivity from anxiety profile Psi
%   chi   = change/shock sensitivity from Psi
%   phi   = fragility sensitivity from Psi
%   gamma = conservative worst-case/tail-risk sensitivity proxy

if nargin < 2 || isempty(cfg)
    cfg = p4fresh.config.default_config();
end
if ~isfield(dataset,'meta') || ~dataset.meta.has_prefit_behavior_params
    error('fit_dataset:UnsupportedDataset', 'Ferrari subject-level prospect parameters are required.');
end

subjects = dataset.subjects;
n = numel(subjects);

rho = NaN(n,1); lambdaLoss = NaN(n,1); mu = NaN(n,1);
gad7 = NaN(n,1); state = NaN(n,1); trait = NaN(n,1); psi = NaN(n,1);
highAnx = false(n,1); pgamble = NaN(n,1);
for i = 1:n
    rho(i) = subjects(i).rho;
    lambdaLoss(i) = subjects(i).lambda_loss;
    mu(i) = subjects(i).mu;
    gad7(i) = subjects(i).gad7;
    state(i) = subjects(i).state_anx;
    trait(i) = subjects(i).trait_anx;
    psi(i) = subjects(i).latent_anxiety;
    highAnx(i) = subjects(i).high_anxiety;
    pgamble(i) = subjects(i).p_gamble;
end

RA = -log(max(rho, eps));
LA = log(max(lambdaLoss, eps));
CP = log(max(mu, eps));

zRA = local_zscore(RA);
zLA = local_zscore(LA);
zCP = local_zscore(CP);
psi = local_zscore(psi);

sc = cfg.transfer.scales;
gc = cfg.transfer.gamma;

tau = local_normalize_multiplier(exp(-sc.s_tau .* zRA), sc);
ell = local_normalize_multiplier(exp( sc.s_ell .* zLA), sc);
beta = local_normalize_multiplier(exp(sc.s_beta .* zCP), sc);
kappa = local_normalize_multiplier(exp(sc.s_kappa .* psi), sc);
chi = local_normalize_multiplier(exp(sc.s_chi .* psi), sc);
phi = local_normalize_multiplier(exp(sc.s_phi .* psi), sc);

gammaLogit = gc.g0 + gc.g_psi .* psi + gc.g_ra .* zRA + gc.g_la .* zLA - gc.g_cp .* zCP;
gamma = local_clip(local_sigmoid(gammaLogit), gc.min_gamma, gc.max_gamma);

subject_results = repmat(local_empty_subject_result(), n, 1);
for i = 1:n
    bs = struct();
    bs.risk_tolerance = tau(i);
    bs.loss_sensitivity = ell(i);
    bs.choice_precision = beta(i);
    bs.low_clarity_sensitivity = kappa(i);
    bs.change_sensitivity = chi(i);
    bs.fragility_sensitivity = phi(i);
    bs.worst_case_sensitivity = gamma(i);

    bs.rho = rho(i);
    bs.lambda_loss = lambdaLoss(i);
    bs.mu = mu(i);
    bs.RA = RA(i);
    bs.LA = LA(i);
    bs.CP = CP(i);
    bs.gad7 = gad7(i);
    bs.state_anx = state(i);
    bs.trait_anx = trait(i);
    bs.latent_anxiety = psi(i);
    bs.high_anxiety = highAnx(i);
    bs.p_gamble = pgamble(i);


    br = struct();
    br.family = "ferrari2025_apf_ds_xai_v8_prefit";
    br.theta = [tau(i), ell(i), beta(i), kappa(i), chi(i), phi(i), gamma(i)];
    br.behavior_summary = bs;
    br.metrics = struct('nll', NaN, 'choice_accuracy', NaN, ...
        'sample_prob', pgamble(i), ...
        'note', "Ferrari subject-level parameters; no raw-trial refitting.");

    sr = local_empty_subject_result();
    sr.subject_idx = int32(i);
    sr.subject_id = subjects(i).subject_id;
    sr.best_family = br.family;
    sr.best_rank = int32(1);
    sr.best_result = br;
    sr.behavior_summary = bs;
    sr.latent_summary = struct('latent_total_mean', psi(i), 'high_anxiety', highAnx(i));
    subject_results(i) = sr;
end

parameter_table = table();
parameter_table.subject_idx = int32((1:n)');
parameter_table.subject_id = string({subjects.subject_id}');
parameter_table.gad7 = gad7;
parameter_table.state_anx = state;
parameter_table.trait_anx = trait;
parameter_table.psi_anxiety = psi;
parameter_table.high_anxiety = highAnx;
parameter_table.rho = rho;
parameter_table.lambda_loss = lambdaLoss;
parameter_table.mu = mu;
parameter_table.RA = RA;
parameter_table.LA = LA;
parameter_table.CP = CP;
parameter_table.risk_tolerance = tau;
parameter_table.loss_sensitivity = ell;
parameter_table.choice_precision = beta;
parameter_table.low_clarity_sensitivity = kappa;
parameter_table.change_sensitivity = chi;
parameter_table.fragility_sensitivity = phi;
parameter_table.worst_case_sensitivity = gamma;
parameter_table.p_gamble = pgamble;

caseA = struct();
caseA.dataset_source = dataset.meta.source;
caseA.dataset_source_type = dataset.meta.source_type;
caseA.subject_results = subject_results;
caseA.parameter_table = parameter_table;
caseA.summary = struct();
caseA.summary.best_family = "ferrari2025_apf_ds_xai_v8_prefit";
caseA.summary.n_subjects = n;
caseA.summary.n_trials = dataset.meta.n_trials;
caseA.summary.mean_risk_tolerance = mean(tau,'omitnan');
caseA.summary.mean_loss_sensitivity = mean(ell,'omitnan');
caseA.summary.mean_choice_precision = mean(beta,'omitnan');
caseA.summary.mean_low_clarity_sensitivity = mean(kappa,'omitnan');
caseA.summary.mean_change_sensitivity = mean(chi,'omitnan');
caseA.summary.mean_fragility_sensitivity = mean(phi,'omitnan');
caseA.summary.mean_worst_case_sensitivity = mean(gamma,'omitnan');
caseA.summary.mean_sample_prob = mean(pgamble,'omitnan');
end

function s = local_empty_subject_result()
s = struct();
s.subject_idx = int32(0);
s.subject_id = '';
s.best_family = "";
s.best_rank = int32(0);
s.best_result = struct();
s.behavior_summary = struct();
s.latent_summary = struct();
end

function z = local_zscore(x)
x = double(x(:));
mu = mean(x,'omitnan');
sd = std(x,'omitnan');
if ~isfinite(sd) || sd < 1e-12
    z = zeros(size(x));
else
    z = (x - mu)./sd;
end
z(~isfinite(z)) = 0;
end

function y = local_sigmoid(x)
x = max(min(double(x), 30), -30);
y = 1 ./ (1 + exp(-x));
end

function x = local_clip(x, lo, hi)
x = min(max(double(x), lo), hi);
end

function m = local_normalize_multiplier(m, sc)
m = double(m(:));
m(~isfinite(m)) = 1;
m = m ./ max(mean(m,'omitnan'), eps);
m = local_clip(m, sc.min_multiplier, sc.max_multiplier);
m = m ./ max(mean(m,'omitnan'), eps);
end
