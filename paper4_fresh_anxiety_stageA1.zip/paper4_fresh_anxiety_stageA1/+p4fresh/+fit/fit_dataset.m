function caseA = fit_dataset(dataset, cfg)
T = p4fresh.schema.templates();
subjResTemplate = T.subject_result;
subjects = dataset.subjects;
trials = dataset.trials;

subject_results = repmat(subjResTemplate, numel(subjects), 1);
for s = 1:numel(subjects)
    subject_results(s,1) = p4fresh.fit.fit_subject(subjects(s), trials, cfg);
end

fams = string(cfg.model.families(:));
winCounts = zeros(numel(fams),1);
meanNLL = zeros(numel(fams),1); %#ok<NASGU>
for f = 1:numel(fams)
    fam = fams(f);
    vals = nan(numel(subject_results),1);
    for s = 1:numel(subject_results)
        fr = subject_results(s).family_results;
        idx = find(string({fr.family})' == fam, 1);
        vals(s) = fr(idx).nll;
        if string(subject_results(s).best_family) == fam
            winCounts(f) = winCounts(f) + 1;
        end
    end
    meanNLL(f) = mean(vals);
end
[~, bestIdx] = max(winCounts);

summary = struct();
summary.best_family = fams(bestIdx);
summary.mean_choice_accuracy = mean(arrayfun(@(x) x.behavior_summary.choice_accuracy, subject_results));
summary.mean_sample_prob = mean(arrayfun(@(x) x.behavior_summary.mean_sample_prob, subject_results));

caseA = struct();
caseA.meta = dataset.meta;
caseA.subject_results = subject_results;
caseA.summary = summary;
caseA.indexing = p4fresh.schema.indexing_convention();
end
