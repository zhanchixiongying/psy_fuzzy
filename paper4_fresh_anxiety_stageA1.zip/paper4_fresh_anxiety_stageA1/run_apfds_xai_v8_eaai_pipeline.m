function results = run_apfds_xai_v8_eaai_pipeline(out, labelDir, outputDir, maxProfiles, nBoot, seed)
%RUN_APFDS_XAI_V8_EAAI_PIPELINE One-click APF-DS-XAI v8 final-guideline evaluation.
%
% This version uses the v2 strict-blind label file as the primary gold label:
%   expert_labels/APFDS_XAI_v8_train_ready_600_final_guideline_v2_strict_blind_visible.csv
%
% Why this file first?
%   It contains expert labels, reason codes, splits, and profile evidence,
%   but excludes model primary actions, model rationales, and S_* action
%   scores. It is therefore the cleanest gold-label file for blind action
%   evaluation. The v2 leakfree file is accepted only as fallback/diagnostic.
%
% The pipeline runs:
%   1) validate_v8_structure
%   2) profile bootstrap CI
%   3) expert-label evaluation
%   4) action ablation against labels
%   5) supervised action-imitation baseline
%   6) global 600-row baseline and annotation-quality summary

if nargin < 1 || isempty(out)
    fprintf('\n[1/6] Running run_paper4_fresh_demo() ...\n');
    out = run_paper4_fresh_demo();
else
    fprintf('\n[1/6] Using provided out struct.\n');
end
if nargin < 2 || isempty(labelDir), labelDir = fullfile(pwd, 'expert_labels'); end
if nargin < 3 || isempty(outputDir), outputDir = fullfile(pwd, 'paper4_apfds_xai_v8_eaai_outputs'); end
if nargin < 4 || isempty(maxProfiles), maxProfiles = 200; end
if nargin < 5 || isempty(nBoot), nBoot = 500; end
if nargin < 6 || isempty(seed), seed = 20261001; end

if ~exist(labelDir,'dir'), mkdir(labelDir); end
if ~exist(outputDir,'dir'), mkdir(outputDir); end

labelFile = local_find_global_label_file(labelDir);

results = struct();
results.out = out;
results.output_dir = string(outputDir);
results.label_dir = string(labelDir);
results.label_file = string(labelFile);
results.max_profiles = maxProfiles;
results.n_bootstrap = nBoot;
results.seed = seed;

fprintf('\nOutput directory:\n  %s\n', outputDir);
fprintf('Expert-label directory:\n  %s\n', labelDir);
if strlength(string(labelFile)) > 0
    fprintf('Using label file:\n  %s\n', labelFile);
else
    fprintf('No filled expert-label file found. Templates will be exported only.\n');
end

fprintf('\n[2/6] Running p4fresh.eval.validate_v8_structure(out) ...\n');
try
    Tstruct = p4fresh.eval.validate_v8_structure(out);
    results.validate_v8_structure = Tstruct;
    writetable(Tstruct, fullfile(outputDir, 'validate_v8_structure.csv'));
    disp(Tstruct);
catch ME
    warning('validate_v8_structure failed: %s', ME.message);
    results.validate_v8_structure_error = string(ME.message);
end

if strlength(string(labelFile)) > 0
    try
        qdir = fullfile(outputDir, 'combined_label_quality');
        if ~exist(qdir,'dir'), mkdir(qdir); end
        results.combined_label_quality = p4fresh.eval.summarize_expert_annotation_quality(labelFile, qdir);
    catch ME
        warning('summarize_expert_annotation_quality failed: %s', ME.message);
        results.combined_label_quality_error = string(ME.message);
    end
end

nCases = numel(out.transfers);
caseResults = cell(nCases,1);
summaryRows = repmat(local_empty_summary_row(), nCases, 1);
allActionTables = cell(nCases,1);

for c = 1:nCases
    tr = out.transfers{c};
    fc = out.fuzzy_cases(c);
    caseId = string(fc.case_id);
    safeCaseId = local_safe_filename(caseId);
    caseDir = fullfile(outputDir, char(safeCaseId));
    if ~exist(caseDir,'dir'), mkdir(caseDir); end

    fprintf('\n================ CASE %d/%d: %s ================\n', c, nCases, caseId);

    caseRes = struct();
    caseRes.case_id = caseId;
    caseRes.case_dir = string(caseDir);
    caseRes.n_alternatives = numel(fc.alternative_names);
    caseRes.n_profiles = numel(unique(string(fc.profile_id(:))));
    caseRes.deployable_action_leakage_free = local_get_sanity_bool(tr, 'deployable_action_leakage_free');
    caseRes.PT_mean_minus_base_max_abs = local_get_sanity_number(tr, 'PT_mean_minus_base_max_abs');
    caseRes.mean_mechanism_load = mean(tr.G_mechanism_load,'omitnan');
    caseRes.mean_communication_burden = mean(tr.G_communication_burden,'omitnan');

    fprintf('Alternatives: %d\n', caseRes.n_alternatives);
    fprintf('Profiles: %d\n', caseRes.n_profiles);
    fprintf('PT mean minus base max abs: %.6g\n', caseRes.PT_mean_minus_base_max_abs);
    fprintf('Deployable action leakage-free: %d\n', caseRes.deployable_action_leakage_free);

    % Persist core deployable/audit tables.
    local_write_if_table(tr, 'deployable_action_table', fullfile(caseDir, 'deployable_action_table.csv'));
    local_write_if_table(tr, 'audit_table', fullfile(caseDir, 'audit_table.csv'));
    local_write_if_table(tr, 'comparison_table', fullfile(caseDir, 'comparison_table.csv'));
    local_write_if_table(tr, 'ablation_table', fullfile(caseDir, 'risk_score_ablation_table.csv'));
    local_write_if_table(tr, 'action_ablation_table', fullfile(caseDir, 'unsupervised_action_ablation_table.csv'));
    local_write_if_table(tr, 'action_flag_rate_table', fullfile(caseDir, 'action_flag_rate_table.csv'));
    local_write_if_table(tr, 'action_cooccurrence_table', fullfile(caseDir, 'action_cooccurrence_table.csv'));
    local_write_if_table(tr, 'mechanism_visibility_table', fullfile(caseDir, 'mechanism_visibility_table.csv'));

    AT = tr.deployable_action_table;
    AT.case_id = repmat(caseId, height(AT), 1);
    allActionTables{c} = AT;

    fprintf('[3/6] Running profile bootstrap CI (%d reps) ...\n', nBoot);
    try
        bootT = p4fresh.eval.run_profile_bootstrap_ci(tr, fc, nBoot, seed);
        caseRes.bootstrap_ci = bootT;
        writetable(bootT, fullfile(caseDir, 'profile_bootstrap_ci.csv'));
    catch ME
        warning('Bootstrap failed for %s: %s', caseId, ME.message);
        caseRes.bootstrap_ci_error = string(ME.message);
    end

    fprintf('[4/6] Exporting strict blind template (%d profiles) ...\n', maxProfiles);
    try
        templateFile = fullfile(caseDir, char(safeCaseId + "_strict_blind_template.csv"));
        p4fresh.eval.export_human_eval_template(tr, templateFile, maxProfiles, "strict_blind");
        caseRes.human_eval_template_file = string(templateFile);
    catch ME
        warning('Template export failed for %s: %s', caseId, ME.message);
        caseRes.human_eval_template_error = string(ME.message);
    end

    if strlength(string(labelFile)) > 0
        fprintf('[5/6] Evaluating expert labels ...\n');
        try
            report = p4fresh.eval.validate_expert_annotation_file(labelFile, caseId);
            caseRes.label_validation_report = report;
            writetable(report.summary_table, fullfile(caseDir, 'expert_label_validation_summary.csv'));

            metrics = p4fresh.eval.evaluate_human_labels(tr.deployable_action_table, labelFile, caseId);
            caseRes.human_metrics = metrics;
            local_export_metrics(metrics, caseDir, 'human_label_metrics');
        catch ME
            warning('Expert-label evaluation failed for %s: %s', caseId, ME.message);
            caseRes.human_metrics_error = string(ME.message);
        end

        fprintf('[5/6] Running action ablation against expert labels ...\n');
        try
            abl = p4fresh.eval.run_action_ablation_against_labels(tr, labelFile, caseId);
            caseRes.action_ablation_against_labels = abl;
            writetable(abl, fullfile(caseDir, 'action_ablation_against_expert_labels.csv'));
        catch ME
            warning('Action ablation failed for %s: %s', caseId, ME.message);
            caseRes.action_ablation_error = string(ME.message);
        end

        fprintf('[6/6] Running supervised action-imitation baseline ...\n');
        try
            baseline = p4fresh.eval.fit_supervised_action_baseline(tr.deployable_action_table, labelFile, "treebagger", caseId);
            caseRes.supervised_action_baseline = baseline;
            save(fullfile(caseDir, 'supervised_action_baseline.mat'), 'baseline');
            local_export_baseline(baseline, caseDir);
        catch ME
            warning('Supervised baseline failed for %s: %s', caseId, ME.message);
            caseRes.supervised_baseline_error = string(ME.message);
        end
    else
        fprintf('[5/6] No label file found. Skipping label evaluation.\n');
        fprintf('[6/6] No label file found. Skipping supervised baseline.\n');
    end

    caseResults{c} = caseRes;
    summaryRows(c) = local_make_summary_row(caseRes);
    save(fullfile(caseDir, 'case_pipeline_result.mat'), 'caseRes');
end

summaryT = struct2table(summaryRows);
results.case_results = caseResults;
results.summary = summaryT;
writetable(summaryT, fullfile(outputDir, 'eaai_pipeline_summary.csv'));

if strlength(string(labelFile)) > 0
    fprintf('\n[6/6] Running global supervised 5-class baseline ...\n');
    try
        allAction = vertcat(allActionTables{:});
        gdir = fullfile(outputDir, 'global_supervised_5class_baseline');
        if ~exist(gdir,'dir'), mkdir(gdir); end
        globalBaseline = p4fresh.eval.fit_supervised_action_baseline(allAction, labelFile, "treebagger", "");
        results.global_supervised_5class_baseline = globalBaseline;
        save(fullfile(gdir, 'global_supervised_5class_baseline.mat'), 'globalBaseline');
        local_export_baseline(globalBaseline, gdir);
    catch ME
        warning('Global supervised baseline failed: %s', ME.message);
        results.global_supervised_5class_baseline_error = string(ME.message);
    end
end

save(fullfile(outputDir, 'eaai_pipeline_results.mat'), 'results');

fprintf('\n================ APF-DS-XAI v8 EAAI PIPELINE COMPLETE ================\n');
fprintf('Summary saved:\n  %s\n', fullfile(outputDir, 'eaai_pipeline_summary.csv'));
fprintf('Results saved:\n  %s\n', fullfile(outputDir, 'eaai_pipeline_results.mat'));
fprintf('======================================================================\n');
end

function labelFile = local_find_global_label_file(labelDir)
candidates = {
    fullfile(labelDir, 'APFDS_XAI_v8_train_ready_600_final_guideline_v2_strict_blind_visible.csv');
    fullfile(labelDir, 'APFDS_XAI_v8_train_ready_600_final_guideline_v2_leakfree.csv');
    fullfile(labelDir, 'APFDS_XAI_v8_train_ready_600_final_guideline_leakfree.csv');
    fullfile(labelDir, 'APFDS_XAI_v8_train_600_5class.csv');
    fullfile(labelDir, 'APFDS_XAI_v8_combined_expert_annotated_600.csv')
};
labelFile = "";
for i = 1:numel(candidates)
    if exist(candidates{i}, 'file') == 2 && local_is_ready_label_file(candidates{i})
        labelFile = string(candidates{i});
        return;
    end
end
end

function ok = local_is_ready_label_file(fp)
ok = false;
try
    L = readtable(fp, 'VariableNamingRule','preserve', 'TextType','string');
catch
    return;
end
names = string(L.Properties.VariableNames);
ok = ismember("profile_id", names) && ismember("expert_primary_action", names) && ...
    any(strlength(strtrim(string(L.expert_primary_action))) > 0);
end

function local_export_metrics(metrics, outDir, prefix)
if isfield(metrics,'summary_table'), writetable(metrics.summary_table, fullfile(outDir, prefix + "_summary.csv")); end
if isfield(metrics,'per_label_all5'), writetable(metrics.per_label_all5, fullfile(outDir, prefix + "_per_label_all5.csv")); end
if isfield(metrics,'per_label_observed'), writetable(metrics.per_label_observed, fullfile(outDir, prefix + "_per_label_observed.csv")); end
if isfield(metrics,'prediction_table'), writetable(metrics.prediction_table, fullfile(outDir, prefix + "_predictions.csv")); end
if isfield(metrics,'flag_metrics') && isstruct(metrics.flag_metrics) && isfield(metrics.flag_metrics,'per_flag')
    writetable(metrics.flag_metrics.per_flag, fullfile(outDir, prefix + "_per_flag.csv"));
end
if isfield(metrics,'rating_summary') && istable(metrics.rating_summary)
    writetable(metrics.rating_summary, fullfile(outDir, prefix + "_rating_summary.csv"));
end
end

function local_export_baseline(baseline, outDir)
if isfield(baseline,'summary_table'), writetable(baseline.summary_table, fullfile(outDir, 'supervised_action_baseline_summary.csv')); end
if isfield(baseline,'prediction_table'), writetable(baseline.prediction_table, fullfile(outDir, 'supervised_action_baseline_predictions.csv')); end
if isfield(baseline,'test_metrics') && isstruct(baseline.test_metrics)
    if isfield(baseline.test_metrics,'per_label_all5'), writetable(baseline.test_metrics.per_label_all5, fullfile(outDir, 'supervised_action_baseline_test_per_label_all5.csv')); end
end
end

function local_write_if_table(S, fieldName, filePath)
if isstruct(S) && isfield(S, fieldName) && istable(S.(fieldName))
    writetable(S.(fieldName), filePath);
end
end

function row = local_empty_summary_row()
row = struct();
row.case_id = "";
row.n_alternatives = NaN;
row.n_profiles = NaN;
row.deployable_action_leakage_free = false;
row.PT_mean_minus_base_max_abs = NaN;
row.mean_mechanism_load = NaN;
row.mean_communication_burden = NaN;
row.bootstrap_done = false;
row.human_metrics_done = false;
row.human_accuracy = NaN;
row.human_macro_f1_5labels = NaN;
row.human_weighted_f1 = NaN;
row.human_flag_jaccard = NaN;
row.action_ablation_done = false;
row.supervised_baseline_done = false;
row.supervised_test_macro_f1_5labels = NaN;
row.supervised_test_weighted_f1 = NaN;
row.case_dir = "";
end

function row = local_make_summary_row(caseRes)
row = local_empty_summary_row();
row.case_id = string(caseRes.case_id);
row.n_alternatives = caseRes.n_alternatives;
row.n_profiles = caseRes.n_profiles;
row.deployable_action_leakage_free = caseRes.deployable_action_leakage_free;
row.PT_mean_minus_base_max_abs = caseRes.PT_mean_minus_base_max_abs;
if isfield(caseRes,'mean_mechanism_load'), row.mean_mechanism_load = caseRes.mean_mechanism_load; end
if isfield(caseRes,'mean_communication_burden'), row.mean_communication_burden = caseRes.mean_communication_burden; end
row.case_dir = string(caseRes.case_dir);
row.bootstrap_done = isfield(caseRes,'bootstrap_ci') && istable(caseRes.bootstrap_ci);
if isfield(caseRes,'human_metrics')
    row.human_metrics_done = true;
    row.human_accuracy = caseRes.human_metrics.accuracy;
    row.human_macro_f1_5labels = caseRes.human_metrics.macro_f1_5labels;
    row.human_weighted_f1 = caseRes.human_metrics.weighted_f1;
    row.human_flag_jaccard = caseRes.human_metrics.flag_metrics.mean_jaccard;
end
row.action_ablation_done = isfield(caseRes,'action_ablation_against_labels') && istable(caseRes.action_ablation_against_labels);
if isfield(caseRes,'supervised_action_baseline')
    row.supervised_baseline_done = true;
    b = caseRes.supervised_action_baseline;
    if isfield(b,'test_metrics') && isfield(b.test_metrics,'macro_f1_5labels')
        row.supervised_test_macro_f1_5labels = b.test_metrics.macro_f1_5labels;
        row.supervised_test_weighted_f1 = b.test_metrics.weighted_f1;
    end
end
end

function v = local_get_sanity_bool(tr, fieldName)
v = false;
if isfield(tr,'sanity') && isstruct(tr.sanity) && isfield(tr.sanity, fieldName)
    v = logical(tr.sanity.(fieldName));
end
end

function v = local_get_sanity_number(tr, fieldName)
v = NaN;
if isfield(tr,'sanity') && isstruct(tr.sanity) && isfield(tr.sanity, fieldName)
    v = double(tr.sanity.(fieldName));
end
end

function safe = local_safe_filename(s)
safe = regexprep(string(s), '[^A-Za-z0-9_\-]', '_');
safe = regexprep(safe, '_+', '_');
end
