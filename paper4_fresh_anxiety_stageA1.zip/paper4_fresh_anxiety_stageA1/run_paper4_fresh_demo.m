function out = run_paper4_fresh_demo()
%RUN_PAPER4_FRESH_DEMO APF-DS-XAI v8 Ferrari 2025 + FINRA/SCF/SHED pipeline.

cfg = p4fresh.config.default_config();

fprintf('\n================ APF-DS-XAI v8 LEAK-FREE DEMO (%s + Public Fuzzy) ================\n', string(cfg.psych.dataset_id));

dataset = p4fresh.io.build_demo_dataset(cfg);
dataset = p4fresh.latent.build_latent_anxiety(dataset, cfg);
caseA = p4fresh.fit.fit_dataset(dataset, cfg);

fprintf('Psychological data source: %s\n', string(dataset.meta.source));
fprintf('Subjects: %d\n', dataset.meta.n_subjects);
fprintf('Summary rows: %d\n', dataset.meta.n_trials);
fprintf('Model family: %s\n', string(caseA.summary.best_family));
fprintf('Mean risk tolerance tau: %.4f\n', caseA.summary.mean_risk_tolerance);
fprintf('Mean loss sensitivity ell: %.4f\n', caseA.summary.mean_loss_sensitivity);
fprintf('Mean choice precision beta: %.4f\n', caseA.summary.mean_choice_precision);
fprintf('Mean low-clarity sensitivity kappa: %.4f\n', caseA.summary.mean_low_clarity_sensitivity);
fprintf('Mean fragility sensitivity phi: %.4f\n', caseA.summary.mean_fragility_sensitivity);
fprintf('Mean worst-case sensitivity gamma: %.4f\n', caseA.summary.mean_worst_case_sensitivity);
fprintf('Mean p(gamble): %.4f\n', caseA.summary.mean_sample_prob);

fuzzy_cases = p4fresh.io.build_demo_fuzzy_case(dataset.subjects, cfg, dataset.trial_table);
nCases = numel(fuzzy_cases);
transfers = cell(nCases,1);
diagnostics_all = cell(nCases,1);
summary_rows = repmat(local_empty_summary_row(), nCases, 1);

for c = 1:nCases
    fc = fuzzy_cases(c);
    fprintf('\n---------------- PUBLIC FUZZY CASE %d/%d ----------------\n', c, nCases);
    fprintf('Case ID: %s\n', string(fc.case_id));
    fprintf('Source: %s\n', string(fc.source_name));
    fprintf('Task: %s\n', string(fc.task_label));
    fprintf('Alternatives: %d\n', numel(fc.alternative_names));
    if isfield(fc,'profile_id'), fprintf('Profiles: %d\n', numel(unique(fc.profile_id))); end

    tr = p4fresh.fuzzy.run_transfer(caseA, fc, cfg);
    diagnostics = p4fresh.reports.run_stageA1_diagnostics(caseA, tr, cfg);

    fprintf('Transfer model: %s\n', string(tr.model_mode));
    fprintf('Primary score: %s\n', string(tr.primary_score));
    fprintf('Transfer Top1: %s\n', string(tr.summary.top1_name));
    fprintf('Transfer HeadGap: %.6g\n', tr.summary.head_gap);
    fprintf('Display rank-key HeadGap: %.6g\n', tr.summary.head_gap_rank_key);
    fprintf('HeadGap ratio: %.6g\n', tr.summary.head_gap_ratio);
    fprintf('PT mean minus base max abs: %.6g\n', tr.sanity.PT_mean_minus_base_max_abs);
    fprintf('Deployable action leakage-free: %d\n', tr.sanity.deployable_action_leakage_free);

    fprintf('\nRisk-truth validation outputs:\n');
    local_print_validation('Primary', tr.validation);
    local_print_validation('Base main', tr.validation_base);
    local_print_validation('PT mean sanity', tr.validation_PT_mean);
    local_print_validation('Support diagnostic', tr.validation_support);
    local_print_validation('Mechanism-load diagnostic', tr.validation_mechanism_load);
    local_print_validation('Communication-burden diagnostic', tr.validation_communication_burden);
    local_print_validation('Action-priority diagnostic', tr.validation_action_priority);

    fprintf('Decision-support mechanism outputs:\n');
    fprintf('Mean information need core: %.4f\n', mean(tr.G_information_need,'omitnan'));
    fprintf('Mean information need resid: %.4f\n', mean(tr.G_information_need_resid,'omitnan'));
    fprintf('Mean mechanism load: %.4f\n', mean(tr.G_mechanism_load,'omitnan'));
    fprintf('Mean communication burden: %.4f\n', mean(tr.G_communication_burden,'omitnan'));
    fprintf('Mean PT polarization: %.4f\n', mean(tr.G_Pol_PT,'omitnan'));
    fprintf('Mean support polarization: %.4f\n', mean(tr.G_Pol_support,'omitnan'));
    fprintf('Mean |D_PT|: %.4f\n', mean(abs(tr.G_D_PT),'omitnan'));
    fprintf('Mean |D_support|: %.4f\n', mean(abs(tr.G_D_support),'omitnan'));
    local_print_action_summary(tr);
    local_print_comparisons(tr);

    local_print_top_alternatives(tr, fc, cfg.report.top_n);
    local_print_top_profiles(tr, cfg.report.profile_top_n);

    cfgCase = cfg;
    cfgCase.report.csv_dir = fullfile(cfg.report.csv_dir, char(string(fc.case_id)));
    p4fresh.reports.export_stageA1_tables_csv(diagnostics, cfgCase);

    transfers{c} = tr;
    diagnostics_all{c} = diagnostics;
    summary_rows(c) = local_make_summary_row(fc, tr);
end

summary_table = struct2table(summary_rows);
fprintf('\n================ PUBLIC FUZZY VALIDATION SUMMARY ================\n');
disp(summary_table);
fprintf('==================================================================\n');

out = struct();
out.caseA = caseA;
out.dataset = dataset;
out.fuzzy_cases = fuzzy_cases;
out.transfers = transfers;
out.diagnostics = diagnostics_all;
out.public_fuzzy_summary = summary_table;
end

function local_print_validation(label, val)
if isstruct(val) && isfield(val,'available') && val.available
    fprintf('%s Spearman rho: %.4f | weighted rho: %.4f\n', label, val.spearman_rho, val.weighted_spearman_rho);
    fprintf('%s NDCG@10%%: %.4f | weighted NDCG@10%%: %.4f\n', label, val.ndcg_at_10pct, val.weighted_ndcg_at_10pct);
    fprintf('%s Top10-Bottom10 truth gap: %.4f | weighted gap: %.4f\n', label, val.top_bottom_gap_truth, val.weighted_top_bottom_gap_truth);
end
end

function local_print_top_alternatives(tr, fc, k)
ord = tr.rank_order(:);
truth = double(fc.ground_truth(:));
k = min(k, numel(ord));
fprintf('Top %d alternatives by primary score (diagnostic only; profile/action tables are preferred):\n', k);
for r = 1:k
    idx = ord(r);
    fprintf('  #%d %s | primary=%.8g | base=%.8g | PTmean=%.8g | D_PT=%.8g | support=%.8g | D_support=%.8g | truth=%.8g | info=%.8g | info_resid=%.8g | action=%.8g\n', ...
        r, string(fc.alternative_names(idx)), tr.G(idx), tr.G_base(idx), tr.G_PT_mean(idx), tr.G_D_PT(idx), tr.G_support(idx), tr.G_D_support(idx), truth(idx), tr.G_information_need(idx), tr.G_information_need_resid(idx), tr.G_action_priority(idx));
end
end

function local_print_action_summary(tr)
if ~isfield(tr,'deployable_action_table') || isempty(tr.deployable_action_table) || height(tr.deployable_action_table)==0, return; end
T = tr.deployable_action_table;
labels = unique(T.primary_action);
fprintf('Deployable primary action counts:\n');
for i = 1:numel(labels)
    fprintf('  %s: %d profiles\n', string(labels(i)), sum(T.primary_action == labels(i)));
end
fprintf('Top 5 deployable action-priority profiles:\n');
disp(T(1:min(5,height(T)), {'profile_id','n_alternatives','action_priority','S_communication_burden','G_mechanism_load','primary_action','secondary_flags','primary_rationale','secondary_cautions','top_drivers'}));
if isfield(tr,'audit_table') && ~isempty(tr.audit_table)
    fprintf('Top 5 post-hoc audit warnings:\n');
    vars = {'profile_id','n_alternatives','truth_var','residual_calibrated','audit_heterogeneity','audit_residual','audit_note'};
vars = vars(ismember(vars, tr.audit_table.Properties.VariableNames));
disp(tr.audit_table(1:min(5,height(tr.audit_table)), vars));
end
end

function local_print_comparisons(tr)
if isfield(tr,'comparison_table') && ~isempty(tr.comparison_table)
    fprintf('Comparison baselines:\n');
    disp(tr.comparison_table);
end
if isfield(tr,'ablation_table') && ~isempty(tr.ablation_table)
    fprintf('Ablation diagnostics:\n');
    disp(tr.ablation_table);
end
end

function local_print_top_profiles(tr, k)
if ~isfield(tr,'profile_table') || isempty(tr.profile_table) || height(tr.profile_table)==0, return; end
T = tr.profile_table;
k = min(k, height(T));
fprintf('Top %d profile groups by support divergence:\n', k);
disp(T(1:k, {'profile_id','n_alternatives','mean_truth','var_truth','mean_base','mean_D_PT','mean_support','mean_info','mean_mechanism_load','mean_communication_burden','mean_abs_D_support'}));
end

function row = local_empty_summary_row()
row = struct();
row.case_id = ""; row.source_name = ""; row.n_alternatives = int32(0); row.n_profiles = int32(0); row.primary_score = "";
row.top1_name = ""; row.head_gap = NaN; row.head_gap_ratio = NaN;
row.primary_spearman_rho = NaN; row.primary_weighted_spearman_rho = NaN; row.primary_ndcg_at_10pct = NaN; row.primary_weighted_ndcg_at_10pct = NaN;
row.base_spearman_rho = NaN; row.base_weighted_spearman_rho = NaN; row.base_ndcg_at_10pct = NaN; row.base_weighted_ndcg_at_10pct = NaN;
row.support_spearman_rho = NaN; row.mechanism_load_weighted_spearman_rho = NaN; row.communication_burden_weighted_spearman_rho = NaN; row.action_priority_weighted_spearman_rho = NaN;
row.mean_information_need = NaN; row.mean_mechanism_load = NaN; row.mean_communication_burden = NaN; row.mean_Pol_PT = NaN; row.mean_Pol_support = NaN; row.mean_abs_D_PT = NaN; row.mean_abs_D_support = NaN;
row.PT_mean_minus_base_max_abs = NaN; row.deployable_action_leakage_free = false;
end

function row = local_make_summary_row(fc, tr)
row = local_empty_summary_row();
row.case_id = string(fc.case_id);
row.source_name = string(fc.source_name);
row.n_alternatives = int32(numel(fc.alternative_names));
if isfield(fc,'profile_id'), row.n_profiles = int32(numel(unique(fc.profile_id))); end
row.primary_score = string(tr.primary_score);
row.top1_name = string(tr.summary.top1_name);
row.head_gap = tr.summary.head_gap;
row.head_gap_ratio = tr.summary.head_gap_ratio;
if tr.validation.available
    row.primary_spearman_rho = tr.validation.spearman_rho;
    row.primary_weighted_spearman_rho = tr.validation.weighted_spearman_rho;
    row.primary_ndcg_at_10pct = tr.validation.ndcg_at_10pct;
    row.primary_weighted_ndcg_at_10pct = tr.validation.weighted_ndcg_at_10pct;
end
if tr.validation_base.available
    row.base_spearman_rho = tr.validation_base.spearman_rho;
    row.base_weighted_spearman_rho = tr.validation_base.weighted_spearman_rho;
    row.base_ndcg_at_10pct = tr.validation_base.ndcg_at_10pct;
    row.base_weighted_ndcg_at_10pct = tr.validation_base.weighted_ndcg_at_10pct;
end
if tr.validation_support.available, row.support_spearman_rho = tr.validation_support.spearman_rho; end
if tr.validation_mechanism_load.available, row.mechanism_load_weighted_spearman_rho = tr.validation_mechanism_load.weighted_spearman_rho; end
if tr.validation_communication_burden.available, row.communication_burden_weighted_spearman_rho = tr.validation_communication_burden.weighted_spearman_rho; end
if tr.validation_action_priority.available, row.action_priority_weighted_spearman_rho = tr.validation_action_priority.weighted_spearman_rho; end
row.mean_information_need = mean(tr.G_information_need,'omitnan');
row.mean_mechanism_load = mean(tr.G_mechanism_load,'omitnan');
row.mean_communication_burden = mean(tr.G_communication_burden,'omitnan');
row.mean_Pol_PT = mean(tr.G_Pol_PT,'omitnan');
row.mean_Pol_support = mean(tr.G_Pol_support,'omitnan');
row.mean_abs_D_PT = mean(abs(tr.G_D_PT),'omitnan');
row.mean_abs_D_support = mean(abs(tr.G_D_support),'omitnan');
row.PT_mean_minus_base_max_abs = tr.sanity.PT_mean_minus_base_max_abs;
row.deployable_action_leakage_free = logical(tr.sanity.deployable_action_leakage_free);
end
