function out = run_paper4_fresh_demo()
% Main pipeline with original file/function name.
% Psychological/behavioral calibration uses the OpenNeuro dataset configured
% in +config/default_config.m. Public fuzzy datasets are loaded independently
% for external fuzzy ranking validation.

cfg = p4fresh.config.default_config();

openneuro_id = local_cfg_string(cfg, {'openneuro','dataset_id'}, "configured OpenNeuro dataset");
fprintf('\n================ PAPER 4 FRESH DEMO (%s + Public Fuzzy) ================\n', string(openneuro_id));

if isfield(cfg, 'openneuro') && isfield(cfg.openneuro, 'dataset_id') && string(cfg.openneuro.dataset_id) ~= "ds000030"
    warning('run_paper4_fresh_demo:OpenNeuroDatasetId', ...
        ['Current cfg.openneuro.dataset_id is %s. This manuscript/code path is written for OpenNeuro ds000030 BART; ' ...
         'update +config/default_config.m and the corresponding OpenNeuro data path/source before running.'], ...
        string(cfg.openneuro.dataset_id));
end

% -------------------------------------------------------------------------
% Stage A: psychological/behavioral calibration
% -------------------------------------------------------------------------
dataset = p4fresh.io.build_demo_dataset(cfg);
dataset = p4fresh.latent.build_latent_anxiety(dataset, cfg);
caseA = p4fresh.fit.fit_dataset(dataset, cfg);

fprintf('Psychological data source: %s\n', string(dataset.meta.source));
fprintf('Subjects: %d\n', dataset.meta.n_subjects);
fprintf('Trials: %d\n', dataset.meta.n_trials);
fprintf('Best mapping family: %s\n', string(caseA.summary.best_family));
fprintf('Mean choice accuracy: %.4f\n', caseA.summary.mean_choice_accuracy);
fprintf('Mean sample prob: %.4f\n', caseA.summary.mean_sample_prob);

% -------------------------------------------------------------------------
% Stage B: independent public fuzzy ranking validation
% -------------------------------------------------------------------------
% Do not use the old constructed fuzzy case. Public fuzzy cases must have
% UCI_* identifiers and ground_truth for external ranking validation.
fuzzy_cases = local_get_public_fuzzy_cases(dataset, cfg);

nCases = numel(fuzzy_cases);
transfers = cell(nCases, 1);
diagnostics_all = cell(nCases, 1);
summary_rows = repmat(local_empty_summary_row(), nCases, 1);

for c = 1:nCases
    fuzzy_case = fuzzy_cases(c);

    fprintf('\n---------------- PUBLIC FUZZY CASE %d/%d ----------------\n', c, nCases);
    fprintf('Case ID: %s\n', string(fuzzy_case.case_id));
    fprintf('Source: %s\n', string(fuzzy_case.source_name));
    fprintf('Task: %s\n', string(fuzzy_case.task_label));
    fprintf('Alternatives: %d\n', numel(fuzzy_case.alternative_names));
    if isfield(fuzzy_case, 'download_url')
        fprintf('Download URL: %s\n', string(fuzzy_case.download_url));
    end

    transfer = p4fresh.fuzzy.run_transfer(caseA, fuzzy_case, cfg);
    diagnostics = p4fresh.reports.run_stageA1_diagnostics(caseA, transfer, cfg);

    fprintf('Transfer Top1: %s\n', string(transfer.summary.top1_name));
    fprintf('Transfer HeadGap: %.6g\n', transfer.summary.head_gap);
    fprintf('HeadGap ratio: %.6g\n', transfer.summary.head_gap_ratio);

    if isfield(transfer, 'validation') && isfield(transfer.validation, 'available') && transfer.validation.available
        fprintf('Validation target: %s\n', string(transfer.validation.ground_truth_label));
        fprintf('Spearman rho: %.4f\n', transfer.validation.spearman_rho);
        fprintf('NDCG@10%%: %.4f\n', transfer.validation.ndcg_at_10pct);
        fprintf('NDCG@20%%: %.4f\n', transfer.validation.ndcg_at_20pct);
        fprintf('Top 10%% mean truth: %.4f\n', transfer.validation.top10pct_mean_truth);
        fprintf('Bottom 10%% mean truth: %.4f\n', transfer.validation.bottom10pct_mean_truth);
    else
        fprintf('Validation target: unavailable\n');
    end

    if isfield(transfer, 'baseline') && isfield(transfer.baseline, 'validation') && ...
            isfield(transfer.baseline.validation, 'available') && transfer.baseline.validation.available
        fprintf('Baseline Spearman rho: %.4f\n', transfer.baseline.validation.spearman_rho);
        fprintf('Baseline NDCG@10%%: %.4f\n', transfer.baseline.validation.ndcg_at_10pct);
    end

    local_print_top_alternatives(transfer, fuzzy_case, 10);

    % Export each public case into its own output folder so CSV files do not
    % overwrite each other. This is an output folder only, not a new source directory.
    cfgCase = cfg;
    cfgCase.report.csv_dir = fullfile(cfg.report.csv_dir, char(string(fuzzy_case.case_id)));
    p4fresh.reports.export_stageA1_tables_csv(diagnostics, cfgCase);

    summary_rows(c) = local_make_summary_row(fuzzy_case, transfer);
    transfers{c,1} = transfer;
    diagnostics_all{c,1} = diagnostics;
end

summary_table = struct2table(summary_rows);
fprintf('\n================ PUBLIC FUZZY VALIDATION SUMMARY ================\n');
disp(summary_table);
fprintf('==================================================================\n');

out = struct();
out.caseA = caseA;
out.transfers = transfers;
out.diagnostics = diagnostics_all;
out.dataset = dataset;
out.fuzzy_cases = fuzzy_cases;
out.public_fuzzy_summary = summary_table;
end

function fuzzy_cases = local_get_public_fuzzy_cases(dataset, cfg)
fuzzy_cases = [];

if isfield(dataset, 'fuzzy_cases') && local_is_public_case_array(dataset.fuzzy_cases)
    fuzzy_cases = dataset.fuzzy_cases;
elseif isfield(dataset, 'fuzzy_case') && local_is_public_case_array(dataset.fuzzy_case)
    fuzzy_cases = dataset.fuzzy_case;
end

if isempty(fuzzy_cases)
    if ~isfield(dataset, 'subjects') || isempty(dataset.subjects)
        error('run_paper4_fresh_demo:NoSubjectsForFuzzy', ...
            'dataset.subjects is empty, so public fuzzy cases cannot be expanded to subject-by-alternative matrices.');
    end
    if isfield(dataset, 'trial_table')
        trialT = dataset.trial_table;
    else
        trialT = table();
    end
    fuzzy_cases = p4fresh.io.build_demo_fuzzy_case(dataset.subjects, cfg, trialT);
end

if ~local_is_public_case_array(fuzzy_cases)
    error('run_paper4_fresh_demo:OldFuzzyCaseDetected', ...
        'The fuzzy case is not a public UCI fuzzy case. Replace the old +io/build_demo_fuzzy_case.m first.');
end
end

function tf = local_is_public_case_array(cases)
tf = false;
if isempty(cases) || ~isstruct(cases)
    return;
end
if ~isfield(cases, 'case_id') || ~isfield(cases, 'ground_truth')
    return;
end
ids = string({cases.case_id});
tf = all(startsWith(ids, "UCI_"));
end

function local_print_top_alternatives(transfer, fuzzy_case, k)
ord = transfer.rank_order(:);
G = transfer.G(:);
y = [];
hasTruth = isfield(fuzzy_case, 'ground_truth') && numel(fuzzy_case.ground_truth) == numel(G);
if hasTruth
    y = double(fuzzy_case.ground_truth(:));
end
k = min(k, numel(ord));
fprintf('Top %d alternatives:\n', k);
for r = 1:k
    idx = ord(r);
    if hasTruth
        fprintf('  #%d %s | score = %.8g | truth = %.8g\n', r, string(fuzzy_case.alternative_names(idx)), G(idx), y(idx));
    else
        fprintf('  #%d %s | score = %.8g\n', r, string(fuzzy_case.alternative_names(idx)), G(idx));
    end
end
end

function row = local_empty_summary_row()
row = struct();
row.case_id = "";
row.source_name = "";
row.n_alternatives = int32(0);
row.top1_name = "";
row.head_gap = NaN;
row.head_gap_ratio = NaN;
row.spearman_rho = NaN;
row.ndcg_at_10pct = NaN;
row.ndcg_at_20pct = NaN;
row.baseline_spearman_rho = NaN;
row.baseline_ndcg_at_10pct = NaN;
end

function row = local_make_summary_row(fuzzy_case, transfer)
row = local_empty_summary_row();
row.case_id = string(fuzzy_case.case_id);
row.source_name = string(fuzzy_case.source_name);
row.n_alternatives = int32(numel(fuzzy_case.alternative_names));
row.top1_name = string(transfer.summary.top1_name);
row.head_gap = transfer.summary.head_gap;
row.head_gap_ratio = transfer.summary.head_gap_ratio;
if isfield(transfer, 'validation') && isfield(transfer.validation, 'available') && transfer.validation.available
    row.spearman_rho = transfer.validation.spearman_rho;
    row.ndcg_at_10pct = transfer.validation.ndcg_at_10pct;
    row.ndcg_at_20pct = transfer.validation.ndcg_at_20pct;
end
if isfield(transfer, 'baseline') && isfield(transfer.baseline, 'validation') && ...
        isfield(transfer.baseline.validation, 'available') && transfer.baseline.validation.available
    row.baseline_spearman_rho = transfer.baseline.validation.spearman_rho;
    row.baseline_ndcg_at_10pct = transfer.baseline.validation.ndcg_at_10pct;
end
end

function value = local_cfg_string(S, path, defaultValue)
value = defaultValue;
cur = S;
for k = 1:numel(path)
    key = path{k};
    if isstruct(cur) && isfield(cur, key)
        cur = cur.(key);
    else
        return;
    end
end
value = string(cur);
end
