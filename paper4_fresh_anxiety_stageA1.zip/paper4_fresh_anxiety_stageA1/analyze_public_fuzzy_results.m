function analysis = analyze_public_fuzzy_results(out, varargin)
%ANALYZE_PUBLIC_FUZZY_RESULTS Export paper-ready analysis tables/figures.
%
% Add this file to the MATLAB project root. Do NOT rename or overwrite:
%   run_paper4_fresh_demo.m
%   +io/build_demo_fuzzy_case.m
%   +fuzzy/run_transfer.m
%
% Usage:
%   out = run_paper4_fresh_demo();
%   analysis = analyze_public_fuzzy_results(out);
%
% Or run everything directly:
%   analysis = analyze_public_fuzzy_results();
%
% Optional name-value pairs:
%   'OutputDir'       default: fullfile(pwd,'paper4_fresh_stageA1_csv','paper_results')
%   'BootstrapN'      default: 300
%   'PerturbN'        default: 100
%   'PerturbDeltas'   default: [0.01 0.03 0.05]
%   'RandomSeed'      default: 20261001
%   'MakeFigures'     default: true
%
% The script only reads the already computed output structure and exports
% analysis artifacts. It does not change the core mathematical model.

if nargin < 1 || isempty(out)
    out = run_paper4_fresh_demo();
end

opts = local_parse_options(varargin{:});
rng(opts.RandomSeed, 'twister');

if ~exist(opts.OutputDir, 'dir')
    mkdir(opts.OutputDir);
end

analysis = struct();
analysis.output_dir = opts.OutputDir;

% -------------------------------------------------------------------------
% Table R1: behavioral calibration summary
% -------------------------------------------------------------------------
analysis.table_R1_behavioral_summary = local_make_behavioral_summary(out);
local_write_table(analysis.table_R1_behavioral_summary, opts.OutputDir, ...
    'Table_R1_behavioral_summary.csv');

% -------------------------------------------------------------------------
% Table R2: mapping-family comparison
% -------------------------------------------------------------------------
analysis.table_R2_mapping_family = local_make_mapping_family_table(out);
local_write_table(analysis.table_R2_mapping_family, opts.OutputDir, ...
    'Table_R2_mapping_family_comparison.csv');

% -------------------------------------------------------------------------
% Table R3: calibrated-parameter summary
% -------------------------------------------------------------------------
analysis.table_R3_parameter_summary = local_make_parameter_summary_table(out);
local_write_table(analysis.table_R3_parameter_summary, opts.OutputDir, ...
    'Table_R3_parameter_summary.csv');

% -------------------------------------------------------------------------
% Table R4/R5: public fuzzy transfer validation and baseline deltas
% -------------------------------------------------------------------------
analysis.table_R4_public_fuzzy_validation = local_make_public_fuzzy_validation_table(out);
local_write_table(analysis.table_R4_public_fuzzy_validation, opts.OutputDir, ...
    'Table_R4_public_fuzzy_validation.csv');

analysis.table_R5_baseline_delta = local_make_baseline_delta_table(analysis.table_R4_public_fuzzy_validation);
local_write_table(analysis.table_R5_baseline_delta, opts.OutputDir, ...
    'Table_R5_baseline_delta.csv');

% -------------------------------------------------------------------------
% Table R6: Top-K enrichment
% -------------------------------------------------------------------------
pctList = [0.01 0.05 0.10 0.20 0.30];
analysis.table_R6_topk_enrichment = local_make_topk_enrichment_table(out, pctList);
local_write_table(analysis.table_R6_topk_enrichment, opts.OutputDir, ...
    'Table_R6_topk_enrichment.csv');

% -------------------------------------------------------------------------
% Table R7: ablations
% -------------------------------------------------------------------------
analysis.table_R7_ablation = local_make_ablation_table(out);
local_write_table(analysis.table_R7_ablation, opts.OutputDir, ...
    'Table_R7_public_fuzzy_ablation.csv');

% -------------------------------------------------------------------------
% Table R8: bootstrap confidence intervals
% -------------------------------------------------------------------------
analysis.table_R8_bootstrap_ci = local_make_bootstrap_ci_table(out, opts.BootstrapN);
local_write_table(analysis.table_R8_bootstrap_ci, opts.OutputDir, ...
    'Table_R8_bootstrap_ci.csv');

% -------------------------------------------------------------------------
% Table R9: perturbation robustness
% -------------------------------------------------------------------------
analysis.table_R9_perturbation_robustness = local_make_perturbation_table(out, opts.PerturbN, opts.PerturbDeltas);
local_write_table(analysis.table_R9_perturbation_robustness, opts.OutputDir, ...
    'Table_R9_perturbation_robustness.csv');

% -------------------------------------------------------------------------
% Figures
% -------------------------------------------------------------------------
if opts.MakeFigures
    local_make_figures(analysis, opts.OutputDir);
end

fprintf('\n================ PAPER-READY ANALYSIS EXPORT COMPLETE ================\n');
fprintf('Output folder:\n  %s\n', opts.OutputDir);
fprintf('Tables exported: R1-R9\n');
if opts.MakeFigures
    fprintf('Figures exported: Fig_R1-Fig_R5\n');
end
fprintf('======================================================================\n');
end

% =========================================================================
% Option parsing
% =========================================================================
function opts = local_parse_options(varargin)
opts = struct();
opts.OutputDir = fullfile(pwd, 'paper4_fresh_stageA1_csv', 'paper_results');
opts.BootstrapN = 300;
opts.PerturbN = 100;
opts.PerturbDeltas = [0.01 0.03 0.05];
opts.RandomSeed = 20261001;
opts.MakeFigures = true;

if mod(numel(varargin), 2) ~= 0
    error('analyze_public_fuzzy_results:BadOptions', ...
        'Options must be name-value pairs.');
end

for k = 1:2:numel(varargin)
    key = char(string(varargin{k}));
    val = varargin{k+1};
    switch lower(key)
        case 'outputdir'
            opts.OutputDir = char(string(val));
        case 'bootstrapn'
            opts.BootstrapN = max(0, round(double(val)));
        case 'perturbn'
            opts.PerturbN = max(0, round(double(val)));
        case 'perturbdeltas'
            opts.PerturbDeltas = double(val(:))';
        case 'randomseed'
            opts.RandomSeed = round(double(val));
        case 'makefigures'
            opts.MakeFigures = logical(val);
        otherwise
            error('analyze_public_fuzzy_results:UnknownOption', ...
                'Unknown option: %s', key);
    end
end
end

function local_write_table(T, outDir, filename)
if ~exist(outDir, 'dir')
    mkdir(outDir);
end
writetable(T, fullfile(outDir, filename));
end

% =========================================================================
% R1-R5 tables
% =========================================================================
function T = local_make_behavioral_summary(out)
meta = out.dataset.meta;
caseA = out.caseA;
T = table();
T.dataset_id = string({meta.dataset_id})';
T.source = string({meta.source})';
T.task = string({meta.task})';
T.n_subjects = double(meta.n_subjects);
T.n_trials = double(meta.n_trials);
T.n_blocks = double(meta.n_blocks);
T.best_mapping_family = string(caseA.summary.best_family);
T.mean_choice_accuracy = double(caseA.summary.mean_choice_accuracy);
T.mean_sample_probability = double(caseA.summary.mean_sample_prob);
if isfield(meta, 'n_event_files_used')
    T.n_event_files_used = double(meta.n_event_files_used);
end
if isfield(meta, 'mapping_version')
    T.mapping_version = string({meta.mapping_version})';
end
T.note = "Public fuzzy benchmarks are downstream transfer checks; OpenNeuro calibration is the core behavioral evidence.";
end

function T = local_make_mapping_family_table(out)
sr = out.caseA.subject_results;
allFams = strings(0,1);
for s = 1:numel(sr)
    fr = sr(s).family_results;
    allFams = [allFams; string({fr.family})']; %#ok<AGROW>
end
fams = unique(allFams, 'stable');
rows = cell(numel(fams), 1);

for f = 1:numel(fams)
    fam = fams(f);
    nll = nan(numel(sr),1);
    aic = nan(numel(sr),1);
    bic = nan(numel(sr),1);
    exitflag = nan(numel(sr),1);
    selected = false(numel(sr),1);
    for s = 1:numel(sr)
        fr = sr(s).family_results;
        idx = find(string({fr.family})' == fam, 1, 'first');
        if ~isempty(idx)
            nll(s) = double(fr(idx).nll);
            aic(s) = double(fr(idx).aic);
            bic(s) = double(fr(idx).bic);
            exitflag(s) = double(fr(idx).exitflag);
        end
        selected(s) = string(sr(s).best_family) == fam;
    end
    row = struct();
    row.family = fam;
    row.selected_subjects = sum(selected);
    row.selected_rate = mean(selected);
    row.mean_nll = mean(nll, 'omitnan');
    row.median_nll = median(nll, 'omitnan');
    row.mean_aic = mean(aic, 'omitnan');
    row.mean_bic = mean(bic, 'omitnan');
    row.converged_rate = mean(exitflag > 0, 'omitnan');
    rows{f} = row;
end
T = struct2table([rows{:}]');
T = sortrows(T, {'selected_subjects','mean_nll'}, {'descend','ascend'});
end

function T = local_make_parameter_summary_table(out)
sr = out.caseA.subject_results;
names = ["mean_alpha","mean_kappa","mean_csub","mean_lambda","mean_beta","mean_w"];
rows = cell(numel(names), 1);
for j = 1:numel(names)
    vals = nan(numel(sr),1);
    for s = 1:numel(sr)
        bs = sr(s).behavior_summary;
        if isfield(bs, char(names(j)))
            vals(s) = double(bs.(char(names(j))));
        end
    end
    row = struct();
    row.parameter = names(j);
    row.n_subjects = sum(isfinite(vals));
    row.mean = mean(vals, 'omitnan');
    row.std = std(vals, 'omitnan');
    row.median = median(vals, 'omitnan');
    row.q25 = local_quantile(vals, 0.25);
    row.q75 = local_quantile(vals, 0.75);
    row.min = min(vals, [], 'omitnan');
    row.max = max(vals, [], 'omitnan');
    rows{j} = row;
end
T = struct2table([rows{:}]');
end

function T = local_make_public_fuzzy_validation_table(out)
n = numel(out.transfers);
rows = cell(n,1);
for c = 1:n
    tr = out.transfers{c};
    fc = out.fuzzy_cases(c);
    val = tr.validation;
    bval = tr.baseline.validation;
    row = struct();
    row.case_id = string(fc.case_id);
    row.source_name = string(fc.source_name);
    row.task_label = string(fc.task_label);
    row.n_alternatives = int32(numel(fc.alternative_names));
    row.top1_name = string(tr.summary.top1_name);
    row.head_gap = double(tr.summary.head_gap);
    row.head_gap_ratio = double(tr.summary.head_gap_ratio);
    row.validation_target = string(val.ground_truth_label);
    row.spearman_rho = double(val.spearman_rho);
    row.ndcg_at_10pct = double(val.ndcg_at_10pct);
    row.ndcg_at_20pct = double(val.ndcg_at_20pct);
    row.top10pct_mean_truth = double(val.top10pct_mean_truth);
    row.bottom10pct_mean_truth = double(val.bottom10pct_mean_truth);
    row.baseline_top1_name = string(tr.baseline.summary.top1_name);
    row.baseline_spearman_rho = double(bval.spearman_rho);
    row.baseline_ndcg_at_10pct = double(bval.ndcg_at_10pct);
    row.baseline_ndcg_at_20pct = double(bval.ndcg_at_20pct);
    row.baseline_head_gap_ratio = double(tr.baseline.summary.head_gap_ratio);
    if isfield(fc, 'transform_note')
        row.transform_note = string(fc.transform_note);
    else
        row.transform_note = "";
    end
    rows{c} = row;
end
T = struct2table([rows{:}]');
end

function T = local_make_baseline_delta_table(R4)
T = table();
T.case_id = R4.case_id;
T.source_name = R4.source_name;
T.n_alternatives = R4.n_alternatives;
T.delta_spearman = R4.spearman_rho - R4.baseline_spearman_rho;
T.delta_ndcg_at_10pct = R4.ndcg_at_10pct - R4.baseline_ndcg_at_10pct;
T.delta_ndcg_at_20pct = R4.ndcg_at_20pct - R4.baseline_ndcg_at_20pct;
T.method_head_gap_ratio = R4.head_gap_ratio;
T.baseline_head_gap_ratio = R4.baseline_head_gap_ratio;
T.interpretation = strings(height(T),1);
for i = 1:height(T)
    if T.delta_ndcg_at_10pct(i) > 0 && T.delta_spearman(i) >= 0
        T.interpretation(i) = "positive transfer gain";
    elseif abs(T.delta_ndcg_at_10pct(i)) <= 0.01 && abs(T.delta_spearman(i)) <= 0.01
        T.interpretation(i) = "comparable to baseline";
    else
        T.interpretation(i) = "baseline stronger on this metric";
    end
end
end

% =========================================================================
% Top-K enrichment
% =========================================================================
function T = local_make_topk_enrichment_table(out, pctList)
rows = {};
ptr = 0;
for c = 1:numel(out.transfers)
    tr = out.transfers{c};
    fc = out.fuzzy_cases(c);
    truth = double(fc.ground_truth(:));
    scores = double(tr.G(:));
    bscore = double(tr.baseline.G(:));
    for p = 1:numel(pctList)
        pct = pctList(p);
        m1 = local_topk_stats(scores, truth, pct);
        mb = local_topk_stats(bscore, truth, pct);
        ptr = ptr + 1;
        row = struct();
        row.case_id = string(fc.case_id);
        row.source_name = string(fc.source_name);
        row.k_pct = pct;
        row.k_count = int32(max(1, ceil(pct * numel(truth))));
        row.method_topk_mean_truth = m1.top_mean;
        row.method_bottomk_mean_truth = m1.bottom_mean;
        row.method_enrichment_ratio = m1.enrichment_ratio;
        row.baseline_topk_mean_truth = mb.top_mean;
        row.baseline_bottomk_mean_truth = mb.bottom_mean;
        row.baseline_enrichment_ratio = mb.enrichment_ratio;
        row.delta_topk_mean_truth = m1.top_mean - mb.top_mean;
        rows{ptr,1} = row; %#ok<AGROW>
    end
end
T = struct2table([rows{:}]');
end

function st = local_topk_stats(scores, truth, pct)
scores = double(scores(:));
truth = double(truth(:));
mask = isfinite(scores) & isfinite(truth);
scores = scores(mask);
truth = truth(mask);
[~, ord] = sort(scores, 'descend');
n = numel(truth);
k = max(1, ceil(pct * n));
k = min(k, n);
topMean = mean(truth(ord(1:k)), 'omitnan');
bottomMean = mean(truth(ord((n-k+1):n)), 'omitnan');
den = max(abs(bottomMean), eps);
st = struct();
st.top_mean = topMean;
st.bottom_mean = bottomMean;
st.enrichment_ratio = topMean / den;
end

% =========================================================================
% Ablations
% =========================================================================
function T = local_make_ablation_table(out)
rows = {};
ptr = 0;
for c = 1:numel(out.fuzzy_cases)
    fc = out.fuzzy_cases(c);
    tr = out.transfers{c};
    truth = double(fc.ground_truth(:));
    B = double(fc.B);
    U = double(fc.U);
    lambda = double(tr.subject_lambda(:));
    beta = double(tr.subject_beta(:));
    omega = double(tr.subject_omega(:));
    nS = numel(lambda);

    variants = {};
    variants{end+1} = local_variant("full_model", double(tr.G(:))); %#ok<AGROW>
    variants{end+1} = local_variant("feature_only_baseline", double(tr.baseline.G(:))); %#ok<AGROW>

    Bmean = repmat(mean(B,1,'omitnan'), nS, 1);
    Umean = repmat(mean(U,1,'omitnan'), nS, 1);
    variants{end+1} = local_variant("no_subject_specific_BU", ...
        local_compute_transfer_scores(Bmean, Umean, lambda, beta, omega)); %#ok<AGROW>

    variants{end+1} = local_variant("uniform_lambda", ...
        local_compute_transfer_scores(B, U, repmat(mean(lambda,'omitnan'), nS, 1), beta, omega)); %#ok<AGROW>

    variants{end+1} = local_variant("uniform_beta", ...
        local_compute_transfer_scores(B, U, lambda, repmat(mean(beta,'omitnan'), nS, 1), omega)); %#ok<AGROW>

    variants{end+1} = local_variant("uniform_lambda_beta", ...
        local_compute_transfer_scores(B, U, repmat(mean(lambda,'omitnan'), nS, 1), ...
        repmat(mean(beta,'omitnan'), nS, 1), omega)); %#ok<AGROW>

    perm = local_fixed_permutation(nS, 1000 + c);
    variants{end+1} = local_variant("shuffled_lambda_beta", ...
        local_compute_transfer_scores(B, U, lambda(perm), beta(perm), omega)); %#ok<AGROW>

    for v = 1:numel(variants)
        score = variants{v}.score(:);
        met = local_metric_pack(score, truth);
        [~, ord] = sort(score, 'descend');
        ptr = ptr + 1;
        row = struct();
        row.case_id = string(fc.case_id);
        row.variant = string(variants{v}.name);
        row.spearman_rho = met.spearman;
        row.ndcg_at_10pct = met.ndcg10;
        row.ndcg_at_20pct = met.ndcg20;
        row.top10pct_mean_truth = met.top10;
        row.bottom10pct_mean_truth = met.bottom10;
        row.top1_name = string(fc.alternative_names(ord(1)));
        row.head_gap_ratio = local_head_gap_ratio(score);
        rows{ptr,1} = row; %#ok<AGROW>
    end
end
T = struct2table([rows{:}]');
end

function v = local_variant(name, score)
v = struct();
v.name = string(name);
v.score = double(score(:));
end

function perm = local_fixed_permutation(n, seed)
oldState = rng;
rng(seed, 'twister');
perm = randperm(n)';
rng(oldState);
end

function G = local_compute_transfer_scores(B, U, lambda, beta, omega)
B = double(B);
U = double(U);
lambda = double(lambda(:));
beta = double(beta(:));
omega = double(omega(:));
nS = numel(lambda);
if size(B,1) == 1 && nS > 1
    B = repmat(B, nS, 1);
end
if size(U,1) == 1 && nS > 1
    U = repmat(U, nS, 1);
end
if numel(omega) ~= nS
    omega = ones(nS,1) / nS;
else
    omega = omega ./ max(sum(omega), eps);
end
P = zeros(size(B));
for s = 1:nS
    V = lambda(s) .* B(s,:) - (1 - lambda(s)) .* U(s,:);
    z = beta(s) .* V;
    z = z - max(z);
    ex = exp(z);
    P(s,:) = ex ./ max(sum(ex), eps);
end
G = omega' * P;
G = G(:);
end

% =========================================================================
% Bootstrap confidence intervals
% =========================================================================
function T = local_make_bootstrap_ci_table(out, nBoot)
rows = {};
ptr = 0;
if nBoot <= 0
    T = table();
    return;
end

for c = 1:numel(out.fuzzy_cases)
    fc = out.fuzzy_cases(c);
    tr = out.transfers{c};
    truth = double(fc.ground_truth(:));
    methodScore = double(tr.G(:));
    baselineScore = double(tr.baseline.G(:));
    n = numel(truth);

    boot = struct();
    boot.method_spearman = nan(nBoot,1);
    boot.baseline_spearman = nan(nBoot,1);
    boot.delta_spearman = nan(nBoot,1);
    boot.method_ndcg10 = nan(nBoot,1);
    boot.baseline_ndcg10 = nan(nBoot,1);
    boot.delta_ndcg10 = nan(nBoot,1);
    boot.method_ndcg20 = nan(nBoot,1);
    boot.baseline_ndcg20 = nan(nBoot,1);
    boot.delta_ndcg20 = nan(nBoot,1);

    for b = 1:nBoot
        idx = randi(n, n, 1);
        m = local_metric_pack(methodScore(idx), truth(idx));
        bb = local_metric_pack(baselineScore(idx), truth(idx));
        boot.method_spearman(b) = m.spearman;
        boot.baseline_spearman(b) = bb.spearman;
        boot.delta_spearman(b) = m.spearman - bb.spearman;
        boot.method_ndcg10(b) = m.ndcg10;
        boot.baseline_ndcg10(b) = bb.ndcg10;
        boot.delta_ndcg10(b) = m.ndcg10 - bb.ndcg10;
        boot.method_ndcg20(b) = m.ndcg20;
        boot.baseline_ndcg20(b) = bb.ndcg20;
        boot.delta_ndcg20(b) = m.ndcg20 - bb.ndcg20;
    end

    fields = fieldnames(boot);
    for f = 1:numel(fields)
        vals = boot.(fields{f});
        ptr = ptr + 1;
        row = struct();
        row.case_id = string(fc.case_id);
        row.metric = string(fields{f});
        row.n_bootstrap = int32(nBoot);
        row.mean_value = mean(vals, 'omitnan');
        row.ci_lower_95 = local_quantile(vals, 0.025);
        row.ci_upper_95 = local_quantile(vals, 0.975);
        rows{ptr,1} = row; %#ok<AGROW>
    end
end
T = struct2table([rows{:}]');
end

% =========================================================================
% Perturbation robustness
% =========================================================================
function T = local_make_perturbation_table(out, nRep, deltas)
rows = {};
ptr = 0;
if nRep <= 0
    T = table();
    return;
end

for c = 1:numel(out.fuzzy_cases)
    fc = out.fuzzy_cases(c);
    tr = out.transfers{c};
    truth = double(fc.ground_truth(:));
    B0 = double(fc.B);
    U0 = double(fc.U);
    lambda = double(tr.subject_lambda(:));
    beta = double(tr.subject_beta(:));
    omega = double(tr.subject_omega(:));
    [~, refTop] = max(double(tr.G(:)));

    for d = 1:numel(deltas)
        delta = double(deltas(d));
        topRet = false(nRep,1);
        spear = nan(nRep,1);
        ndcg10 = nan(nRep,1);
        headRatio = nan(nRep,1);

        for r = 1:nRep
            B = local_clip01(B0 + delta .* (2*rand(size(B0)) - 1));
            U = local_clip01(U0 + delta .* (2*rand(size(U0)) - 1));
            G = local_compute_transfer_scores(B, U, lambda, beta, omega);
            [~, topIdx] = max(G);
            topRet(r) = (topIdx == refTop);
            met = local_metric_pack(G, truth);
            spear(r) = met.spearman;
            ndcg10(r) = met.ndcg10;
            headRatio(r) = local_head_gap_ratio(G);
        end

        ptr = ptr + 1;
        row = struct();
        row.case_id = string(fc.case_id);
        row.perturb_delta = delta;
        row.n_replicates = int32(nRep);
        row.top1_retention_rate = mean(topRet);
        row.mean_spearman = mean(spear, 'omitnan');
        row.spearman_ci_lower_95 = local_quantile(spear, 0.025);
        row.spearman_ci_upper_95 = local_quantile(spear, 0.975);
        row.mean_ndcg_at_10pct = mean(ndcg10, 'omitnan');
        row.ndcg10_ci_lower_95 = local_quantile(ndcg10, 0.025);
        row.ndcg10_ci_upper_95 = local_quantile(ndcg10, 0.975);
        row.mean_head_gap_ratio = mean(headRatio, 'omitnan');
        rows{ptr,1} = row; %#ok<AGROW>
    end
end
T = struct2table([rows{:}]');
end

% =========================================================================
% Figures
% =========================================================================
function local_make_figures(analysis, outDir)
R4 = analysis.table_R4_public_fuzzy_validation;
R5 = analysis.table_R5_baseline_delta;
R6 = analysis.table_R6_topk_enrichment;
R7 = analysis.table_R7_ablation;

local_plot_method_baseline(R4.case_id, R4.spearman_rho, R4.baseline_spearman_rho, ...
    'Spearman rho', fullfile(outDir, 'Fig_R1_method_vs_baseline_spearman.png'));

local_plot_method_baseline(R4.case_id, R4.ndcg_at_10pct, R4.baseline_ndcg_at_10pct, ...
    'NDCG@10%', fullfile(outDir, 'Fig_R2_method_vs_baseline_ndcg10.png'));

local_plot_delta(R5.case_id, R5.delta_spearman, R5.delta_ndcg_at_10pct, ...
    fullfile(outDir, 'Fig_R3_baseline_delta.png'));

local_plot_topk(R6, fullfile(outDir, 'Fig_R4_topk_enrichment.png'));

local_plot_ablation(R7, fullfile(outDir, 'Fig_R5_ablation_ndcg10.png'));
end

function local_plot_method_baseline(caseIds, methodVals, baseVals, ylab, fp)
fig = figure('Visible','off');
bar([double(methodVals(:)) double(baseVals(:))]);
set(gca, 'XTick', 1:numel(caseIds), 'XTickLabel', cellstr(caseIds), 'XTickLabelRotation', 25);
ylabel(ylab);
legend({'Behaviorally calibrated transfer','Feature-only baseline'}, 'Location','best');
grid on;
title(['Public fuzzy benchmark: ' ylab]);
local_save_figure(fig, fp);
end

function local_plot_delta(caseIds, deltaSpearman, deltaNDCG10, fp)
fig = figure('Visible','off');
bar([double(deltaSpearman(:)) double(deltaNDCG10(:))]);
set(gca, 'XTick', 1:numel(caseIds), 'XTickLabel', cellstr(caseIds), 'XTickLabelRotation', 25);
ylabel('Method minus baseline');
legend({'\Delta Spearman','\Delta NDCG@10%'}, 'Location','best');
grid on;
title('Transfer gain over feature-only baseline');
local_save_figure(fig, fp);
end

function local_plot_topk(T, fp)
fig = figure('Visible','off');
cases = unique(T.case_id, 'stable');
hold on;
for c = 1:numel(cases)
    mask = T.case_id == cases(c);
    X = 100 .* double(T.k_pct(mask));
    Y = double(T.method_topk_mean_truth(mask));
    plot(X, Y, '-o', 'DisplayName', char(cases(c)));
end
xlabel('Top-K percentage');
ylabel('Mean ground-truth value in Top-K');
legend('Location','best');
grid on;
title('Top-K enrichment of behaviorally calibrated transfer ranking');
hold off;
local_save_figure(fig, fp);
end

function local_plot_ablation(T, fp)
fig = figure('Visible','off');
fullRows = T.variant == "full_model";
baseRows = T.variant == "feature_only_baseline";
cases = T.case_id(fullRows);
fullVals = T.ndcg_at_10pct(fullRows);
baseVals = T.ndcg_at_10pct(baseRows);
bar([double(fullVals(:)) double(baseVals(:))]);
set(gca, 'XTick', 1:numel(cases), 'XTickLabel', cellstr(cases), 'XTickLabelRotation', 25);
ylabel('NDCG@10%');
legend({'Full model','Feature-only baseline'}, 'Location','best');
grid on;
title('Ablation overview: Full model vs baseline');
local_save_figure(fig, fp);
end

function local_save_figure(fig, fp)
try
    saveas(fig, fp);
catch
    warning('Could not save figure to %s', fp);
end
try
    close(fig);
catch
end
end

% =========================================================================
% Metrics
% =========================================================================
function met = local_metric_pack(scores, truth)
scores = double(scores(:));
truth = double(truth(:));
mask = isfinite(scores) & isfinite(truth);
scores = scores(mask);
truth = truth(mask);
met = struct();
if numel(truth) < 3 || max(truth) <= min(truth) || max(scores) <= min(scores)
    met.spearman = NaN;
    met.ndcg10 = NaN;
    met.ndcg20 = NaN;
    met.top10 = NaN;
    met.bottom10 = NaN;
    return;
end
met.spearman = local_spearman(scores, truth);
met.ndcg10 = local_ndcg_at_pct(scores, truth, 0.10);
met.ndcg20 = local_ndcg_at_pct(scores, truth, 0.20);
st = local_topk_stats(scores, truth, 0.10);
met.top10 = st.top_mean;
met.bottom10 = st.bottom_mean;
end

function rho = local_spearman(x, y)
rx = local_tied_rank(x(:));
ry = local_tied_rank(y(:));
rho = local_pearson_corr(rx, ry);
end

function ndcg = local_ndcg_at_pct(scores, truth, pct)
n = numel(scores);
k = max(1, ceil(pct * n));
k = min(k, n);
rel = local_minmax01(truth(:));
[~, ord] = sort(scores(:), 'descend');
[~, idealOrd] = sort(rel(:), 'descend');
den = local_dcg(rel(idealOrd(1:k)));
if den <= eps
    ndcg = NaN;
else
    ndcg = local_dcg(rel(ord(1:k))) / den;
end
end

function d = local_dcg(rel)
rel = double(rel(:));
pos = (1:numel(rel))';
d = sum((2.^rel - 1) ./ log2(pos + 1));
end

function r = local_tied_rank(x)
x = double(x(:));
r = NaN(size(x));
[sorted, idx] = sort(x);
n = numel(x);
i = 1;
while i <= n
    if ~isfinite(sorted(i))
        r(idx(i)) = NaN;
        i = i + 1;
        continue;
    end
    j = i;
    while j < n && sorted(j+1) == sorted(i)
        j = j + 1;
    end
    r(idx(i:j)) = (i + j) / 2;
    i = j + 1;
end
end

function r = local_pearson_corr(x, y)
x = double(x(:));
y = double(y(:));
mask = isfinite(x) & isfinite(y);
x = x(mask);
y = y(mask);
if numel(x) < 3 || std(x) <= eps || std(y) <= eps
    r = NaN;
    return;
end
x = x - mean(x);
y = y - mean(y);
r = sum(x .* y) ./ sqrt(sum(x.^2) .* sum(y.^2));
end

function z = local_minmax01(x)
x = double(x(:));
z = zeros(size(x));
mask = isfinite(x);
if ~any(mask)
    z(:) = 0.5;
    return;
end
lo = min(x(mask));
hi = max(x(mask));
if hi <= lo + eps
    z(:) = 0.5;
else
    z(mask) = (x(mask) - lo) ./ (hi - lo);
    z(~mask) = 0.5;
end
z = local_clip01(z);
end

function ratio = local_head_gap_ratio(score)
score = double(score(:));
score = score(isfinite(score));
if numel(score) < 2
    ratio = NaN;
    return;
end
s = sort(score, 'descend');
gap = s(1) - s(2);
rngv = max(score) - min(score);
if rngv <= 1e-12
    ratio = NaN;
else
    ratio = gap / rngv;
end
end

function q = local_quantile(x, p)
x = double(x(:));
x = x(isfinite(x));
if isempty(x)
    q = NaN;
    return;
end
x = sort(x);
p = min(max(p, 0), 1);
idx = 1 + (numel(x)-1) * p;
lo = floor(idx);
hi = ceil(idx);
if lo == hi
    q = x(lo);
else
    q = x(lo) + (idx-lo) * (x(hi)-x(lo));
end
end

function x = local_clip01(x)
x = min(max(double(x), 0), 1);
end
