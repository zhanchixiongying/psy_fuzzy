APF-DS-XAI v8 expert label instructions
Case: SCF_2022_PORTFOLIO_RISK_EXPOSURE

Template exported here:
G:\AI\four\paper4_fresh_anxiety_stageA1\paper4_apfds_xai_v8_eaai_outputs\SCF_2022_PORTFOLIO_RISK_EXPOSURE\SCF_2022_PORTFOLIO_RISK_EXPOSURE_human_eval_template.csv

Supported filled label files in this folder:
<case_id>_expert_labels.csv
<case_id>_expert_annotated.csv
<case_id>_human_eval_filled.csv
<case_id>_human_eval_template_filled.csv
APFDS_XAI_v8_train_ready_600_final_guideline_leakfree.csv
APFDS_XAI_v8_final_guideline_combined_600.csv

Required: profile_id, expert_primary_action.
Recommended: case_id, expert_secondary_flags, expert_confidence_1to5, split.
Do not add truth, ground_truth, residual_calibrated, audit, or outcome columns.
