# Core contracts

## Indexing convention
- `l`: subject / expert index
- `t`: trial index
- `i`: alternative index
- `j`: criterion index
- `k`: LDF component index

If an LDF tensor is used:
- `X(l,i,j,k)`

## Input tables
### psychometric_table
- `subject_id`
- `stai_t`
- `ius`
- `masq_aa`
- `pswq`

### trial_table
- `subject_id`
- `trial_id`
- `block_id`
- `vas`
- `loss_flag`
- `uncertainty_level`
- `recent_error`
- `conflict_level`
- `eiv`
- `reward_signal`
- `punishment_signal`
- `sample_obs`
- `choice_obs`
- `choice_optimal`
- `confidence_obs`

## Master dataset struct
- `meta`
- `psychometric_table`
- `trial_table`
- `subjects` (fixed struct array)
- `trials`   (fixed struct array)
- `fuzzy_case`

## Output struct
- `caseA`
- `transfer`
- `diagnostics`

## Diagnostics tables
- `subject_table`
- `family_table`
- `family_subject_table`
- `parameter_table`
- `parameter_boundary_table`
- `anomaly_table`
- `transfer_table`
- `transfer_alt_table`
