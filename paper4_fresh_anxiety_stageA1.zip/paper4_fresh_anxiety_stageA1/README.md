# paper4_fresh_anxiety_stageA1

Fresh MATLAB repository for Paper 4 Stage A.1 diagnostics.

## Entry point
```matlab
restoredefaultpath;
rehash toolboxcache;
addpath(genpath('paper4_fresh_anxiety_stageA1'));
out = run_paper4_fresh_demo();
```

## Main flow
psychometric table + trial table
-> master dataset (fixed contract)
-> latent anxiety
-> subject-level mapping-family fitting
-> Stage A.1 diagnostics tables
-> fuzzy transfer

## Namespace
All package functions live under `+p4fresh`.
No `tp3_*`, `caseA_*`, `p4x*` functions are used.
