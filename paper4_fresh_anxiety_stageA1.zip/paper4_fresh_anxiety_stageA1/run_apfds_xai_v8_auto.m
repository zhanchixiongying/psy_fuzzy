function results = run_apfds_xai_v8_auto()
%RUN_APFDS_XAI_V8_AUTO One-click APF-DS-XAI v8 final-guideline pipeline.
%
% Put this file in project root, then run:
%   results = run_apfds_xai_v8_auto();

clc;

projectRoot = pwd;
labelDir = fullfile(projectRoot, 'expert_labels');
outputDir = fullfile(projectRoot, 'paper4_apfds_xai_v8_eaai_outputs');

maxProfiles = 200;
nBoot = 500;
seed = 20261001;

primaryLabelFile = fullfile(labelDir, 'APFDS_XAI_v8_train_ready_600_final_guideline_v2_strict_blind_visible.csv');
fallbackLabelFile = fullfile(labelDir, 'APFDS_XAI_v8_train_ready_600_final_guideline_v2_leakfree.csv');

fprintf('\n================ APF-DS-XAI v8 AUTO PIPELINE ================\n');
fprintf('Project root:\n  %s\n', projectRoot);
fprintf('Label directory:\n  %s\n', labelDir);
fprintf('Output directory:\n  %s\n', outputDir);
fprintf('Primary label file:\n  %s\n', primaryLabelFile);

if ~exist(labelDir, 'dir')
    error('run_apfds_xai_v8_auto:MissingLabelDir', 'Missing expert_labels folder:\n%s', labelDir);
end
if ~exist(primaryLabelFile, 'file')
    if exist(fallbackLabelFile, 'file')
        warning('Primary strict-blind label file missing. Fallback leakfree label file exists and will be found by pipeline.');
    else
        error('run_apfds_xai_v8_auto:MissingStrictBlindLabelFile', ...
            ['Missing strict-blind label file:\n%s\n\n' ...
             'Put APFDS_XAI_v8_train_ready_600_final_guideline_v2_strict_blind_visible.csv in expert_labels first.'], ...
             primaryLabelFile);
    end
end
if ~exist(outputDir, 'dir'), mkdir(outputDir); end

diaryFile = fullfile(outputDir, ['auto_pipeline_log_' datestr(now,'yyyymmdd_HHMMSS') '.txt']);
diary(diaryFile);
cleanupObj = onCleanup(@() diary('off')); %#ok<NASGU>

fprintf('\n[0] Clearing MATLAB function cache...\n');
clear functions
rehash toolboxcache

fprintf('\n[1] Checking required entry functions...\n');
local_require_function('run_paper4_fresh_demo');
local_require_function('run_apfds_xai_v8_eaai_pipeline');

fprintf('\n[2] Running run_paper4_fresh_demo()...\n');
out = run_paper4_fresh_demo();

fprintf('\n[3] Running run_apfds_xai_v8_eaai_pipeline()...\n');
results = run_apfds_xai_v8_eaai_pipeline(out, labelDir, outputDir, maxProfiles, nBoot, seed);

fprintf('\n[4] Saving auto results...\n');
save(fullfile(outputDir, 'auto_pipeline_out.mat'), 'out', '-v7.3');
save(fullfile(outputDir, 'auto_pipeline_results.mat'), 'results', '-v7.3');

if isfield(results, 'validate_v8_structure')
    fprintf('\n--- validate_v8_structure ---\n');
    disp(results.validate_v8_structure);
end
if isfield(results, 'summary')
    fprintf('\n--- eaai_pipeline_summary ---\n');
    disp(results.summary);
end

fprintf('\nCompleted successfully.\n');
fprintf('Log file:\n  %s\n', diaryFile);
fprintf('Results saved in:\n  %s\n', outputDir);
fprintf('=============================================================\n');
end

function local_require_function(funcName)
if exist(funcName, 'file') ~= 2
    error('run_apfds_xai_v8_auto:MissingFunction', 'Required function not found on MATLAB path: %s', funcName);
end
fprintf('  OK: %s\n', funcName);
end
